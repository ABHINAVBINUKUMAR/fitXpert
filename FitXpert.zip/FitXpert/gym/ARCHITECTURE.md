# FitXpert Architecture

## Overview
FitXpert is a React + Vite single-page application for a gym platform with public marketing pages, member portal screens, and an admin dashboard. The app uses client-side routing, localStorage-based auth simulation, and a modular page/component structure.

## Tech Stack
- React 18
- Vite
- React Router DOM
- Lucide React icons
- Framer Motion
- Recharts
- Tailwind-like custom CSS styling via `index.css` and inline styles

## Application Structure

```text
src/
├── App.jsx                     # Main router and route composition
├── main.jsx                    # React bootstrap entry
├── index.css                   # Global styling / app theme
├── components/
│   ├── AdminSidebar.jsx        # Admin navigation
│   ├── ChatWidget.jsx          # Floating chat UI
│   ├── Layout.jsx              # Generic layout shell
│   ├── ProtectedRoute.jsx      # Auth route guard logic
│   ├── PublicLayout.jsx        # Marketing/public layout
│   ├── Sidebar.jsx             # Member navigation
│   ├── UserSidebar.jsx         # Alternate member sidebar variant
│   └── ui/
│       ├── card.tsx
│       ├── demo.tsx
│       ├── split.jsx
│       └── spotlight.tsx
├── context/
│   └── AuthContext.jsx         # Auth state and session logic
├── lib/
│   ├── utils.js
│   └── utils.ts
├── pages/
│   ├── Home.jsx
│   ├── Login.jsx
│   ├── MemberLogin.jsx
│   ├── AdminLogin.jsx
│   ├── Programs.jsx
│   ├── Pricing.jsx
│   ├── Register.jsx
│   ├── TrainersDirectory.jsx
│   ├── admin/
│   │   ├── AttendanceLogs.jsx
│   │   ├── Dashboard.jsx
│   │   ├── DietPlans.jsx
│   │   ├── Equipment.jsx
│   │   ├── Gamification.jsx
│   │   ├── Members.jsx
│   │   ├── Revenue.jsx
│   │   ├── Settings.jsx
│   │   ├── Trainers.jsx
│   │   └── WorkoutPlans.jsx
│   └── user/
│       ├── Achievements.jsx
│       ├── Attendance.jsx
│       ├── Chat.jsx
│       ├── Dashboard.jsx
│       ├── Diet.jsx
│       ├── Payments.jsx
│       ├── Profile.jsx
│       ├── Trainers.jsx
│       └── Workout.jsx
└── assets/ (if added later)
```

## Core Architecture Pattern

### 1. App entry point
`src/App.jsx` is the central composition root.

Responsibilities:
- Wraps the app in `AuthProvider`
- Sets up `BrowserRouter`
- Defines route groups for public pages and protected portal pages
- Uses `UserRoute` and `AdminRoute` guards to redirect unauthorized access
- Provides separate layout shells for member and admin sections

### 2. Authentication model
`src/context/AuthContext.jsx` provides the app-wide auth state.

Current behavior:
- Stores a role in `localStorage` under `fitxpert_auth`
- Accepts values like `user` and `admin`
- Exposes `login`, `logout`, and `loading`
- Reads storage on mount and sets `user` accordingly

This is a lightweight role-based auth simulation rather than a full backend-backed identity system.

### 3. Route guards
`src/components/ProtectedRoute.jsx` enforces access control.

- `UserRoute`
  - redirects unauthenticated users to `/login/member`
  - redirects admins away from user area to `/admin/dashboard`
  - allows valid member role access

- `AdminRoute`
  - redirects unauthenticated users to `/login/admin`
  - redirects non-admin users away from admin area to `/user/dashboard`
  - allows admin access only

### 4. Layout system
The UI is divided into two major layout patterns:

- Public layout: used for landing pages and marketing content
  - `PublicLayout.jsx`
  - routes: `/`, `/programs`, `/trainers-directory`, `/pricing`

- Member layout: used for logged-in user dashboard and tools
  - `UserLayout()` inside `App.jsx`
  - includes `UserSidebar` and `ChatWidget`

- Admin layout: used for admin operations
  - `AdminLayout()` inside `App.jsx`
  - includes `AdminSidebar`

### 5. Navigation structure
There are both public and protected navigation patterns:

- Public nav: Home, Programs, Trainers, Pricing, then login CTA buttons
- Member sidebar: Dashboard, Chatbot, Attendance, Workout, Diet, Trainers, Equipment, Achievements, Payments
- Admin sidebar: admin-specific sections such as Members, Trainers, Equipment, Workout Plans, Diet Plans, Attendance, Revenue, Gamification, Settings

### 6. Page organization
The app is organized by feature domain:

- `pages/public` style pages are directly under `src/pages/`
- `pages/user/` contains member portal features
- `pages/admin/` contains administrator features

This makes the app easy to extend feature-by-feature while keeping route logic centralized.

## Route Map

### Public routes
- `/` -> `Home`
- `/programs` -> `Programs`
- `/trainers-directory` -> `TrainersDirectory`
- `/pricing` -> `Pricing`

### Auth routes
- `/login/member` -> `MemberLogin`
- `/login/admin` -> `AdminLogin`

### Member routes
- `/user/chat` -> `Chat`
- `/user/attendance` -> `Attendance`
- `/user/workout` -> `WorkoutGenerator`
- `/user/diet` -> `Diet`
- `/user/trainers` -> `Trainers`
- `/user/achievements` -> `Achievements`
- `/user/payments` -> `Payments`
- `/user/profile` -> `Profile`

### Admin routes
- `/admin/dashboard` -> `AdminDashboard`
- `/admin/members` -> `AdminMembers`
- `/admin/trainers` -> `AdminTrainers`
- `/admin/equipment` -> `Equipment`
- `/admin/workout-plans` -> `AdminWorkoutPlans`
- `/admin/diet-plans` -> `AdminDietPlans`
- `/admin/attendance` -> `AdminAttendanceLogs`
- `/admin/revenue` -> `AdminRevenue`
- `/admin/gamification` -> `AdminGamification`
- `/admin/settings` -> `AdminSettings`

## State and Data Flow
The app currently relies mostly on local client-side state and browser storage:

- Auth role stored in `localStorage`
- UI behavior reacts to `user` state from `AuthContext`
- Most pages appear to be mostly static/demo UI screens rather than connected to a backend API
- Navigation and access control are driven from `user.role`

## Design / UI Layer
The current app uses:
- dark theme styling
- neon accent color scheme (`#e8ff47` / neon green)
- fixed sidebars and polished dashboard layouts
- inline styles for many shell and card components

This means the UI layer is largely component-driven but not yet structured around a full design system or CSS module architecture.

## Current Architectural Strengths
- Clear separation between public, member, and admin sections
- Centralized route configuration
- Simple role-based access control
- Modular page organization by feature
- Easy to extend with real backend integration later

## Current Architectural Limitations
- Authentication is not backed by a real backend or token system
- No centralized API layer or service module
- Data is mostly mock/demo content, not persisted state
- Some components are duplicated or partially redundant (`Layout.jsx`, `Sidebar.jsx`, `UserSidebar.jsx`, `AdminSidebar.jsx`)
- Styling is mixed between inline CSS and global CSS, which may reduce consistency over time

## Recommended Next Step
If this app is being extended into a production system, the next natural architecture step would be:
1. Add a real backend API
2. Introduce a centralized data/service layer
3. Replace localStorage auth with secure session/token-based auth
4. Standardize a reusable styling system
5. Split large page sections into feature components and hooks

## Summary
The current architecture is a Vite + React gym SaaS frontend with a role-based route system, modular feature pages, and localStorage auth. It is structured well for a prototype or MVP, and it is ready to evolve into a fuller application with real data and backend integration.
