import { Navigate, Outlet } from "react-router-dom";
import { useAuth } from "../context/AuthContext";

export function UserRoute() {
  const { user } = useAuth();
  
  if (!user) {
    return <Navigate to="/login/member" replace />;
  }
  
  if (user.role === "admin") {
    return <Navigate to="/admin/dashboard" replace />;
  }
  
  return <Outlet />;
}

export function AdminRoute() {
  const { user } = useAuth();
  
  if (!user) {
    return <Navigate to="/login/admin" replace />;
  }
  
  if (user.role !== "admin") {
    return <Navigate to="/user/dashboard" replace />;
  }
  
  return <Outlet />;
}
