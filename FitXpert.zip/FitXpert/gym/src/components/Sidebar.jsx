import { NavLink } from "react-router-dom";
import { 
  LayoutDashboard, MessageSquare, CalendarCheck, Dumbbell, 
  Utensils, Users, Wrench, Trophy, CreditCard, LogOut
} from "lucide-react";

const NAV_ITEMS = [
  { path: "/dashboard", name: "Dashboard", icon: <LayoutDashboard size={20} /> },
  { path: "/chat", name: "Chatbot", icon: <MessageSquare size={20} /> },
  { path: "/attendance", name: "Attendance", icon: <CalendarCheck size={20} /> },
  { path: "/workout", name: "Workout", icon: <Dumbbell size={20} /> },
  { path: "/diet", name: "Diet", icon: <Utensils size={20} /> },
  { path: "/trainers", name: "Trainers", icon: <Users size={20} /> },
  { path: "/equipment", name: "Equipment", icon: <Wrench size={20} /> },
  { path: "/achievements", name: "Achievements", icon: <Trophy size={20} /> },
  { path: "/payments", name: "Payments", icon: <CreditCard size={20} /> },
];

export default function Sidebar() {
  return (
    <div style={styles.sidebar}>
      <NavLink to="/" style={styles.logo}>
        <span style={styles.logoMark}>⬡</span>
        <span style={styles.logoText}>FITXPERT</span>
      </NavLink>
      <nav style={styles.nav}>
        {NAV_ITEMS.map((item) => (
          <NavLink 
            key={item.path} 
            to={item.path}
            className={({ isActive }) => isActive ? 'active-link' : 'default-link'}
            style={({ isActive }) => ({
              ...styles.link,
              ...(isActive ? styles.linkActive : {}),
            })}
          >
            {item.icon}
            <span>{item.name}</span>
          </NavLink>
        ))}
      </nav>
      
      <div style={{ marginTop: "auto", borderTop: "1px solid rgba(255,255,255,0.06)", paddingTop: 24 }}>
        <div style={{ fontSize: 13, textTransform: "uppercase", color: "rgba(255,255,255,0.4)", letterSpacing: 1, marginBottom: 16, fontWeight: 700 }}>
          Role: <span style={{ color: localStorage.getItem("fitxpert_auth") === "admin" ? "#e8ff47" : "#fff" }}>{localStorage.getItem("fitxpert_auth") === "admin" ? "Administrator" : "Member"}</span>
        </div>
        <button 
          onClick={() => { localStorage.removeItem("fitxpert_auth"); window.location.href = "/login"; }}
          style={{ width: "100%", background: "transparent", color: "#ff4747", border: "1px solid rgba(255,71,71,0.2)", padding: "14px", borderRadius: 8, display: "flex", alignItems: "center", gap: 12, fontSize: 14, fontWeight: 800, textTransform: "uppercase", cursor: "pointer", transition: "all 0.2s" }}
        >
          <LogOut size={18} /> Secure Logout
        </button>
      </div>
    </div>
  );
}

const styles = {
  sidebar: {
    width: 260,
    background: "#080808",
    borderRight: "1px solid rgba(255,255,255,0.06)",
    height: "100vh",
    display: "flex",
    flexDirection: "column",
    padding: "24px",
    position: "fixed",
    left: 0,
    top: 0,
    zIndex: 100,
  },
  logo: { 
    display: "flex", 
    alignItems: "center", 
    gap: 10, 
    marginBottom: 40,
    textDecoration: "none",
  },
  logoMark: { fontSize: 28, color: "#e8ff47", lineHeight: 1 },
  logoText: {
    fontSize: 28,
    fontWeight: 800,
    letterSpacing: 4,
    color: "#fff",
    fontFamily: "'Barlow Condensed', sans-serif",
  },
  nav: {
    display: "flex",
    flexDirection: "column",
    gap: 12,
  },
  link: {
    display: "flex",
    alignItems: "center",
    gap: 16,
    padding: "12px 16px",
    borderRadius: 8,
    color: "rgba(255,255,255,0.6)",
    textDecoration: "none",
    fontSize: 16,
    fontWeight: 600,
    letterSpacing: 1,
    textTransform: "uppercase",
    transition: "all 0.2s",
  },
  linkActive: {
    background: "rgba(232,255,71,0.1)",
    color: "#e8ff47",
    boxShadow: "inset 4px 0 0 #e8ff47",
  }
}
