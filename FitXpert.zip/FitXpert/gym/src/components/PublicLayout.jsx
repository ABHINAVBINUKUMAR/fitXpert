import { useState } from "react";
import { Link, Outlet } from "react-router-dom";
import { useAuth } from "../context/AuthContext";

const NAV_LINKS = [
  { name: "Home", path: "/" },
  { name: "Programs", path: "/programs" },
  { name: "Trainers", path: "/trainers-directory" },
  { name: "Pricing", path: "/pricing" }
];

export default function PublicLayout() {
  const [menuOpen, setMenuOpen] = useState(false);
  const { user } = useAuth();
  const scrolled = true; // For sticky nav effect on pages

  return (
    <div style={{ minHeight: "100vh", background: "#0a0a0a", color: "#f0f0f0" }}>
      <nav style={{ ...styles.nav, ...(scrolled ? styles.navScrolled : {}) }}>
        <div style={styles.navInner}>
          <Link to="/" style={styles.logo}>
            <span style={styles.logoMark}>⬡</span>
            <span style={styles.logoText}>FitXpert</span>
          </Link>
          <div style={styles.navLinks}>
            {NAV_LINKS.map((l) => (
              <Link key={l.name} to={l.path} style={styles.navLink} className="nav-link">
                {l.name}
              </Link>
            ))}
            <div style={{ display: "flex", gap: 12 }}>
              {user?.role === "user" ? (
                <Link to="/user/workout" style={{...styles.navCta, textDecoration: "none"}} className="btn-glow">My Portal</Link>
              ) : user?.role === "admin" ? (
                <Link to="/admin/dashboard" style={{...styles.navCta, textDecoration: "none", background: "#ff4444", color: "#fff"}} className="btn-glow">Admin Portal</Link>
              ) : (
                <>
                  <Link to="/login/member" style={{...styles.navCta, textDecoration: "none"}} className="btn-glow">Member Login</Link>
                  <Link to="/login/admin" style={{...styles.navCta, background: "#ff4444", color: "#fff", textDecoration: "none"}} className="btn-glow">Admin Login</Link>
                </>
              )}
            </div>
          </div>
          <button style={{...styles.burger, display: "none"}} onClick={() => setMenuOpen(!menuOpen)}>
            {menuOpen ? "✕" : "☰"}
          </button>
        </div>
      </nav>
      <Outlet />
    </div>
  );
}

const styles = {
  nav: { position: "fixed", top: 0, left: 0, right: 0, zIndex: 100, transition: "background 0.3s", padding: "0 24px" },
  navScrolled: { background: "rgba(10,10,10,0.96)", boxShadow: "0 1px 0 rgba(232,255,71,0.15)", backdropFilter: "blur(12px)" },
  navInner: { maxWidth: 1200, margin: "0 auto", display: "flex", alignItems: "center", justifyContent: "space-between", height: 72 },
  logo: { display: "flex", alignItems: "center", gap: 10, cursor: "pointer", textDecoration: "none" },
  logoMark: { fontSize: 28, color: "#e8ff47", lineHeight: 1 },
  logoText: { fontSize: 28, fontWeight: 800, letterSpacing: 6, color: "#fff", fontFamily: "'Barlow Condensed', sans-serif" },
  navLinks: { display: "flex", alignItems: "center", gap: 32 },
  navLink: { color: "#ccc", textDecoration: "none", fontSize: 15, letterSpacing: 2, fontWeight: 600, textTransform: "uppercase", transition: "color 0.2s" },
  navCta: { background: "#e8ff47", color: "#0a0a0a", border: "none", borderRadius: 4, padding: "10px 24px", fontWeight: 800, fontSize: 14, letterSpacing: 2, textTransform: "uppercase", cursor: "pointer" }
};
