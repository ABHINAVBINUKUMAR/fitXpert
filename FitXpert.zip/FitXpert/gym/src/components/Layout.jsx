import { Outlet } from "react-router-dom";
import Sidebar from "./Sidebar";
import ChatWidget from "./ChatWidget";

export default function Layout() {
  return (
    <div style={{ display: "flex", minHeight: "100vh", background: "#0a0a0a", color: "#f0f0f0" }}>
      <Sidebar />
      <div style={{ flex: 1, marginLeft: 260 }}>
        {/* Main Content Area */}
        <div style={{ padding: "40px 60px", maxWidth: 1600, margin: "0 auto" }}>
          <Outlet />
        </div>
      </div>
      <ChatWidget />
    </div>
  );
}
