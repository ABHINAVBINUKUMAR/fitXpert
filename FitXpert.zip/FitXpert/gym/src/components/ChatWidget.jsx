import { useState, useRef, useEffect } from "react";
import { MessageSquare, X, Send } from "lucide-react";

export default function ChatWidget() {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState([
    { text: "Hi! I am the FitXpert AI. How can I help you today?", isBot: true, time: new Date().toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'}) }
  ]);
  const [input, setInput] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const scrollRef = useRef(null);

  useEffect(() => {
    if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
  }, [messages, isTyping]);

  const QA_PAIRS = [
    { keywords: ["days", "how many", "train"], answer: "For general fitness, 3-4 days a week is ideal. If you want to build major muscle, aim for 5-6 days with a solid split!" },
    { keywords: ["eat", "before", "workout", "pre"], answer: "A mix of simple carbs and moderate protein 1-2 hours before is best. Think a banana with peanut butter or a small bowl of oats!" },
    { keywords: ["protein", "powder", "supplement"], answer: "Protein powder is great for convenience, but you can get all your protein from real food. Aim for 1.6-2.2g per kg of body weight!" },
    { keywords: ["timings", "time", "open"], answer: "We are open 24/7! The front desk is staffed from 6AM to 10PM daily." },
    { keywords: ["lose weight", "weight loss", "fat"], answer: "For weight loss, prioritize a slight caloric deficit (300-500 cals), strength training to maintain muscle, and 2-3 sessions of cardio per week." },
    { keywords: ["knee pain", "injury", "hurt"], answer: "If you have knee pain, avoid high-impact jumping and deep loaded squats. Ice it, rest, and consult a physical therapist if pain persists!" },
    { keywords: ["book", "trainer"], answer: "You can book a trainer easily by going to the Trainers tab on the left sidebar and clicking 'Book Session'!" },
    { keywords: ["lat pulldown", "equipment"], answer: "For the lat pulldown: sit tall, grab the bar slightly wider than shoulder-width, and pull down to your upper chest while squeezing your shoulder blades together." }
  ];

  const handleSend = () => {
    if (!input.trim()) return;
    const userMsg = input.trim();
    setMessages(prev => [...prev, { text: userMsg, isBot: false, time: new Date().toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'}) }]);
    setInput("");
    setIsTyping(true);

    setTimeout(() => {
      let botAnswer = "I'm not exactly sure, but I am learning every day! Try asking me about workouts, diet, or booking a trainer.";
      const lowerInput = userMsg.toLowerCase();
      
      for (const qa of QA_PAIRS) {
        if (qa.keywords.some(kw => lowerInput.includes(kw))) {
          botAnswer = qa.answer;
          break;
        }
      }

      setMessages(prev => [...prev, { text: botAnswer, isBot: true, time: new Date().toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'}) }]);
      setIsTyping(false);
    }, 1200);
  };

  return (
    <>
      <button 
        style={styles.fab} 
        onClick={() => setIsOpen(true)}
        className="btn-glow"
      >
        <MessageSquare size={26} />
      </button>

      {isOpen && (
        <div style={styles.panel} className="card chat-panel">
          <div style={styles.header}>
            <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
              <div style={styles.avatar}>🤖</div>
              <div>
                <h3 style={{ fontSize: 18, fontWeight: 700, margin: 0, textTransform: "uppercase" }}>FitXpert AI</h3>
                <span style={{ fontSize: 12, color: "#e8ff47" }}>● Online</span>
              </div>
            </div>
            <button style={styles.closeBtn} onClick={() => setIsOpen(false)}>
              <X size={20} />
            </button>
          </div>
          
          <div style={styles.chatArea} ref={scrollRef}>
            <div style={styles.chipsRow}>
              {["Workout Plan?", "Protein Intake?", "Gym Timings?"].map(chip => (
                <button key={chip} style={styles.chip} onClick={() => setInput(chip)}>{chip}</button>
              ))}
            </div>

            {messages.map((m, i) => (
              <div key={i} style={{ ...styles.msgRow, justifyContent: m.isBot ? "flex-start" : "flex-end" }}>
                {m.isBot && <div style={styles.msgAvatar}>🤖</div>}
                <div style={{...styles.msgBubble, background: m.isBot ? "#222" : "#e8ff47", color: m.isBot ? "#fff" : "#000"}}>
                  <div style={styles.msgText}>{m.text}</div>
                  <div style={{...styles.msgTime, color: m.isBot ? "rgba(255,255,255,0.4)" : "rgba(0,0,0,0.5)"}}>
                    {m.time}
                  </div>
                </div>
              </div>
            ))}
            {isTyping && (
              <div style={{ ...styles.msgRow, justifyContent: "flex-start" }}>
                <div style={styles.msgAvatar}>🤖</div>
                <div style={{...styles.msgBubble, background: "#222", color: "#fff"}}>
                  <div style={styles.typingDots}>
                    <span className="dot">.</span><span className="dot">.</span><span className="dot">.</span>
                  </div>
                </div>
              </div>
            )}
          </div>

          <div style={styles.inputArea}>
            <input 
              value={input}
              onChange={e => setInput(e.target.value)}
              onKeyDown={e => e.key === "Enter" && handleSend()}
              placeholder="Ask me anything..."
              style={styles.input}
            />
            <button onClick={handleSend} style={styles.sendBtn} className="btn-glow">
              <Send size={18} />
            </button>
          </div>
        </div>
      )}

      <style>{`
        .dot { animation: typing 1.4s infinite; display: inline-block; font-family: sans-serif; }
        .dot:nth-child(2) { animation-delay: 0.2s; }
        .dot:nth-child(3) { animation-delay: 0.4s; }
        @keyframes typing {
          0%, 100% { transform: translateY(0); opacity: 0.4; }
          50% { transform: translateY(-4px); opacity: 1; }
        }
        .chat-panel {
          animation: slideUp 0.3s cubic-bezier(0.16, 1, 0.3, 1);
        }
        @keyframes slideUp {
          from { opacity: 0; transform: translateY(20px) scale(0.95); }
          to { opacity: 1; transform: translateY(0) scale(1); }
        }
      `}</style>
    </>
  );
}

const styles = {
  fab: {
    position: "fixed",
    bottom: 32,
    right: 32,
    width: 68,
    height: 68,
    borderRadius: 34,
    background: "#e8ff47",
    color: "#0a0a0a",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    border: "none",
    cursor: "pointer",
    zIndex: 9999,
  },
  panel: {
    position: "fixed",
    bottom: 110,
    right: 32,
    width: 400,
    height: 580,
    display: "flex",
    flexDirection: "column",
    overflow: "hidden",
    zIndex: 9999,
    boxShadow: "0 24px 48px rgba(0,0,0,0.5)",
  },
  header: {
    background: "#1a1a1a",
    padding: "20px",
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
    borderBottom: "1px solid rgba(255,255,255,0.05)",
  },
  avatar: { width: 44, height: 44, background: "#333", borderRadius: 22, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 24 },
  closeBtn: { background: "none", border: "none", color: "#fff", cursor: "pointer", opacity: 0.6 },
  chatArea: {
    flex: 1,
    padding: "20px",
    overflowY: "auto",
    display: "flex",
    flexDirection: "column",
    gap: 16,
    background: "#0a0a0a",
  },
  chipsRow: { display: "flex", gap: 8, overflowX: "auto", paddingBottom: 8, flexShrink: 0 },
  chip: { background: "rgba(232,255,71,0.1)", border: "1px solid rgba(232,255,71,0.3)", borderRadius: 100, padding: "6px 14px", color: "#e8ff47", fontSize: 13, fontWeight: 600, cursor: "pointer", whiteSpace: "nowrap", fontFamily: "'Inter', sans-serif" },
  msgRow: { display: "flex", alignItems: "flex-end", gap: 10 },
  msgAvatar: { width: 32, height: 32, background: "#333", borderRadius: 16, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 16, flexShrink: 0 },
  msgBubble: {
    padding: "12px 16px",
    borderRadius: 16,
    maxWidth: "80%",
  },
  msgText: { fontSize: 15, fontFamily: "'Inter', sans-serif", lineHeight: 1.5 },
  msgTime: { fontSize: 10, marginTop: 4, textAlign: "right", fontFamily: "'Inter', sans-serif" },
  inputArea: {
    padding: "16px",
    background: "#1a1a1a",
    display: "flex",
    gap: 12,
    borderTop: "1px solid rgba(255,255,255,0.05)",
  },
  input: {
    flex: 1,
    background: "#0a0a0a",
    border: "1px solid rgba(255,255,255,0.1)",
    borderRadius: 8,
    padding: "0 16px",
    color: "#fff",
    outline: "none",
    fontFamily: "'Inter', sans-serif",
  },
  sendBtn: {
    width: 48,
    height: 48,
    background: "#e8ff47",
    color: "#000",
    border: "none",
    borderRadius: 8,
    cursor: "pointer",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
  },
  typingDots: { fontSize: 28, lineHeight: 0.5, color: "#e8ff47", letterSpacing: 2, padding: "0 4px" }
};
