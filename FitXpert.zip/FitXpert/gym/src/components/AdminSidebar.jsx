import { NavLink } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import { 
  BarChart2, Users, UserCog, Wrench, ClipboardList, 
  Apple, Calendar, IndianRupee, Trophy, Settings, LogOut
} from "lucide-react";

const NAV_ITEMS = [
  { path: "/admin/dashboard", name: "Dashboard", icon: <BarChart2 size={20} /> },
  { path: "/admin/members", name: "Members", icon: <Users size={20} /> },
  { path: "/admin/trainers", name: "Trainers", icon: <UserCog size={20} /> },
  { path: "/admin/equipment", name: "Equipment", icon: <Wrench size={20} /> },
  { path: "/admin/workout-plans", name: "Workout Plans", icon: <ClipboardList size={20} /> },
  { path: "/admin/diet-plans", name: "Diet Plans", icon: <Apple size={20} /> },
  { path: "/admin/attendance", name: "Attendance Logs", icon: <Calendar size={20} /> },
  { path: "/admin/revenue", name: "Revenue", icon: <IndianRupee size={20} /> },
  { path: "/admin/gamification", name: "Gamification", icon: <Trophy size={20} /> },
  { path: "/admin/settings", name: "Settings", icon: <Settings size={20} /> },
];

export default function AdminSidebar() {
  const { logout } = useAuth();

  return (
    <div style={styles.sidebar}>
      <NavLink to="/" style={styles.logo}>
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          <span style={styles.logoMark}>⬡</span>
          <span style={styles.logoText}>FITXPERT</span>
        </div>
        <div style={styles.adminBadge}>ADMIN</div>
      </NavLink>
      
      <div style={styles.profileBox}>
        <div style={styles.avatar}>A</div>
        <div>
          <div style={styles.welcome}>Admin User</div>
          <div style={styles.badge}>SUPER ADMIN</div>
        </div>
      </div>

      <nav style={styles.nav}>
        {NAV_ITEMS.map((item) => (
          <NavLink 
            key={item.path} 
            to={item.path}
            className={({ isActive }) => (isActive ? 'active-link' : 'default-link')}
            style={({ isActive }) => ({
              ...styles.link,
              ...(isActive ? styles.linkActive : {}),
            })}
          >
            {item.icon}
            <span>{item.name}</span>
          </NavLink>
        ))}
      </nav>
      
      <div style={{ marginTop: "auto", borderTop: "1px solid rgba(255,255,255,0.06)", paddingTop: 24 }}>
        <button onClick={logout} style={styles.logoutBtn}>
          <LogOut size={18} /> Secure Logout
        </button>
      </div>
    </div>
  );
}

const styles = {
  sidebar: { width: 260, background: "#050000", borderRight: "1px solid rgba(255,68,68,0.1)", height: "100vh", display: "flex", flexDirection: "column", padding: "24px", position: "fixed", left: 0, top: 0, zIndex: 100 },
  logo: { display: "flex", flexDirection: "column", gap: 4, marginBottom: 24, textDecoration: "none" },
  logoMark: { fontSize: 24, color: "#ff4444", lineHeight: 1 },
  logoText: { fontSize: 24, fontWeight: 900, letterSpacing: 2, color: "#fff", fontFamily: "'Barlow Condensed', sans-serif" },
  adminBadge: { background: "#ff4444", color: "#000", padding: "2px 8px", borderRadius: 4, fontSize: 10, fontWeight: 900, letterSpacing: 2, display: "inline-block", width: "fit-content" },
  profileBox: { display: "flex", alignItems: "center", gap: 12, padding: "16px", background: "rgba(255,68,68,0.05)", borderRadius: 12, marginBottom: 24, border: "1px solid rgba(255,68,68,0.2)" },
  avatar: { width: 40, height: 40, borderRadius: 20, background: "#ff4444", color: "#000", display: "flex", alignItems: "center", justifyContent: "center", fontWeight: 900, fontSize: 18 },
  welcome: { fontSize: 13, color: "rgba(255,255,255,0.8)", fontWeight: 700, fontFamily: "Inter" },
  badge: { fontSize: 10, background: "#ff4444", color: "#000", padding: "2px 6px", borderRadius: 4, fontWeight: 900, marginTop: 4, display: "inline-block" },
  nav: { display: "flex", flexDirection: "column", gap: 8, overflowY: "auto", paddingRight: 8 },
  link: { display: "flex", alignItems: "center", gap: 16, padding: "12px 16px", borderRadius: 8, color: "rgba(255,255,255,0.6)", textDecoration: "none", fontSize: 15, fontWeight: 700, letterSpacing: 1, textTransform: "uppercase", transition: "all 0.2s" },
  linkActive: { background: "rgba(255,68,68,0.1)", color: "#ff4444", boxShadow: "inset 4px 0 0 #ff4444" },
  logoutBtn: { width: "100%", background: "transparent", color: "rgba(255,255,255,0.6)", border: "1px solid rgba(255,255,255,0.1)", padding: "14px", borderRadius: 8, display: "flex", alignItems: "center", gap: 12, fontSize: 14, fontWeight: 800, textTransform: "uppercase", cursor: "pointer", transition: "all 0.2s" }
};
