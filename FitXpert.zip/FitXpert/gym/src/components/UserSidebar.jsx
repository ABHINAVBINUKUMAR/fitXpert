import { NavLink } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import { 
  Home, Bot, CalendarCheck, Dumbbell, 
  Utensils, Users, Trophy, CreditCard, User, LogOut
} from "lucide-react";

const NAV_ITEMS = [
  { path: "/", name: "Home", icon: <Home size={20} /> },
  { path: "/user/chat", name: "AI Assistant", icon: <Bot size={20} /> },
  { path: "/user/attendance", name: "Attendance", icon: <CalendarCheck size={20} /> },
  { path: "/user/workout", name: "My Workout", icon: <Dumbbell size={20} /> },
  { path: "/user/diet", name: "My Diet", icon: <Utensils size={20} /> },
  { path: "/user/trainers", name: "Book Trainer", icon: <Users size={20} /> },
  { path: "/user/achievements", name: "Achievements", icon: <Trophy size={20} /> },
  { path: "/user/payments", name: "Payments", icon: <CreditCard size={20} /> },
  { path: "/user/profile", name: "Profile", icon: <User size={20} /> },
];

export default function UserSidebar() {
  const { logout } = useAuth();

  return (
    <div style={styles.sidebar}>
      <NavLink to="/" style={styles.logo}>
        <span style={styles.logoMark}>⬡</span>
        <span style={styles.logoText}>FITXPERT</span>
      </NavLink>
      
      <div style={styles.profileBox}>
        <div style={styles.avatar}>M</div>
        <div>
          <div style={styles.welcome}>Welcome, Member</div>
          <div style={styles.badge}>PRO PLAN</div>
        </div>
      </div>

      <nav style={styles.nav}>
        {NAV_ITEMS.map((item) => (
          <NavLink 
            key={item.path} 
            to={item.path}
            className={({ isActive }) => (isActive ? 'active-link' : 'default-link')}
            style={({ isActive }) => ({
              ...styles.link,
              ...(isActive ? styles.linkActive : {}),
            })}
          >
            {item.icon}
            <span>{item.name}</span>
          </NavLink>
        ))}
      </nav>
      
      <div style={{ marginTop: "auto", borderTop: "1px solid rgba(255,255,255,0.06)", paddingTop: 24 }}>
        <button onClick={logout} style={styles.logoutBtn}>
          <LogOut size={18} /> Secure Logout
        </button>
      </div>
    </div>
  );
}

const styles = {
  sidebar: { width: 260, background: "#080808", borderRight: "1px solid rgba(255,255,255,0.06)", height: "100vh", display: "flex", flexDirection: "column", padding: "24px", position: "fixed", left: 0, top: 0, zIndex: 100 },
  logo: { display: "flex", alignItems: "center", gap: 10, marginBottom: 24, textDecoration: "none" },
  logoMark: { fontSize: 28, color: "#e8ff47", lineHeight: 1 },
  logoText: { fontSize: 28, fontWeight: 900, letterSpacing: 3, color: "#fff", fontFamily: "'Barlow Condensed', sans-serif" },
  profileBox: { display: "flex", alignItems: "center", gap: 12, padding: "16px", background: "rgba(232,255,71,0.05)", borderRadius: 12, marginBottom: 32, border: "1px solid rgba(232,255,71,0.1)" },
  avatar: { width: 40, height: 40, borderRadius: 20, background: "#e8ff47", color: "#000", display: "flex", alignItems: "center", justifyContent: "center", fontWeight: 900, fontSize: 18 },
  welcome: { fontSize: 13, color: "rgba(255,255,255,0.8)", fontWeight: 700, fontFamily: "Inter" },
  badge: { fontSize: 10, background: "#e8ff47", color: "#000", padding: "2px 6px", borderRadius: 4, fontWeight: 900, marginTop: 4, display: "inline-block" },
  nav: { display: "flex", flexDirection: "column", gap: 8, overflowY: "auto", paddingRight: 8 },
  link: { display: "flex", alignItems: "center", gap: 16, padding: "12px 16px", borderRadius: 8, color: "rgba(255,255,255,0.6)", textDecoration: "none", fontSize: 15, fontWeight: 700, letterSpacing: 1, textTransform: "uppercase", transition: "all 0.2s" },
  linkActive: { background: "rgba(232,255,71,0.1)", color: "#e8ff47", boxShadow: "inset 4px 0 0 #e8ff47" },
  logoutBtn: { width: "100%", background: "transparent", color: "#ff4747", border: "1px solid rgba(255,71,71,0.2)", padding: "14px", borderRadius: 8, display: "flex", alignItems: "center", gap: 12, fontSize: 14, fontWeight: 800, textTransform: "uppercase", cursor: "pointer", transition: "all 0.2s" }
};
