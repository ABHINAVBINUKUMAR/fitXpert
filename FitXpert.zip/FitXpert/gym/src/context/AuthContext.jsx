import { createContext, useContext, useState, useEffect } from "react";
import { apiFetch } from "../lib/api";

const AuthContext = createContext();

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const syncSession = async () => {
      const token = localStorage.getItem("fitxpert_token");
      if (!token) {
        setUser(null);
        setLoading(false);
        return;
      }

      try {
        const response = await apiFetch("/user");
        setUser(response.user);
      } catch (error) {
        localStorage.removeItem("fitxpert_token");
        setUser(null);
      } finally {
        setLoading(false);
      }
    };

    syncSession();
  }, []);

  const login = async (emailOrUser, password) => {
    const payload = typeof emailOrUser === "string"
      ? { email: emailOrUser, password }
      : emailOrUser;

    const response = await apiFetch("/login", {
      method: "POST",
      body: payload,
    });

    localStorage.setItem("fitxpert_token", response.token);
    setUser(response.user);
    return response.user;
  };

  const register = async (payload) => {
    const response = await apiFetch("/register", {
      method: "POST",
      body: payload,
    });

    localStorage.setItem("fitxpert_token", response.token);
    setUser(response.user);
    return response.user;
  };

  const logout = async () => {
    try {
      await apiFetch("/logout", { method: "POST" });
    } catch (error) {
      // ignore logout failure and clear local state
    }

    localStorage.removeItem("fitxpert_token");
    setUser(null);
  };

  return (
    <AuthContext.Provider value={{ user, login, register, logout, loading }}>
      {!loading && children}
    </AuthContext.Provider>
  );
}

export const useAuth = () => useContext(AuthContext);
