import { BrowserRouter as Router, Routes, Route, Outlet, Navigate } from "react-router-dom";
import { AuthProvider } from "./context/AuthContext";
import { UserRoute, AdminRoute } from "./components/ProtectedRoute";

import Home from "./pages/Home";
import Programs from "./pages/Programs";
import TrainersDirectory from "./pages/TrainersDirectory";
import Pricing from "./pages/Pricing";
import PublicLayout from "./components/PublicLayout";
import MemberLogin from "./pages/MemberLogin";
import Register from "./pages/Register";
import AdminLogin from "./pages/AdminLogin";

import UserSidebar from "./components/UserSidebar";
import AdminSidebar from "./components/AdminSidebar";
import ChatWidget from "./components/ChatWidget";

// Existing Pages
import Dashboard from "./pages/user/Dashboard";
import Achievements from "./pages/user/Achievements";
import Attendance from "./pages/user/Attendance";
import WorkoutGenerator from "./pages/user/Workout";
import Diet from "./pages/user/Diet";
import Trainers from "./pages/user/Trainers";
import Equipment from "./pages/admin/Equipment";
import Payments from "./pages/user/Payments";
import Profile from "./pages/user/Profile";
import Chat from "./pages/user/Chat";

// Admin Pages
import AdminDashboard from "./pages/admin/Dashboard";
import AdminMembers from "./pages/admin/Members";
import AdminTrainers from "./pages/admin/Trainers";
import AdminWorkoutPlans from "./pages/admin/WorkoutPlans";
import AdminDietPlans from "./pages/admin/DietPlans";
import AdminAttendanceLogs from "./pages/admin/AttendanceLogs";
import AdminRevenue from "./pages/admin/Revenue";
import AdminGamification from "./pages/admin/Gamification";
import AdminSettings from "./pages/admin/Settings";

import "./index.css";

const MockPage = ({ title }) => (
  <div>
    <h1 style={{ fontSize: 48, textTransform: "uppercase", fontWeight: 900, marginBottom: 40, letterSpacing: -1 }}>
      {title}
    </h1>
    <div className="card" style={{ padding: 60, textAlign: "center", color: "rgba(255,255,255,0.4)", fontSize: 18 }}>
      Content for <strong style={{ color: "#fff" }}>{title}</strong> coming soon.
    </div>
  </div>
);

function UserLayout() {
  return (
    <div style={{ display: "flex", minHeight: "100vh", background: "#0a0a0a", color: "#f0f0f0" }}>
      <UserSidebar />
      <div style={{ flex: 1, marginLeft: 260 }}>
        <div style={{ padding: "40px 60px", width: "100%" }}>
          <Outlet />
        </div>
      </div>
      <ChatWidget />
    </div>
  );
}

function AdminLayout() {
  return (
    <div style={{ display: "flex", minHeight: "100vh", background: "#050000", color: "#f0f0f0" }}>
      <AdminSidebar />
      <div style={{ flex: 1, marginLeft: 400 }}>
        <div style={{ padding: "40px 60px", maxWidth: 1600, margin: "0 auto" }}>
          <Outlet />
        </div>
      </div>
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <Router>
        <Routes>
          {/* Public Routes with Layout */}
          <Route element={<PublicLayout />}>
            <Route path="/" element={<Home />} />
            <Route path="/programs" element={<Programs />} />
            <Route path="/trainers-directory" element={<TrainersDirectory />} />
            <Route path="/pricing" element={<Pricing />} />
          </Route>

          {/* Independent Public Routes */}
          <Route path="/login" element={<MemberLogin />} />
          <Route path="/login/member" element={<MemberLogin />} />
          <Route path="/register" element={<Register />} />
          <Route path="/login/admin" element={<AdminLogin />} />

          {/* User Protected Routes */}
          <Route element={<UserRoute />}>
            <Route path="/user" element={<UserLayout />}>
              <Route path="dashboard" element={<Navigate to="/" replace />} />
              <Route path="chat" element={<Chat />} />
              <Route path="attendance" element={<Attendance />} />
              <Route path="workout" element={<WorkoutGenerator />} />
              <Route path="diet" element={<Diet />} />
              <Route path="trainers" element={<Trainers />} />
              <Route path="achievements" element={<Achievements />} />
              <Route path="payments" element={<Payments />} />
              <Route path="profile" element={<Profile />} />
            </Route>
          </Route>

          {/* Admin Protected Routes */}
          <Route element={<AdminRoute />}>
            <Route path="/admin" element={<AdminLayout />}>
              <Route path="dashboard" element={<AdminDashboard />} />
              <Route path="members" element={<AdminMembers />} />
              <Route path="trainers" element={<AdminTrainers />} />
              <Route path="equipment" element={<Equipment />} />
              <Route path="workout-plans" element={<AdminWorkoutPlans />} />
              <Route path="diet-plans" element={<AdminDietPlans />} />
              <Route path="attendance" element={<AdminAttendanceLogs />} />
              <Route path="revenue" element={<AdminRevenue />} />
              <Route path="gamification" element={<AdminGamification />} />
              <Route path="settings" element={<AdminSettings />} />
            </Route>
          </Route>
        </Routes>
      </Router>
    </AuthProvider>
  );
}
