import { useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import { Mail, Lock, User, ShieldAlert, CheckCircle2 } from "lucide-react";
import { useAuth } from "../context/AuthContext";

export default function MemberLogin() {
  const navigate = useNavigate();
  const { login, register } = useAuth();
  const [view, setView] = useState("login"); // 'login' or 'signup'
  const [formData, setFormData] = useState({ name: "", email: "", password: "", confirm: "" });
  const [error, setError] = useState("");
  const [success, setSuccess] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");

    if (view === "login") {
      if (!formData.email || !formData.password) return setError("Please fill all fields.");

      try {
        const user = await login(formData.email, formData.password);
        if (user.role === "admin") {
          navigate("/admin/dashboard");
          return;
        }
        navigate("/user/dashboard");
      } catch (err) {
        setError(err.message || "Login failed.");
      }
      return;
    }

    if (!formData.name || !formData.email || !formData.password || !formData.confirm) return setError("Please fill all fields.");
    if (formData.password !== formData.confirm) return setError("Passwords do not match.");
    if (formData.password.length < 6) return setError("Password must be at least 6 characters.");

    try {
      setSuccess(true);
      await register({
        name: formData.name,
        email: formData.email,
        password: formData.password,
        password_confirmation: formData.confirm,
      });
      navigate("/user/dashboard");
    } catch (err) {
      setSuccess(false);
      setError(err.message || "Unable to create account.");
    }
  };

  return (
    <div style={{ minHeight: "100vh", background: "#0a0a0a", display: "flex", alignItems: "center", justifyContent: "center", padding: 24, position: "relative" }}>
      <div style={{ position: "absolute", width: "50vw", height: "50vw", background: "radial-gradient(circle, rgba(232,255,71,0.04) 0%, transparent 70%)", top: "50%", left: "-20%", transform: "translateY(-50%)", zIndex: 0 }} />
      
      <div className="card" style={{ width: "100%", maxWidth: 480, padding: 48, position: "relative", zIndex: 1 }}>
        <div style={{ textAlign: "center", marginBottom: 32 }}>
          <div style={{ fontSize: 40, color: "#e8ff47", marginBottom: 16 }}>⬡</div>
          <h1 style={{ fontSize: 32, textTransform: "uppercase", fontWeight: 900, color: "#fff", margin: 0, letterSpacing: 1 }}>
             {view === "login" ? "Welcome Back" : "Join FitXpert"}
          </h1>
          <div style={{ display: "inline-block", background: "rgba(232,255,71,0.1)", color: "#e8ff47", padding: "4px 12px", borderRadius: 100, fontSize: 12, fontWeight: 800, textTransform: "uppercase", letterSpacing: 1, marginTop: 12 }}>
             🟡 Member Portal
          </div>
        </div>

        {success ? (
          <div style={{ textAlign: "center", animation: "fadeIn 0.5s ease" }}>
             <div style={{ display: "inline-flex", background: "rgba(232,255,71,0.1)", borderRadius: 100, padding: 24, marginBottom: 24, border: "1px solid rgba(232,255,71,0.3)" }}><CheckCircle2 size={64} color="#e8ff47" /></div>
            <h2 style={{ fontSize: 24, fontWeight: 900, color: "#fff", textTransform: "uppercase" }}>Registration Successful</h2>
            <p style={{ color: "rgba(255,255,255,0.6)", marginTop: 8 }}>Logging you in...</p>
          </div>
        ) : (
          <>
            <div style={{ display: "flex", gap: 8, marginBottom: 32, background: "rgba(255,255,255,0.05)", padding: 6, borderRadius: 8 }}>
              <button type="button" onClick={() => { setView("login"); setError(""); }} style={{ flex: 1, background: view === "login" ? "#1a1a1a" : "transparent", color: view === "login" ? "#fff" : "rgba(255,255,255,0.5)", border: "1px solid", borderColor: view === "login" ? "rgba(255,255,255,0.1)" : "transparent", padding: "12px", borderRadius: 6, fontSize: 14, fontWeight: 800, textTransform: "uppercase", cursor: "pointer", transition: "all 0.2s" }}>Log In</button>
              <button type="button" onClick={() => { setView("signup"); setError(""); }} style={{ flex: 1, background: view === "signup" ? "#1a1a1a" : "transparent", color: view === "signup" ? "#fff" : "rgba(255,255,255,0.5)", border: "1px solid", borderColor: view === "signup" ? "rgba(255,255,255,0.1)" : "transparent", padding: "12px", borderRadius: 6, fontSize: 14, fontWeight: 800, textTransform: "uppercase", cursor: "pointer", transition: "all 0.2s" }}>Sign Up</button>
            </div>

            {error && (
              <div style={{ background: "rgba(255,71,71,0.1)", border: "1px solid rgba(255,71,71,0.3)", padding: "12px 16px", borderRadius: 8, color: "#ff4747", fontSize: 14, fontWeight: 700, marginBottom: 24, display: "flex", alignItems: "center", gap: 10 }}>
                <ShieldAlert size={18} /> {error}
              </div>
            )}

            <form onSubmit={handleSubmit} style={{ display: "flex", flexDirection: "column", gap: 20 }}>
              {view === "signup" && (
                <div style={styles.formGroup}>
                  <label style={styles.label}>Full Name</label>
                  <div style={{ position: "relative" }}>
                    <User size={20} color="rgba(255,255,255,0.3)" style={{ position: "absolute", left: 16, top: "50%", transform: "translateY(-50%)" }} />
                    <input type="text" value={formData.name} onChange={e => setFormData({...formData, name: e.target.value})} placeholder="John Doe" style={{...styles.input, paddingLeft: 48}} />
                  </div>
                </div>
              )}

              <div style={styles.formGroup}>
                <label style={styles.label}>Email Address</label>
                <div style={{ position: "relative" }}>
                  <Mail size={20} color="rgba(255,255,255,0.3)" style={{ position: "absolute", left: 16, top: "50%", transform: "translateY(-50%)" }} />
                  <input type="email" value={formData.email} onChange={e => setFormData({...formData, email: e.target.value})} placeholder="you@example.com" style={{...styles.input, paddingLeft: 48}} />
                </div>
              </div>

              <div style={view === "signup" ? { display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16 } : {}}>
                <div style={styles.formGroup}>
                  <label style={styles.label}>Password</label>
                  <div style={{ position: "relative" }}>
                    <Lock size={20} color="rgba(255,255,255,0.3)" style={{ position: "absolute", left: 16, top: "50%", transform: "translateY(-50%)" }} />
                    <input type="password" value={formData.password} onChange={e => setFormData({...formData, password: e.target.value})} placeholder="••••••••" style={{...styles.input, paddingLeft: 48}} />
                  </div>
                </div>
                
                {view === "signup" && (
                  <div style={styles.formGroup}>
                    <label style={styles.label}>Confirm</label>
                    <div style={{ position: "relative" }}>
                      <Lock size={20} color="rgba(255,255,255,0.3)" style={{ position: "absolute", left: 16, top: "50%", transform: "translateY(-50%)" }} />
                      <input type="password" value={formData.confirm} onChange={e => setFormData({...formData, confirm: e.target.value})} placeholder="••••••••" style={{...styles.input, paddingLeft: 48}} />
                    </div>
                  </div>
                )}
              </div>
              
              <button type="submit" className="btn-glow" style={{ ...styles.submitBtn, marginTop: 16 }}>
                 {view === "login" ? "Login" : "Create Account"}
              </button>
            </form>
          </>
        )}
      </div>

      <Link to="/login/admin" style={{ position: "absolute", bottom: 40, color: "rgba(255,255,255,0.4)", textDecoration: "none", fontWeight: 700, fontSize: 13, textTransform: "uppercase", letterSpacing: 2 }}>
        Admin Access
      </Link>
    </div>
  );
}

const styles = {
  formGroup: { display: "flex", flexDirection: "column", gap: 10 },
  label: { fontSize: 13, textTransform: "uppercase", letterSpacing: 1, color: "rgba(255,255,255,0.6)", fontWeight: 800 },
  input: { width: "100%", background: "#050505", border: "1px solid rgba(255,255,255,0.15)", color: "#fff", padding: "16px 20px", borderRadius: 8, fontSize: 16, fontFamily: "Inter", outline: "none", transition: "border-color 0.2s", boxSizing: "border-box" },
  submitBtn: { background: "#e8ff47", color: "#000", border: "none", padding: "20px", borderRadius: 8, fontSize: 16, fontWeight: 900, textTransform: "uppercase", letterSpacing: 2, cursor: "pointer", width: "100%" }
};
