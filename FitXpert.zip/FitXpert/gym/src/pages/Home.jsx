import { useState, useEffect, useRef } from "react";
import { Link, useNavigate } from "react-router-dom";
import { SplineSceneBasic } from "@/components/ui/demo";
import { useAuth } from "../context/AuthContext";

const STATS = [
  { num: "12K+", label: "Active Members" },
  { num: "98%", label: "Retention Rate" },
  { num: "50+", label: "Expert Trainers" },
  { num: "15", label: "Years of Mastery" },
];

function useIntersection(threshold = 0.15) {
  const ref = useRef(null);
  const [visible, setVisible] = useState(false);
  useEffect(() => {
    const obs = new IntersectionObserver(([e]) => { if (e.isIntersecting) { setVisible(true); obs.disconnect(); } }, { threshold });
    if (ref.current) obs.observe(ref.current);
    return () => obs.disconnect();
  }, [threshold]);
  return [ref, visible];
}

function AnimSection({ children, className = "", delay = 0, style = {} }) {
  const [ref, visible] = useIntersection();
  return (
    <div
      ref={ref}
      className={className}
      style={{
        opacity: visible ? 1 : 0,
        transform: visible ? "translateY(0)" : "translateY(40px)",
        transition: `opacity 0.75s ease ${delay}ms, transform 0.75s ease ${delay}ms`,
        ...style
      }}
    >
      {children}
    </div>
  );
}

export default function Home() {
  const navigate = useNavigate();
  const { user } = useAuth();

  const handleStartFreeTrial = () => {
    if (user) {
      navigate("/pricing");
      return;
    }

    navigate("/login/member");
  };

  return (
    <div style={styles.root}>
      {/* HERO */}
      <section style={styles.hero}>
        <div style={styles.heroBg}>
          <img src="https://images.unsplash.com/photo-1517838277536-f5f99be501cd?w=1800&q=90" alt="gym" style={styles.heroBgImg} />
          <div style={styles.heroOverlay} />
          <div style={styles.heroNoise} />
        </div>
        <div style={styles.heroContent}>
          <div style={styles.heroBadge} className="badge-pulse">
            <span style={{ color: "#e8ff47" }}>⚡</span> &nbsp;NOW OPEN — THIRUVANANTHAPURAM
          </div>
          <h1 style={styles.heroH1}>
            <span style={styles.heroLine1}>FITXPERT: YOUR</span><br />
            <span style={styles.heroLine2} className="gradient-text">LIMITS.</span>
          </h1>
          <p style={styles.heroSub}>
            Where elite athletes and everyday warriors come to be remade.
            <br />Science-backed. Coach-led. Zero excuses.
          </p>
          <div style={styles.heroActions}>
            <button type="button" onClick={handleStartFreeTrial} style={{ ...styles.heroPrimary, textDecoration: "none", display: "inline-block", border: "none" }} className="btn-glow">
              Start Free Trial
            </button>
            <button style={{ ...styles.heroSecondary, textDecoration: "none", display: "inline-block" }} className="btn-outline">
              ▶ &nbsp;Watch Film
            </button>
          </div>
          <div style={styles.heroScroll} className="scroll-bounce">
            <span>Scroll</span><span style={{ fontSize: 20 }}>↓</span>
          </div>
        </div>
      </section>

      {/* STATS TICKER */}
      <section style={styles.ticker}>
        <div style={styles.tickerInner} className="ticker-scroll">
          {[...STATS, ...STATS].map((s, i) => (
            <div key={i} style={styles.tickerItem}>
              <span style={styles.tickerNum}>{s.num}</span><span style={styles.tickerLabel}>{s.label}</span><span style={styles.tickerDot}>◆</span>
            </div>
          ))}
        </div>
      </section>

      {/* FEATURE SPLIT */}
      <section style={styles.split}>
        <div style={styles.splitImg}>
          <img src="https://images.unsplash.com/photo-1605296867304-46d5465a13f1?w=900&q=80" alt="training" style={{ width: "100%", height: "100%", objectFit: "cover" }} />
          <div style={styles.splitImgOverlay} />
          <div style={styles.splitBadgeFloat}>
            <div style={styles.splitBadgeNum}>4.9 ★</div>
            <div style={styles.splitBadgeTxt}>Member Rating</div>
          </div>
        </div>
        <div style={styles.splitContent}>
          <AnimSection>
            <div style={styles.sectionLabel}>— THE FITXPERT DIFFERENCE</div>
            <h2 style={{ ...styles.sectionH2, textAlign: "left" }}>
              Not a gym.<br /><span className="gradient-text">A system.</span>
            </h2>
            <p style={styles.splitText}>
              Every detail at FitXpert is engineered for transformation. From our biometric tracking to our 1:1 coaching ratio — we remove every obstacle between you and your peak.
            </p>
            <div style={styles.featureList}>
              {["AI-powered workout personalization", "Real-time form correction via smart mirrors", "Recovery pods & cold plunge therapy", "Certified nutritionist on-demand"].map((f, i) => (
                <div key={i} style={styles.featureItem}><span style={styles.featureCheck}>✓</span><span>{f}</span></div>
              ))}
            </div>
            <Link to="/programs" style={{ ...styles.heroPrimary, textDecoration: "none", display: "inline-block" }} className="btn-glow">Explore Programs</Link>
          </AnimSection>
        </div>
      </section>

      {/* 3D SPLINE SCENE */}
      <section style={{ padding: "80px 24px", background: "#050505", display: "flex", justifyContent: "center" }}>
        <div style={{ maxWidth: 1200, width: "100%" }}>
          <SplineSceneBasic />
        </div>
      </section>

      {/* CTA BANNER */}
      <section style={styles.ctaBanner}>
        <div style={styles.ctaBannerBg}>
          <img src="https://images.unsplash.com/photo-1526506118085-60ce8714f8c5?w=1600&q=80" alt="cta" style={{ width: "100%", height: "100%", objectFit: "cover" }} />
          <div style={styles.ctaOverlay} />
        </div>
        <AnimSection style={{ position: "relative", zIndex: 2 }}>
          <div style={styles.ctaContent}>
            <h2 style={styles.ctaH2}>The first rep is the hardest.<br /><span className="gradient-text">Take it today.</span></h2>
            <button type="button" onClick={handleStartFreeTrial} style={{ ...styles.heroPrimary, textDecoration: "none", display: "inline-block", border: "none" }} className="btn-glow">Claim Your Free Week</button>
          </div>
        </AnimSection>
      </section>

      {/* FOOTER */}
      <footer style={styles.footer}>
        <div style={styles.footerTop}>
          <div style={styles.logo}>
            <span style={styles.logoMark}>⬡</span>
            <span style={styles.logoText}>FITXPERT</span>
          </div>
          <div style={styles.footerLinks}>
            {["Instagram", "YouTube", "Twitter", "Strava"].map((s) => (
              <a key={s} href="#" style={styles.footerLink} className="nav-link">{s}</a>
            ))}
          </div>
        </div>
        <div style={styles.footerBottom}>
          <span>© 2026 FitXpert. All rights reserved.</span>
          <span>Thiruvananthapuram, Kerala, India</span>
        </div>
      </footer>
    </div>
  );
}

const styles = {
  root: { fontFamily: "'Barlow Condensed', 'Oswald', sans-serif", background: "#0a0a0a", color: "#f0f0f0", overflowX: "hidden", minHeight: "100vh" },
  logo: { display: "flex", alignItems: "center", gap: 10, cursor: "pointer" },
  logoMark: { fontSize: 28, color: "#e8ff47", lineHeight: 1 },
  logoText: { fontSize: 28, fontWeight: 800, letterSpacing: 6, color: "#fff", fontFamily: "'Barlow Condensed', sans-serif" },
  hero: { position: "relative", minHeight: "100vh", display: "flex", alignItems: "center", justifyContent: "center", overflow: "hidden" },
  heroBg: { position: "absolute", inset: 0 },
  heroBgImg: { width: "100%", height: "100%", objectFit: "cover", filter: "brightness(0.45)" },
  heroOverlay: { position: "absolute", inset: 0, background: "linear-gradient(to bottom, rgba(10,10,10,0.5) 0%, transparent 40%, rgba(10,10,10,0.9) 100%)" },
  heroNoise: { position: "absolute", inset: 0, backgroundImage: "url(\"data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noise'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noise)' opacity='0.04'/%3E%3C/svg%3E\")", opacity: 0.4, pointerEvents: "none" },
  heroContent: { position: "relative", zIndex: 2, textAlign: "center", maxWidth: 900, padding: "0 24px", paddingTop: 80 },
  heroBadge: { display: "inline-flex", alignItems: "center", background: "rgba(232,255,71,0.12)", border: "1px solid rgba(232,255,71,0.3)", borderRadius: 100, padding: "8px 20px", fontSize: 13, letterSpacing: 2, fontWeight: 700, color: "#e8ff47", marginBottom: 32, textTransform: "uppercase" },
  heroH1: { fontSize: "clamp(64px, 12vw, 140px)", fontWeight: 900, lineHeight: 0.9, textTransform: "uppercase", letterSpacing: -2, margin: "0 0 28px" },
  heroLine1: { color: "#fff" },
  heroLine2: { display: "inline-block" },
  heroSub: { fontSize: "clamp(15px, 2vw, 20px)", color: "rgba(255,255,255,0.65)", lineHeight: 1.7, maxWidth: 560, margin: "0 auto 40px", fontFamily: "Georgia, serif", fontWeight: 400, fontStyle: "italic" },
  heroActions: { display: "flex", gap: 16, justifyContent: "center", flexWrap: "wrap" },
  heroPrimary: { background: "#e8ff47", color: "#0a0a0a", border: "none", borderRadius: 4, padding: "16px 40px", fontWeight: 900, fontSize: 16, letterSpacing: 3, textTransform: "uppercase", cursor: "pointer", transition: "transform 0.2s, box-shadow 0.2s" },
  heroSecondary: { background: "transparent", color: "#fff", border: "none", borderRadius: 4, padding: "16px 36px", fontWeight: 700, fontSize: 16, letterSpacing: 2, textTransform: "uppercase", cursor: "pointer" },
  heroScroll: { display: "flex", flexDirection: "column", alignItems: "center", gap: 4, color: "rgba(255,255,255,0.4)", fontSize: 12, letterSpacing: 3, textTransform: "uppercase", marginTop: 72 },
  ticker: { background: "#e8ff47", overflow: "hidden", padding: "14px 0", borderTop: "none" },
  tickerInner: { display: "flex", gap: 0, width: "max-content" },
  tickerItem: { display: "flex", alignItems: "center", gap: 16, padding: "0 40px", whiteSpace: "nowrap" },
  tickerNum: { fontSize: 22, fontWeight: 900, color: "#0a0a0a", letterSpacing: 1 },
  tickerLabel: { fontSize: 13, fontWeight: 700, color: "#333", letterSpacing: 2, textTransform: "uppercase" },
  tickerDot: { color: "#0a0a0a", fontSize: 10, opacity: 0.5 },
  sectionLabel: { fontSize: 12, letterSpacing: 4, color: "#e8ff47", textTransform: "uppercase", fontWeight: 700, marginBottom: 16 },
  sectionH2: { fontSize: "clamp(36px, 6vw, 72px)", fontWeight: 900, textTransform: "uppercase", lineHeight: 1, letterSpacing: -1, marginBottom: 60 },
  split: { display: "grid", gridTemplateColumns: "1fr 1fr", minHeight: 600, background: "#0d0d0d" },
  splitImg: { position: "relative", overflow: "hidden", minHeight: 500 },
  splitImgOverlay: { position: "absolute", inset: 0, background: "linear-gradient(120deg, transparent 60%, #0d0d0d)" },
  splitBadgeFloat: { position: "absolute", bottom: 40, left: 40, background: "#e8ff47", borderRadius: 8, padding: "16px 24px", textAlign: "center" },
  splitBadgeNum: { fontSize: 32, fontWeight: 900, color: "#0a0a0a" },
  splitBadgeTxt: { fontSize: 12, fontWeight: 700, color: "#333", letterSpacing: 2 },
  splitContent: { display: "flex", alignItems: "center", padding: "80px 64px", background: "#0d0d0d" },
  splitText: { fontSize: 17, color: "rgba(255,255,255,0.6)", lineHeight: 1.8, fontFamily: "Georgia, serif", marginBottom: 32 },
  featureList: { display: "flex", flexDirection: "column", gap: 14, marginBottom: 40 },
  featureItem: { display: "flex", alignItems: "flex-start", gap: 12, fontSize: 16, color: "#ddd", fontWeight: 600, letterSpacing: 0.5 },
  featureCheck: { color: "#e8ff47", fontSize: 18, fontWeight: 900, minWidth: 20 },
  ctaBanner: { position: "relative", display: "flex", alignItems: "center", justifyContent: "center", padding: "120px 24px", textAlign: "center", overflow: "hidden" },
  ctaBannerBg: { position: "absolute", inset: 0, zIndex: 1 },
  ctaOverlay: { position: "absolute", inset: 0, background: "linear-gradient(to right, rgba(10,10,10,0.95), rgba(10,10,10,0.8))" },
  ctaContent: { position: "relative", zIndex: 2 },
  ctaH2: { fontSize: "clamp(32px, 5vw, 64px)", fontWeight: 900, textTransform: "uppercase", lineHeight: 1, letterSpacing: -1, marginBottom: 32 },
  footer: { borderTop: "1px solid rgba(255,255,255,0.05)", padding: "60px 40px 40px", maxWidth: 1200, margin: "0 auto" },
  footerTop: { display: "flex", justifyContent: "space-between", alignItems: "center", flexWrap: "wrap", gap: 32, marginBottom: 40 },
  footerLinks: { display: "flex", gap: 24, flexWrap: "wrap" },
  footerLink: { color: "rgba(255,255,255,0.5)", textDecoration: "none", fontSize: 13, fontWeight: 700, letterSpacing: 2, textTransform: "uppercase", transition: "color 0.2s" },
  footerBottom: { display: "flex", justifyContent: "space-between", alignItems: "center", flexWrap: "wrap", gap: 16, borderTop: "1px solid rgba(255,255,255,0.1)", paddingTop: 32, fontSize: 13, color: "rgba(255,255,255,0.3)", letterSpacing: 1, textTransform: "uppercase" },
};