import { useState } from "react";
import { Link } from "react-router-dom";

const PROGRAMS = [
  { title: "Strength & Power", desc: "Build raw, functional strength with Olympic lifts, powerlifting, and progressive overload systems.", icon: "🏋️", tag: "MOST POPULAR", img: "https://images.unsplash.com/photo-1534438327276-14e5300c3a48?w=600&q=80" },
  { title: "HIIT & Conditioning", desc: "Torch calories and build endurance with our high-intensity interval training protocols.", icon: "⚡", tag: "FAT BURN", img: "https://images.unsplash.com/photo-1549060279-7e168fcee0c2?w=600&q=80" },
  { title: "Combat & MMA", desc: "Boxing, Muay Thai, and grappling fundamentals for total body transformation.", icon: "🥊", tag: "ELITE", img: "https://images.unsplash.com/photo-1552072805-f0abe7c0a53d?w=600&q=80" },
  { title: "Mobility & Recovery", desc: "Move better, perform longer. Expert-guided flexibility and recovery protocols.", icon: "🧘", tag: "WELLNESS", img: "https://images.unsplash.com/photo-1544367567-0f2fcb009e0b?w=600&q=80" },
];

export default function Programs() {
  const [activeProgram, setActiveProgram] = useState(0);

  return (
    <div style={styles.root}>
      {/* Spacer for navbar */}
      <div style={{ height: 100 }} />
      <div style={{ maxWidth: 1200, margin: "0 auto", padding: "40px 24px" }}>
        <div style={styles.sectionLabel}>— WHAT WE OFFER</div>
        <h2 style={styles.sectionH2}>Programs Built to <span className="gradient-text">Break You</span> & Build You</h2>
        
        <div style={styles.programGrid}>
          {PROGRAMS.map((p, i) => (
            <div
              key={i}
              style={{ ...styles.programCard, ...(activeProgram === i ? styles.programCardActive : {}) }}
              className="program-card"
              onMouseEnter={() => setActiveProgram(i)}
            >
              <div style={styles.programImgWrap}>
                <img src={p.img} alt={p.title} style={styles.programImg} />
                <div style={styles.programImgOverlay} />
                <span style={styles.programTag}>{p.tag}</span>
              </div>
              <div style={styles.programBody}>
                <div style={styles.programIcon}>{p.icon}</div>
                <h3 style={styles.programTitle}>{p.title}</h3>
                <p style={styles.programDesc}>{p.desc}</p>
                <Link to={`/user/payments?payTo=FitXpert&amount=1499&item=${encodeURIComponent(p.title)}`} style={styles.programLink} className="program-link">
                  Buy Program (₹1,499) →
                </Link>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

const styles = {
  root: { minHeight: "100vh", background: "#0a0a0a", color: "#f0f0f0" },
  sectionLabel: { fontSize: 12, letterSpacing: 4, color: "#e8ff47", textTransform: "uppercase", fontWeight: 700, marginBottom: 16, textAlign: "center" },
  sectionH2: { fontSize: "clamp(36px, 6vw, 72px)", fontWeight: 900, textTransform: "uppercase", lineHeight: 1, letterSpacing: -1, marginBottom: 60, textAlign: "center" },
  programGrid: { display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(260px, 1fr))", gap: 24 },
  programCard: { background: "#111", borderRadius: 12, overflow: "hidden", border: "1px solid rgba(255,255,255,0.06)", transition: "transform 0.3s, border-color 0.3s", cursor: "pointer" },
  programCardActive: { border: "1px solid rgba(232,255,71,0.4)" },
  programImgWrap: { position: "relative", height: 200 },
  programImg: { width: "100%", height: "100%", objectFit: "cover", display: "block" },
  programImgOverlay: { position: "absolute", inset: 0, background: "linear-gradient(to bottom, transparent 40%, rgba(0,0,0,0.7))" },
  programTag: { position: "absolute", top: 12, right: 12, background: "#e8ff47", color: "#0a0a0a", fontSize: 10, fontWeight: 900, letterSpacing: 2, padding: "4px 10px", borderRadius: 2 },
  programBody: { padding: "24px" },
  programIcon: { fontSize: 28, marginBottom: 10 },
  programTitle: { fontSize: 22, fontWeight: 800, textTransform: "uppercase", letterSpacing: 1, marginBottom: 10, color: "#fff" },
  programDesc: { fontSize: 14, color: "rgba(255,255,255,0.55)", lineHeight: 1.7, marginBottom: 20, fontFamily: "Georgia, serif" },
  programLink: { color: "#e8ff47", textDecoration: "none", fontSize: 13, fontWeight: 700, letterSpacing: 1, textTransform: "uppercase" },
};
