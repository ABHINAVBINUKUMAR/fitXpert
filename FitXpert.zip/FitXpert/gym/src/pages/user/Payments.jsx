import { useState, useEffect } from "react";
import { useSearchParams, useNavigate } from "react-router-dom";
import { Search, QrCode, ArrowRightLeft, Building2, Receipt, Phone, User, CheckCircle2, ChevronRight, History } from "lucide-react";

export default function Payments() {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const bookingId = searchParams.get("booking_id");
  
  const [checkingOut, setCheckingOut] = useState(false);
  const [checkoutData, setCheckoutData] = useState(null);
  const [paymentStatus, setPaymentStatus] = useState("idle"); // idle, processing, success
  
  const [transactions, setTransactions] = useState([
    { id: 1, to: "Marcus Steele", date: "12 Mar 2026", amount: "₹1,999", type: "sent", avatar: "MS", color: "#e8ff47" },
    { id: 2, to: "FitXpert Cafe", date: "10 Mar 2026", amount: "₹349", type: "sent", avatar: "FC", color: "#4caf50" },
    { id: 3, to: "FitXpert Gym", date: "01 Mar 2026", amount: "₹2,999", type: "sent", avatar: "FX", color: "#00bcd4" },
  ]);

  useEffect(() => {
    const payTo = searchParams.get("payTo");
    const amount = searchParams.get("amount");
    const item = searchParams.get("item");

    if (payTo && amount) {
      setCheckoutData({ payTo, amount, item, bookingId });
      setCheckingOut(true);
    }
  }, [searchParams, bookingId]);

  const handlePay = () => {
    setPaymentStatus("processing");
    setTimeout(() => {
      setPaymentStatus("success");

      if (bookingId) {
        fetch(`${import.meta.env.VITE_API_URL || "http://localhost:8000/api"}/bookings/${bookingId}/pay`, {
          method: "PATCH",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${localStorage.getItem("fitxpert_token")}`,
          },
        }).catch(() => {});
      }
      
      // Add fake transaction
      setTransactions(prev => [{
        id: Date.now(),
        to: checkoutData.payTo,
        date: "Today",
        amount: `₹${checkoutData.amount}`,
        type: "sent",
        avatar: checkoutData.payTo.substring(0, 2).toUpperCase(),
        color: "#e8ff47"
      }, ...prev]);

      setTimeout(() => {
        setCheckingOut(false);
        setPaymentStatus("idle");
        navigate("/user/payments", { replace: true });
      }, 2500); // Wait 2.5s on success screen before closing
    }, 1500); // 1.5s processing fake
  };

  const closeModal = () => {
    if (paymentStatus === "processing") return;
    setCheckingOut(false);
    navigate("/user/payments", { replace: true });
  };

  return (
    <div style={{ animation: "fadeIn 0.5s ease", position: "relative", minHeight: "100%", paddingBottom: 60, fontFamily: "Inter, sans-serif" }}>
      
      {/* GPAY HOME SCREEN DUMMY UI */}
      <div style={{ maxWidth: 600, margin: "0 auto" }}>
        
        {/* Header / Search */}
        <div style={{ display: "flex", alignItems: "center", gap: 16, marginBottom: 32 }}>
          <div style={{ flex: 1, position: "relative" }}>
            <Search size={20} color="rgba(255,255,255,0.4)" style={{ position: "absolute", left: 16, top: "50%", transform: "translateY(-50%)" }} />
            <input placeholder="Pay anyone on UPI" style={{ width: "100%", background: "#1a1a1c", border: "1px solid rgba(255,255,255,0.05)", color: "#fff", padding: "16px 16px 16px 48px", borderRadius: 30, fontSize: 16, outline: "none", boxSizing: "border-box" }} />
          </div>
          <div style={{ width: 44, height: 44, borderRadius: 22, background: "linear-gradient(135deg, #e8ff47, #4caf50)", display: "flex", alignItems: "center", justifyContent: "center", color: "#000", fontWeight: 800 }}>
            US
          </div>
        </div>

        {/* Quick Actions Array */}
        <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 40 }}>
          <QuickAction icon={<QrCode size={24} />} label="Scan QR" />
          <QuickAction icon={<Phone size={24} />} label="Pay Contacts" />
          <QuickAction icon={<Building2 size={24} />} label="Bank Transfer" />
          <QuickAction icon={<Receipt size={24} />} label="Pay Bills" />
        </div>

        {/* People & Businesses */}
        <h3 style={{ fontSize: 16, fontWeight: 700, marginBottom: 16, padding: "0 8px" }}>People & Businesses</h3>
        <div style={{ display: "flex", gap: 24, overflowX: "auto", padding: "0 8px 16px", marginBottom: 24, WebkitOverflowScrolling: "touch" }}>
          <Avatar title="FitXpert" subtitle="Gym" initials="FX" bg="#00bcd4" />
          <Avatar title="Marcus" subtitle="Trainer" initials="MS" bg="#e8ff47" />
          <Avatar title="Aria" subtitle="Dietitian" initials="AC" bg="#ff9800" />
          <Avatar title="Cafe" subtitle="Protein" initials="FC" bg="#4caf50" />
          <Avatar title="Store" subtitle="Supps" initials="SS" bg="#9c27b0" />
        </div>

        {/* Transaction History */}
        <h3 style={{ fontSize: 16, fontWeight: 700, marginBottom: 16, padding: "0 8px", display: "flex", alignItems: "center", gap: 8 }}>
          <History size={18} /> Transaction History
        </h3>
        <div style={{ background: "#111", borderRadius: 16, overflow: "hidden" }}>
          {transactions.map((t, idx) => (
            <div key={t.id} style={{ display: "flex", alignItems: "center", padding: "16px 20px", borderBottom: idx !== transactions.length - 1 ? "1px solid rgba(255,255,255,0.05)" : "none" }}>
               <div style={{ width: 40, height: 40, borderRadius: 20, background: t.color, color: "#000", display: "flex", alignItems: "center", justifyContent: "center", fontWeight: 800, fontSize: 14 }}>
                 {t.avatar}
               </div>
               <div style={{ flex: 1, marginLeft: 16 }}>
                 <div style={{ fontSize: 16, fontWeight: 600, color: "#fff" }}>{t.to}</div>
                 <div style={{ fontSize: 13, color: "rgba(255,255,255,0.4)", marginTop: 4 }}>{t.date}</div>
               </div>
               <div style={{ textAlign: "right" }}>
                 <div style={{ fontSize: 16, fontWeight: 700, color: "#fff" }}>{t.amount}</div>
                 <div style={{ fontSize: 11, color: "rgba(255,255,255,0.4)", marginTop: 4, textTransform: "uppercase" }}>{t.type} <ChevronRight size={12} style={{verticalAlign: "middle"}} /></div>
               </div>
            </div>
          ))}
        </div>

      </div>

      {/* BOTTOM SHEET CHECKOUT MODAL */}
      {checkingOut && (
        <div style={{ position: "fixed", inset: 0, zIndex: 9999, display: "flex", flexDirection: "column", justifyContent: "flex-end" }}>
          {/* Backdrop */}
          <div style={{ position: "absolute", inset: 0, background: "rgba(0,0,0,0.6)", backdropFilter: "blur(4px)" }} onClick={closeModal} />
          
          {/* Sheet */}
          <div style={{ position: "relative", background: "#121212", borderTopLeftRadius: 24, borderTopRightRadius: 24, padding: "32px 24px", minHeight: 400, transform: "translateY(0)", animation: "slideUp 0.3s cubic-bezier(0.16, 1, 0.3, 1)", display: "flex", flexDirection: "column" }}>
            
            {paymentStatus === "idle" && (
              <>
                <div style={{ textAlign: "center", marginBottom: 32 }}>
                   <div style={{ width: 64, height: 64, borderRadius: 32, background: "rgba(232,255,71,0.1)", color: "#e8ff47", display: "flex", alignItems: "center", justifyContent: "center", margin: "0 auto 16px", fontWeight: 800, fontSize: 24 }}>
                     {checkoutData?.payTo.substring(0, 2).toUpperCase()}
                   </div>
                   <div style={{ fontSize: 16, color: "rgba(255,255,255,0.6)" }}>Paying</div>
                   <div style={{ fontSize: 24, fontWeight: 700, marginTop: 4 }}>{checkoutData?.payTo}</div>
                   <div style={{ fontSize: 14, color: "rgba(255,255,255,0.4)", marginTop: 4 }}>{checkoutData?.item}</div>
                </div>

                <div style={{ textAlign: "center", marginBottom: 48 }}>
                  <div style={{ fontSize: 64, fontWeight: 900, color: "#fff", display: "flex", alignItems: "baseline", justifyContent: "center", gap: 4 }}>
                    <span style={{ fontSize: 32 }}>₹</span>{checkoutData?.amount}
                  </div>
                </div>

                <div style={{ flex: 1 }} />

                <div style={{ background: "#1c1c1e", borderRadius: 16, padding: 16, display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 24 }}>
                   <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
                     <Building2 size={24} color="#e8ff47" />
                     <div>
                       <div style={{ fontSize: 14, fontWeight: 600 }}>HDFC Bank •••• 4242</div>
                       <div style={{ fontSize: 12, color: "rgba(255,255,255,0.4)" }}>Savings Account</div>
                     </div>
                   </div>
                   <ChevronRight size={20} color="rgba(255,255,255,0.4)" />
                </div>

                <button onClick={handlePay} style={{ background: "#3b82f6", color: "#fff", border: "none", width: "100%", padding: 20, borderRadius: 30, fontSize: 18, fontWeight: 700, cursor: "pointer", transition: "transform 0.1s" }} onPointerDown={e=>e.target.style.transform="scale(0.98)"} onPointerUp={e=>e.target.style.transform="scale(1)"}>
                  Pay ₹{checkoutData?.amount}
                </button>
              </>
            )}

            {paymentStatus === "processing" && (
              <div style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 24 }}>
                <div className="spinner" />
                <div style={{ fontSize: 18, fontWeight: 600 }}>Processing Payment...</div>
                <div style={{ fontSize: 14, color: "rgba(255,255,255,0.4)" }}>Connecting securely to bank</div>
              </div>
            )}

            {paymentStatus === "success" && (
              <div style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 24, animation: "scaleIn 0.5s cubic-bezier(0.16, 1, 0.3, 1)" }}>
                <div style={{ background: "#4caf50", width: 100, height: 100, borderRadius: 50, display: "flex", alignItems: "center", justifyContent: "center", boxShadow: "0 0 40px rgba(76,175,80,0.5)" }}>
                  <CheckCircle2 size={64} color="#fff" strokeWidth={2.5} />
                </div>
                <div style={{ textAlign: "center" }}>
                  <div style={{ fontSize: 32, fontWeight: 800 }}>Paid ₹{checkoutData?.amount}</div>
                  <div style={{ fontSize: 18, color: "rgba(255,255,255,0.6)", marginTop: 8 }}>Securely to {checkoutData?.payTo}</div>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      <style>{`
        @keyframes slideUp { from { transform: translateY(100%); } to { transform: translateY(0); } }
        @keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }
        @keyframes scaleIn { 0% { opacity: 0; transform: scale(0.5); } 60% { transform: scale(1.1); } 100% { opacity: 1; transform: scale(1); } }
        .spinner { width: 48px; height: 48px; border: 4px solid rgba(59, 130, 246, 0.3); border-left-color: #3b82f6; border-radius: 50%; animation: spin 1s linear infinite; }
        @keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }
      `}</style>
    </div>
  );
}

const QuickAction = ({ icon, label }) => (
  <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 8, cursor: "pointer", width: 80 }}>
    <div style={{ width: 56, height: 56, borderRadius: 28, background: "#1a1a1c", border: "1px solid rgba(255,255,255,0.05)", display: "flex", alignItems: "center", justifyContent: "center", color: "#3b82f6" }}>
      {icon}
    </div>
    <div style={{ fontSize: 12, fontWeight: 500, color: "rgba(255,255,255,0.8)", textAlign: "center" }}>
      {label}
    </div>
  </div>
);

const Avatar = ({ initials, title, subtitle, bg }) => (
  <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 8, minWidth: 70 }}>
    <div style={{ width: 64, height: 64, borderRadius: 32, background: bg, display: "flex", alignItems: "center", justifyContent: "center", color: "#000", fontWeight: 800, fontSize: 22 }}>
      {initials}
    </div>
    <div style={{ textAlign: "center" }}>
      <div style={{ fontSize: 13, fontWeight: 600, color: "#fff", whiteSpace: "nowrap" }}>{title}</div>
      <div style={{ fontSize: 11, color: "rgba(255,255,255,0.4)" }}>{subtitle}</div>
    </div>
  </div>
);
