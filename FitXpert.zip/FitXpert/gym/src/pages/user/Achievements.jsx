import { useState } from "react";
import confetti from "canvas-confetti";
import { Lock, Trophy, Zap, Flame, Crown, Target, Heart, Shield, Star, Medal } from "lucide-react";

const INITIAL_BADGES = [
  { id: 1, name: "First Flame", desc: "First workout completed", icon: <Flame size={32} />, unlocked: false },
  { id: 2, name: "Iron Will", desc: "30 days streak", icon: <Shield size={32} />, unlocked: false },
  { id: 3, name: "Century Club", desc: "100 workouts", icon: <Trophy size={32} />, unlocked: false },
  { id: 4, name: "Clean Eater", desc: "Followed diet plan 7 days", icon: <Heart size={32} />, unlocked: false },
  { id: 5, name: "Elite Member", desc: "1 year membership", icon: <Crown size={32} />, unlocked: false },
  { id: 6, name: "HIIT Hero", desc: "20 HIIT sessions", icon: <Zap size={32} />, unlocked: false },
  { id: 7, name: "Goal Crusher", desc: "Achieved first goal", icon: <Target size={32} />, unlocked: false },
  { id: 8, name: "Cardio King", desc: "50 cardio sessions", icon: <Star size={32} />, unlocked: false },
  { id: 9, name: "Zen Master", desc: "15 yoga sessions", icon: <Medal size={32} />, unlocked: false },
  { id: 10, name: "Beast Mode", desc: "Lifted 100kg+", icon: <Trophy size={32} />, unlocked: false },
  { id: 11, name: "Early Bird", desc: "10 workouts before 7AM", icon: <Zap size={32} />, unlocked: false },
  { id: 12, name: "Night Owl", desc: "10 workouts after 9PM", icon: <Star size={32} />, unlocked: false }
];

const INITIAL_LEADERBOARD = [
  { rank: 1, name: "Alex Chen", xp: 12450, isUser: false },
  { rank: 2, name: "Sarah Jenkins", xp: 11200, isUser: false },
  { rank: 3, name: "Marcus Steele", xp: 10850, isUser: false },
  { rank: 5, name: "David Kim", xp: 8900, isUser: false },
  { rank: 6, name: "Emma Watson", xp: 8100, isUser: false },
];

export default function Achievements() {
  const [activeTab, setActiveTab] = useState('badges');
  
  // Load dynamic data from localStorage
  const userXp = parseInt(localStorage.getItem('fitxpert_xp') || "2400", 10);
  const unlockedBadgeIds = JSON.parse(localStorage.getItem('fitxpert_badges') || "[]");
  
  const level = Math.floor(userXp / 200) + 1;
  const nextLevelXp = level * 200;
  const progressPercent = ((userXp % 200) / 200) * 100;

  const badges = INITIAL_BADGES.map(b => ({
    ...b,
    unlocked: unlockedBadgeIds.includes(b.id) || (b.id === 2 && userXp > 3000) // minor mock
  }));

  const leaderboard = [...INITIAL_LEADERBOARD, { name: "You", xp: userXp, isUser: true }]
    .sort((a, b) => b.xp - a.xp)
    .map((u, i) => ({ ...u, rank: i + 1 }));

  const triggerConfetti = (e) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const x = (rect.left + rect.width / 2) / window.innerWidth;
    const y = (rect.top + rect.height / 2) / window.innerHeight;
    
    confetti({
      particleCount: 50,
      spread: 60,
      origin: { x, y },
      colors: ['#e8ff47', '#ffffff', '#b8ff00'],
      zIndex: 9999
    });
  };

  return (
    <div>
      <h1 style={{ fontSize: 56, textTransform: "uppercase", fontWeight: 900, marginBottom: 40, letterSpacing: -1 }}>
        Your <span className="gradient-text">Legacy</span>
      </h1>

      {/* TOP PROFILE HEADER */}
      <div className="card" style={{ padding: 40, marginBottom: 40, display: "flex", gap: 32, alignItems: "center" }}>
        <div style={{ width: 100, height: 100, borderRadius: 50, background: "#e8ff47", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 40, color: "#000", fontWeight: 'bold' }}>
          YD
        </div>
        <div style={{ flex: 1 }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-end", marginBottom: 16 }}>
            <div>
              <h2 style={{ fontSize: 32, fontWeight: 800, margin: 0 }}>LEVEL {level} WARRIOR</h2>
              <div style={{ color: "rgba(255,255,255,0.5)", fontSize: 16, letterSpacing: 1, textTransform: "uppercase", marginTop: 4 }}>Member since Jan 2024</div>
            </div>
            <div style={{ fontSize: 24, fontWeight: 800, color: "#e8ff47" }}>{userXp} / {nextLevelXp} XP</div>
          </div>
          <div style={{ height: 12, background: "#222", borderRadius: 6, overflow: "hidden" }}>
            <div style={{ height: "100%", width: `${progressPercent}%`, background: "#e8ff47", borderRadius: 6, boxShadow: "0 0 12px rgba(232,255,71,0.5)" }} />
          </div>
        </div>
      </div>

      {/* TABS */}
      <div style={{ display: "flex", gap: 16, marginBottom: 32 }}>
        {['badges', 'leaderboard', 'challenges'].map(tab => (
          <button 
            key={tab}
            onClick={() => setActiveTab(tab)}
            style={{
              padding: "12px 24px",
              background: activeTab === tab ? "#e8ff47" : "transparent",
              color: activeTab === tab ? "#0a0a0a" : "#fff",
              border: `1px solid ${activeTab === tab ? "#e8ff47" : "rgba(255,255,255,0.2)"}`,
              borderRadius: 8,
              fontSize: 14,
              fontWeight: 800,
              textTransform: "uppercase",
              letterSpacing: 2,
              cursor: "pointer",
              transition: "all 0.2s"
            }}
          >
            {tab}
          </button>
        ))}
      </div>

      {/* TAB CONTENT */}
      {activeTab === 'badges' && (
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(200px, 1fr))", gap: 24 }}>
          {badges.map(badge => (
            <div 
              key={badge.id} 
              className="card badge-card"
              onMouseEnter={(e) => badge.unlocked && triggerConfetti(e)}
              style={{ 
                padding: 24, 
                textAlign: "center", 
                position: "relative",
                overflow: "hidden",
                border: badge.unlocked ? "1px solid rgba(232,255,71,0.3)" : "1px solid rgba(255,255,255,0.05)",
                background: badge.unlocked ? "rgba(232,255,71,0.03)" : "#111",
                cursor: badge.unlocked ? "pointer" : "default",
                transition: "all 0.3s"
              }}
            >
              {!badge.unlocked && (
                <div style={{ position: "absolute", top: 12, right: 12, color: "rgba(255,255,255,0.2)" }}>
                  <Lock size={16} />
                </div>
              )}
              <div style={{ 
                display: "inline-flex", 
                alignItems: "center", 
                justifyContent: "center",
                width: 80, 
                height: 80, 
                borderRadius: 40,
                background: badge.unlocked ? "rgba(232,255,71,0.1)" : "#222",
                color: badge.unlocked ? "#e8ff47" : "#555",
                marginBottom: 16,
                transform: badge.unlocked ? "scale(1)" : "scale(0.9)",
                filter: badge.unlocked ? "none" : "blur(1px)",
                transition: "all 0.3s"
              }}>
                {badge.icon}
              </div>
              <h4 style={{ fontSize: 18, fontWeight: 700, margin: "0 0 8px", color: badge.unlocked ? "#fff" : "#666" }}>{badge.name}</h4>
              <p style={{ fontSize: 13, color: "rgba(255,255,255,0.4)", margin: 0, fontFamily: "'Inter', sans-serif" }}>{badge.desc}</p>
            </div>
          ))}
        </div>
      )}

      {activeTab === 'leaderboard' && (
        <div className="card" style={{ padding: 0, overflow: "hidden" }}>
          {leaderboard.map((user) => (
            <div key={user.rank} style={{ 
              display: "flex", 
              alignItems: "center", 
              padding: "20px 32px",
              borderBottom: "1px solid rgba(255,255,255,0.05)",
              background: user.isUser ? "rgba(232,255,71,0.05)" : "transparent"
            }}>
              <div style={{ width: 40, fontSize: 24, fontWeight: 900, color: user.rank <= 3 ? "#e8ff47" : "#666" }}>
                #{user.rank}
              </div>
              <div style={{ width: 48, height: 48, borderRadius: 24, background: "#333", marginRight: 20, display: "flex", alignItems: "center", justifyContent: "center", fontWeight: "bold" }}>
                {user.name.charAt(0)}
              </div>
              <div style={{ flex: 1, fontSize: 18, fontWeight: 700, color: user.isUser ? "#e8ff47" : "#fff" }}>
                {user.name} {user.isUser && "(You)"}
              </div>
              <div style={{ fontSize: 20, fontWeight: 900 }}>{user.xp.toLocaleString()} XP</div>
            </div>
          ))}
        </div>
      )}

      {activeTab === 'challenges' && (
        <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
          {[
            { title: "Complete 4 workouts this week", progress: 2, total: 4, xp: 500 },
            { title: "Hit your daily protein goal 5 days", progress: 5, total: 5, xp: 800, done: true },
            { title: "Log 3 cardio sessions", progress: 1, total: 3, xp: 300 }
          ].map((c, i) => (
            <div key={i} className="card" style={{ padding: 32, display: "flex", alignItems: "center", gap: 32 }}>
              <div style={{ flex: 1 }}>
                <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 16 }}>
                  <h3 style={{ fontSize: 20, fontWeight: 700, margin: 0 }}>{c.title}</h3>
                  <span style={{ color: "#e8ff47", fontWeight: 800, fontSize: 18 }}>+{c.xp} XP</span>
                </div>
                <div style={{ height: 12, background: "#222", borderRadius: 6, overflow: "hidden" }}>
                  <div style={{ height: "100%", width: (c.progress/c.total)*100 + "%", background: c.done ? "#4caf50" : "#e8ff47" }} />
                </div>
              </div>
              <div style={{ fontSize: 28, fontWeight: 900, color: c.done ? "#4caf50" : "#fff", width: 80, textAlign: "right" }}>
                {c.progress} / {c.total}
              </div>
            </div>
          ))}
        </div>
      )}

      <style>{`
        .badge-card:hover { transform: translateY(-4px); }
      `}</style>
    </div>
  );
}
