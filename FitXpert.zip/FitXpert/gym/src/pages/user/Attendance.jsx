import { useState, useMemo } from "react";
import { Calendar as CalendarIcon, Flame, BarChart3, CheckCircle2, XCircle } from "lucide-react";
import { BarChart, Bar, XAxis, Tooltip, ResponsiveContainer } from "recharts";

const MONTH_DAYS = 30; // Mock 30-day month
const WEEK_DATA = [
  { day: "Mon", attendance: 1 },
  { day: "Tue", attendance: 1 },
  { day: "Wed", attendance: 0 },
  { day: "Thu", attendance: 1 },
  { day: "Fri", attendance: 1 },
  { day: "Sat", attendance: 0 },
  { day: "Sun", attendance: 0 },
];

export default function Attendance() {
  const [attendanceRecords, setAttendanceRecords] = useState(() => {
    const saved = localStorage.getItem("fitxpert_attendance");
    if (saved) return JSON.parse(saved);
    
    // Default to empty month if no saved data
    return Array.from({ length: MONTH_DAYS }, () => null);
  });

  const saveRecords = (records) => {
    localStorage.setItem("fitxpert_attendance", JSON.stringify(records));
    setAttendanceRecords(records);
  }

  const stats = useMemo(() => {
    let present = 0;
    let absent = 0;
    let currentStreak = 0;
    let maxStreak = 0;

    for (const status of attendanceRecords) {
      if (status === 'present') {
        present++;
        currentStreak++;
        maxStreak = Math.max(maxStreak, currentStreak);
      } else if (status === 'absent') {
        absent++;
        currentStreak = 0;
      }
    }

    const totalDays = present + absent;
    const percentage = totalDays > 0 ? Math.round((present / totalDays) * 100) : 0;

    return { present, absent, percentage, currentStreak };
  }, [attendanceRecords]);

  const checkInToday = () => {
    // Determine "today" based on the number of present/absent days so far
    // Or just find the first null day
    const firstNull = attendanceRecords.findIndex(s => s === null);
    if (firstNull !== -1) {
      const newArr = [...attendanceRecords];
      newArr[firstNull] = 'present';
      
      // Mark all previous nulls as absent (missed days) if any
      for (let i = 0; i < firstNull; i++) {
        if (newArr[i] === null) newArr[i] = 'absent';
      }
      
      saveRecords(newArr);
      
      // Give XP for checking in
      const currentXp = parseInt(localStorage.getItem("fitxpert_xp") || "2400", 10);
      localStorage.setItem("fitxpert_xp", currentXp + 10);
      
      // Trigger confetti or something?
    }
  };

  const getQuote = () => {
    if (stats.currentStreak >= 10) return "Unstoppable force! You're on fire.";
    if (stats.currentStreak >= 5) return "Great momentum! Keep the streak alive.";
    if (stats.currentStreak >= 2) return "Good start! Consistency is key.";
    return "The hardest part is showing up. Let's get it today!";
  };

  return (
    <div>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-end", marginBottom: 40 }}>
        <h1 style={{ fontSize: 56, textTransform: "uppercase", fontWeight: 900, margin: 0, letterSpacing: -1 }}>
          <span className="gradient-text">Attendance</span> Log
        </h1>
        <button 
          onClick={checkInToday}
          className="btn-glow"
          style={{ 
            background: "#e8ff47", color: "#000", border: "none", borderRadius: 8, 
            padding: "16px 32px", fontSize: 18, fontWeight: 900, textTransform: "uppercase", cursor: "pointer",
            display: "flex", alignItems: "center", gap: 12,
            animation: "pulseBtn 2s infinite"
          }}
        >
          <CheckCircle2 /> Check In Today
        </button>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 340px", gap: 32, alignItems: "start" }}>
        
        {/* LEFT COL: CALENDAR */}
        <div>
          <div className="card" style={{ padding: "40px 48px", marginBottom: 32 }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 32 }}>
              <h3 style={{ fontSize: 26, fontWeight: 700, margin: 0, display: "flex", alignItems: "center", gap: 12, textTransform: "uppercase", letterSpacing: 1 }}>
                <CalendarIcon color="#e8ff47" size={28} /> March 2026
              </h3>
              <div style={{ display: "flex", gap: 16, fontSize: 13, textTransform: "uppercase", fontWeight: 600 }}>
                <span style={{ display: "flex", alignItems: "center", gap: 8 }}><div style={{width: 14, height: 14, borderRadius: 7, background: "#e8ff47"}}/> Present</span>
                <span style={{ display: "flex", alignItems: "center", gap: 8 }}><div style={{width: 14, height: 14, borderRadius: 7, background: "#ff4747"}}/> Absent</span>
              </div>
            </div>

            <div style={{ display: "grid", gridTemplateColumns: "repeat(7, 1fr)", gap: 16 }}>
              {["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"].map(d => (
                <div key={d} style={{ textAlign: "center", color: "rgba(255,255,255,0.3)", fontWeight: 700, paddingBottom: 16, fontSize: 14, textTransform: "uppercase", letterSpacing: 1 }}>{d}</div>
              ))}
              {attendanceRecords.map((status, i) => {
                let bg = "#181818";
                let shadow = "inset 0 0 0 1px rgba(255,255,255,0.03)";
                let color = "rgba(255,255,255,0.3)";
                
                if (status === 'present') {
                  bg = "rgba(232,255,71,0.12)";
                  shadow = "inset 0 0 0 1px rgba(232,255,71,0.4)";
                  color = "#e8ff47";
                } else if (status === 'absent') {
                  bg = "rgba(255,71,71,0.12)";
                  shadow = "inset 0 0 0 1px rgba(255,71,71,0.4)";
                  color = "#ff4747";
                }

                return (
                  <button 
                    key={i} 
                    style={{ 
                      aspectRatio: "1", background: bg, border: "none", borderRadius: 12, 
                      color: color, fontSize: 24, fontWeight: 800, cursor: "default",
                      boxShadow: shadow, transition: "all 0.2s"
                    }}
                    onMouseEnter={(e) => { e.currentTarget.style.transform = "scale(1.05)"; e.currentTarget.style.filter = "brightness(1.2)"; }}
                    onMouseLeave={(e) => { e.currentTarget.style.transform = "scale(1)"; e.currentTarget.style.filter = "brightness(1)"; }}
                  >
                    {i + 1}
                  </button>
                );
              })}
            </div>
          </div>

          <div className="card" style={{ padding: "40px 48px" }}>
            <h3 style={{ fontSize: 22, fontWeight: 700, marginBottom: 32, display: "flex", alignItems: "center", gap: 12, textTransform: "uppercase", letterSpacing: 1 }}>
              <BarChart3 color="#e8ff47" size={24} /> Weekly Distribution
            </h3>
            <div style={{ height: 260 }}>
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={WEEK_DATA}>
                  <XAxis dataKey="day" stroke="rgba(255,255,255,0.2)" tick={{ fill: "rgba(255,255,255,0.6)", fontFamily: "Inter" }} />
                  <Tooltip 
                    cursor={{ fill: "rgba(255,255,255,0.05)" }}
                    contentStyle={{ backgroundColor: "#111", border: "1px solid rgba(232,255,71,0.3)", borderRadius: 8, color: "#fff", fontFamily: "Inter" }}
                  />
                  <Bar dataKey="attendance" fill="#e8ff47" radius={[6, 6, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>

        {/* RIGHT COL: STATS */}
        <div style={{ display: "flex", flexDirection: "column", gap: 24 }}>
          <div className="card" style={{ padding: 32, background: "linear-gradient(135deg, rgba(232,255,71,0.08) 0%, rgba(10,10,10,0) 100%)", border: "1px solid rgba(232,255,71,0.25)" }}>
            <div style={{ display: "flex", alignItems: "center", gap: 20, marginBottom: 24 }}>
              <Flame size={48} color="#e8ff47" />
              <div>
                <div style={{ fontSize: 13, textTransform: "uppercase", color: "#e8ff47", letterSpacing: 2, fontWeight: 700 }}>Current Streak</div>
                <div style={{ fontSize: 44, fontWeight: 900, lineHeight: 1 }}>{stats.currentStreak} Days</div>
              </div>
            </div>
            <p style={{ fontSize: 16, color: "rgba(255,255,255,0.7)", margin: 0, fontStyle: "italic", fontFamily: "Georgia, serif", lineHeight: 1.6 }}>
              "{getQuote()}"
            </p>
          </div>

          <div className="card" style={{ padding: 40, display: "flex", flexDirection: "column", gap: 32 }}>
            <div>
              <div style={{ fontSize: 13, textTransform: "uppercase", color: "rgba(255,255,255,0.5)", letterSpacing: 2, fontWeight: 700, marginBottom: 8 }}>Total Present</div>
              <div style={{ fontSize: 40, fontWeight: 900, color: "#fff", display: "flex", alignItems: "center", gap: 12 }}>
                {stats.present} <CheckCircle2 color="#e8ff47" size={32} />
              </div>
            </div>
            <div style={{ height: 1, background: "rgba(255,255,255,0.05)" }} />
            <div>
              <div style={{ fontSize: 13, textTransform: "uppercase", color: "rgba(255,255,255,0.5)", letterSpacing: 2, fontWeight: 700, marginBottom: 8 }}>Total Absent</div>
              <div style={{ fontSize: 40, fontWeight: 900, color: "#fff", display: "flex", alignItems: "center", gap: 12 }}>
                {stats.absent} <XCircle color="#ff4747" size={32} />
              </div>
            </div>
            <div style={{ height: 1, background: "rgba(255,255,255,0.05)" }} />
            <div>
              <div style={{ fontSize: 13, textTransform: "uppercase", color: "rgba(255,255,255,0.5)", letterSpacing: 2, fontWeight: 700, marginBottom: 8 }}>Attendance Rate</div>
              <div style={{ fontSize: 56, fontWeight: 900, color: "#e8ff47", textShadow: "0 0 20px rgba(232,255,71,0.2)" }}>
                {stats.percentage}%
              </div>
            </div>
          </div>
        </div>

      </div>

      <style>{`
        @keyframes pulseBtn {
          0% { box-shadow: 0 0 0 0 rgba(232, 255, 71, 0.4); }
          70% { box-shadow: 0 0 0 15px rgba(232, 255, 71, 0); }
          100% { box-shadow: 0 0 0 0 rgba(232, 255, 71, 0); }
        }
      `}</style>
    </div>
  );
}
