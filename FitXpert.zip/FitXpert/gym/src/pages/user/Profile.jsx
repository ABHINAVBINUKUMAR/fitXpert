import { useState, useEffect } from "react";

const defaultProfile = {
  name: "Aswin",
  phone: "+91 98765 43210",
  dob: "1998-05-15",
  gender: "Male",
  photoUrl: "https://images.unsplash.com/photo-1599566150163-29194dcaad36?w=400&q=80",
  currentPassword: "",
  newPassword: ""
};

const PROFILE_STORAGE_KEY = "fitxpert_profile";

export default function Profile() {
  const [formData, setFormData] = useState(defaultProfile);

  useEffect(() => {
    const savedProfile = localStorage.getItem(PROFILE_STORAGE_KEY);
    if (savedProfile) {
      setFormData({ ...defaultProfile, ...JSON.parse(savedProfile) });
    }
  }, []);

  const handleUpdate = (e) => {
    e.preventDefault();
    const profileDataToSave = {
      name: formData.name,
      phone: formData.phone,
      dob: formData.dob,
      gender: formData.gender,
      photoUrl: formData.photoUrl
    };
    localStorage.setItem(PROFILE_STORAGE_KEY, JSON.stringify(profileDataToSave));
    setFormData((prev) => ({ ...prev, currentPassword: "", newPassword: "" }));
    alert("Profile Updated Successfully!");
  };

  const handlePhotoUpload = (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = () => {
      if (reader.result) {
        setFormData((prev) => ({ ...prev, photoUrl: reader.result }));
      }
    };
    reader.readAsDataURL(file);
  };

  const handleDelete = () => {
    if (window.confirm("Are you sure you want to delete your account? This action cannot be undone.")) {
      alert("Account deleted.");
      window.location.href = "/";
    }
  };

  return (
    <div style={{ animation: "fadeIn 0.5s ease" }}>
      <h1 style={{ fontSize: 48, textTransform: "uppercase", fontWeight: 900, marginBottom: 40, letterSpacing: -1 }}>
        Member <span className="gradient-text">Profile</span>
      </h1>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 2fr", gap: 40 }}>
        {/* Left Col */}
        <div style={{ display: "flex", flexDirection: "column", gap: 24 }}>
          <div className="card" style={{ padding: 32, textAlign: "center" }}>
            <img src={formData.photoUrl} alt="Avatar" style={{ width: 120, height: 120, borderRadius: 60, objectFit: "cover", border: "4px solid #e8ff47", marginBottom: 16 }} />
            <h2 style={{ fontSize: 24, fontWeight: 900, textTransform: "uppercase" }}>{formData.name}</h2>
            <div style={{ display: "inline-block", background: "rgba(232,255,71,0.1)", color: "#e8ff47", padding: "4px 12px", borderRadius: 4, fontSize: 11, fontWeight: 900, marginTop: 8, letterSpacing: 1 }}>PRO PLAN</div>
          </div>

          <div className="card" style={{ padding: 32 }}>
            <h3 style={{ fontSize: 16, textTransform: "uppercase", color: "rgba(255,255,255,0.5)", marginBottom: 24, fontWeight: 700 }}>Overview Stats</h3>
            <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 16 }}>
              <span style={{ color: "rgba(255,255,255,0.8)" }}>Member Since</span>
              <span style={{ fontWeight: 800 }}>Jan 2026</span>
            </div>
            <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 16 }}>
              <span style={{ color: "rgba(255,255,255,0.8)" }}>Total Workouts</span>
              <span style={{ fontWeight: 800 }}>142</span>
            </div>
            <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 16 }}>
              <span style={{ color: "rgba(255,255,255,0.8)" }}>Total Check-ins</span>
              <span style={{ fontWeight: 800 }}>128</span>
            </div>
            <div style={{ display: "flex", justifyContent: "space-between" }}>
              <span style={{ color: "rgba(255,255,255,0.8)" }}>Current Streak</span>
              <span style={{ fontWeight: 800, color: "#e8ff47" }}>14 Days 🔥</span>
            </div>
          </div>
        </div>

        {/* Right Col */}
        <div style={{ display: "flex", flexDirection: "column", gap: 32 }}>
          <form className="card" onSubmit={handleUpdate} style={{ padding: 40 }}>
            <h2 style={{ fontSize: 20, fontWeight: 800, textTransform: "uppercase", marginBottom: 24, letterSpacing: 1 }}>Personal Information</h2>
            
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 20, marginBottom: 20 }}>
              <div style={styles.formGroup}><label style={styles.label}>Full Name</label><input value={formData.name} onChange={e => setFormData({...formData, name: e.target.value})} style={styles.input} /></div>
              <div style={styles.formGroup}><label style={styles.label}>Phone Number</label><input value={formData.phone} onChange={e => setFormData({...formData, phone: e.target.value})} style={styles.input} /></div>
              <div style={styles.formGroup}><label style={styles.label}>Date of Birth</label><input type="date" value={formData.dob} onChange={e => setFormData({...formData, dob: e.target.value})} style={styles.input} /></div>
              <div style={styles.formGroup}>
                <label style={styles.label}>Gender</label>
                <select value={formData.gender} onChange={e => setFormData({...formData, gender: e.target.value})} style={styles.input}><option>Male</option><option>Female</option><option>Other</option></select>
              </div>
            </div>
            
            <div style={styles.formGroup}>
              <label style={styles.label}>Profile Photo URL</label>
              <input value={formData.photoUrl} onChange={e => setFormData({...formData, photoUrl: e.target.value})} style={styles.input} />
            </div>

            <div style={styles.formGroup}>
              <label style={styles.label}>Upload Profile Photo</label>
              <input type="file" accept="image/*" onChange={handlePhotoUpload} style={styles.inputFile} />
            </div>

            <h2 style={{ fontSize: 20, fontWeight: 800, textTransform: "uppercase", marginTop: 40, marginBottom: 24, letterSpacing: 1, borderTop: "1px solid rgba(255,255,255,0.05)", paddingTop: 40 }}>Security</h2>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 20, marginBottom: 32 }}>
              <div style={styles.formGroup}><label style={styles.label}>Current Password</label><input type="password" placeholder="••••••••" style={styles.input} /></div>
              <div style={styles.formGroup}><label style={styles.label}>New Password</label><input type="password" placeholder="••••••••" style={styles.input} /></div>
            </div>

            <button type="submit" className="btn-glow" style={{ background: "#e8ff47", color: "#000", border: "none", padding: "16px 32px", borderRadius: 8, fontSize: 14, fontWeight: 900, textTransform: "uppercase", letterSpacing: 1, cursor: "pointer" }}>Save Changes</button>
          </form>

          <div className="card" style={{ padding: 40, border: "1px solid rgba(255,71,71,0.2)", background: "rgba(255,71,71,0.02)" }}>
            <h2 style={{ fontSize: 20, fontWeight: 800, textTransform: "uppercase", marginBottom: 12, letterSpacing: 1, color: "#ff4747" }}>Danger Zone</h2>
            <p style={{ color: "rgba(255,255,255,0.6)", fontSize: 14, marginBottom: 24 }}>Once you delete your account, there is no going back. Please be certain.</p>
            <button type="button" onClick={handleDelete} style={{ background: "transparent", color: "#ff4747", border: "1px solid #ff4747", padding: "12px 24px", borderRadius: 8, fontSize: 13, fontWeight: 800, textTransform: "uppercase", letterSpacing: 1, cursor: "pointer", transition: "all 0.2s" }} onMouseEnter={e => {e.currentTarget.style.background = "#ff4747"; e.currentTarget.style.color = "#fff"}} onMouseLeave={e => {e.currentTarget.style.background = "transparent"; e.currentTarget.style.color = "#ff4747"}}>Delete Account</button>
          </div>
        </div>
      </div>
    </div>
  );
}

const styles = {
  formGroup: { display: "flex", flexDirection: "column", gap: 8 },
  label: { fontSize: 12, textTransform: "uppercase", letterSpacing: 1, color: "rgba(255,255,255,0.5)", fontWeight: 700 },
  input: { background: "#050505", border: "1px solid rgba(255,255,255,0.1)", color: "#fff", padding: "14px 16px", borderRadius: 8, fontSize: 14, fontFamily: "Inter", outline: "none", boxSizing: "border-box" },
  inputFile: { background: "#050505", border: "1px solid rgba(255,255,255,0.1)", color: "#fff", padding: "12px 16px", borderRadius: 8, fontSize: 14, fontFamily: "Inter", outline: "none", boxSizing: "border-box" }
};
