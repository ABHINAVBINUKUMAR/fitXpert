import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Star, ShieldCheck, Calendar, Clock, User, CheckCircle2, X } from "lucide-react";
import { apiFetch } from "../../lib/api";
import { useAuth } from "../../context/AuthContext";

const TRAINERS = [
  { id: 1, name: "Marcus Steele", specialty: "Strength", rating: 4.9, exp: "8 Yrs", price: 800, img: "https://images.unsplash.com/photo-1567013127542-490d757e51fc?w=400&q=80", bio: "Former powerlifting champion specializing in raw strength and hypertrophy.", certs: ["NSCA-CSCS", "CrossFit L2"] },
  { id: 2, name: "Aria Chen", specialty: "HIIT", rating: 4.8, exp: "5 Yrs", price: 600, img: "https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?w=400&q=80", bio: "High-energy coach focused on fat loss, endurance and athletic conditioning.", certs: ["ACE Certified", "Kettlebell L1"] },
  { id: 3, name: "Dev Ramos", specialty: "MMA", rating: 4.9, exp: "12 Yrs", price: 1000, img: "https://images.unsplash.com/photo-1583454110551-21f2fa2afe61?w=400&q=80", bio: "Active professional fighter teaching striking and grappling fundamentals.", certs: ["Pro Fighter", "BJJ Brown Belt"] },
  { id: 4, name: "Elena Rostova", specialty: "Yoga", rating: 5.0, exp: "10 Yrs", price: 700, img: "https://images.unsplash.com/photo-1518611012118-696072aa579a?w=400&q=80", bio: "Mobility and recovery expert helping athletes move pain-free.", certs: ["RYT 500", "FMS Certified"] },
  { id: 5, name: "Tyson King", specialty: "Strength", rating: 4.7, exp: "6 Yrs", price: 750, img: "https://images.unsplash.com/photo-1534438327276-14e5300c3a48?w=400&q=80", bio: "Bodybuilding prep coach focusing on aesthetics and symmetry.", certs: ["ISSA Master", "Nutritionist"] },
  { id: 6, name: "Sarah Jenkins", specialty: "Nutrition", rating: 4.9, exp: "7 Yrs", price: 650, img: "https://images.unsplash.com/photo-1594381898411-846e7d193883?w=400&q=80", bio: "Registered dietitian helping you fuel performance and hit macros.", certs: ["Registered Dietitian", "Sports Nutrition"] },
  { id: 7, name: "Jimmy 'Flash'", specialty: "HIIT", rating: 4.6, exp: "4 Yrs", price: 550, img: "https://images.unsplash.com/photo-1599058917212-d750089bc07e?w=400&q=80", bio: "Explosive athletic training designed to make you faster and leaner.", certs: ["NASM-CPT", "USA Weightlifting"] },
  { id: 8, name: "Maya Patel", specialty: "Yoga", rating: 4.9, exp: "9 Yrs", price: 700, img: "https://images.unsplash.com/photo-1544367567-0f2fcb009e0b?w=400&q=80", bio: "Vinyasa flow teacher bridging mindfulness with rigorous physical practice.", certs: ["E-RYT 200", "Pilates Method"] }
];

const MY_BOOKINGS = [
  { id: 101, trainer: "Marcus Steele", type: "1:1 Session", date: "2026-03-24", time: "07:00 AM", status: "Upcoming" },
  { id: 102, trainer: "Aria Chen", type: "Group Class", date: "2026-03-20", time: "06:00 PM", status: "Completed" },
  { id: 103, trainer: "Elena Rostova", type: "1:1 Session", date: "2026-03-15", time: "08:00 AM", status: "Completed" }
];

export default function Trainers() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState("all_trainers");
  const [filter, setFilter] = useState("All");
  const [bookingModal, setBookingModal] = useState(null);
  const [toast, setToast] = useState(false);

  // Form states
  const [date, setDate] = useState("");
  const [time, setTime] = useState("Morning (6AM - 11AM)");
  const [type, setType] = useState("1:1 Personal");
  const [notes, setNotes] = useState("");

  const filteredTrainers = filter === "All" ? TRAINERS : TRAINERS.filter(t => t.specialty === filter);

  const handleBook = async (e) => {
    e.preventDefault();

    if (!user) {
      navigate("/login/member");
      return;
    }

    try {
      const response = await apiFetch("/bookings", {
        method: "POST",
        body: {
          trainer_name: bookingModal.name,
          session_type: type,
          booking_date: date,
          booking_time: time,
          amount: bookingModal.price,
          notes: notes || `Session for ${bookingModal.specialty}`,
        },
      });

      const bookingId = response.booking?.id;
      setBookingModal(null);
      setToast(true);
      setTimeout(() => setToast(false), 2000);

      navigate(`/user/payments?payTo=${encodeURIComponent(bookingModal.name)}&amount=${bookingModal.price}&item=${encodeURIComponent(`${bookingModal.specialty} Session`)}&booking_id=${bookingId}`);
    } catch (error) {
      setToast(`Booking failed: ${error.message}`);
      setTimeout(() => setToast(false), 3000);
    }
  };

  return (
    <div>
      <h1 style={{ fontSize: 56, textTransform: "uppercase", fontWeight: 900, marginBottom: 40, letterSpacing: -1 }}>
        Elite <span className="gradient-text">Coaches</span>
      </h1>

      <div style={{ display: "flex", gap: 16, marginBottom: 40 }}>
        <button className={activeTab === 'all_trainers' ? 'tab-btn active' : 'tab-btn'} onClick={() => setActiveTab('all_trainers')}>Directory</button>
        <button className={activeTab === 'my_bookings' ? 'tab-btn active' : 'tab-btn'} onClick={() => setActiveTab('my_bookings')}>My Bookings</button>
      </div>

      {activeTab === 'all_trainers' && (
        <>
          {/* FILTERS */}
          <div style={{ display: "flex", gap: 12, marginBottom: 32, overflowX: "auto", paddingBottom: 8 }}>
            {["All", "Strength", "HIIT", "Yoga", "MMA", "Nutrition"].map(f => (
              <button 
                key={f}
                onClick={() => setFilter(f)}
                style={{ 
                  background: filter === f ? "#e8ff47" : "transparent",
                  color: filter === f ? "#000" : "#fff",
                  border: filter === f ? "1px solid #e8ff47" : "1px solid rgba(255,255,255,0.2)",
                  padding: "10px 24px", borderRadius: 100, fontSize: 13, fontWeight: 800, 
                  textTransform: "uppercase", letterSpacing: 1, cursor: "pointer", transition: "all 0.2s"
                }}
              >
                {f}
              </button>
            ))}
          </div>

          {/* GRID */}
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(280px, 1fr))", gap: 32 }}>
            {filteredTrainers.map(t => (
              <div key={t.id} className="card trainer-card" style={{ overflow: "hidden", display: "flex", flexDirection: "column" }}>
                <div style={{ height: 300, background: "#222", position: "relative" }}>
                  <img src={t.img} alt={t.name} style={{ width: "100%", height: "100%", objectFit: "cover" }} />
                  <div style={{ position: "absolute", top: 12, right: 12, background: "rgba(0,0,0,0.7)", backdropFilter: "blur(4px)", padding: "6px 14px", borderRadius: 20, display: "flex", alignItems: "center", gap: 6, color: "#e8ff47", fontSize: 14, fontWeight: 700 }}>
                    <Star size={16} fill="#e8ff47" /> {t.rating}
                  </div>
                  <div style={{ position: "absolute", bottom: 16, left: 16, background: "#e8ff47", color: "#000", padding: "6px 14px", borderRadius: 6, fontSize: 11, fontWeight: 900, textTransform: "uppercase", letterSpacing: 2 }}>
                    {t.specialty}
                  </div>
                </div>
                <div style={{ padding: "24px", flex: 1, display: "flex", flexDirection: "column" }}>
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 16 }}>
                    <div>
                      <h3 style={{ fontSize: 26, fontWeight: 800, margin: 0, letterSpacing: -0.5 }}>{t.name}</h3>
                      <div style={{ fontSize: 13, color: "rgba(255,255,255,0.4)", marginTop: 6, textTransform: "uppercase", letterSpacing: 1, fontWeight: 600 }}>{t.exp} Experience</div>
                    </div>
                    <div style={{ fontSize: 24, fontWeight: 900, color: "#e8ff47" }}>₹{t.price}<span style={{fontSize: 14, color: "rgba(255,255,255,0.4)", fontWeight: 600}}>/hr</span></div>
                  </div>
                  <p style={{ fontSize: 15, color: "rgba(255,255,255,0.6)", fontFamily: "Inter", lineHeight: 1.5, flex: 1, marginBottom: 20 }}>{t.bio}</p>
                  
                  <div style={{ display: "flex", flexWrap: "wrap", gap: 8, marginBottom: 24 }}>
                    {t.certs.map(c => (
                      <span key={c} style={{ fontSize: 12, background: "rgba(255,255,255,0.06)", padding: "6px 10px", borderRadius: 6, display: "flex", alignItems: "center", gap: 6, letterSpacing: 0.5, fontWeight: 500 }}>
                        <ShieldCheck size={14} color="#e8ff47" /> {c}
                      </span>
                    ))}
                  </div>

                  <button 
                    onClick={() => setBookingModal(t)}
                    className="btn-glow" 
                    style={{ width: "100%", background: "#1a1a1a", color: "#e8ff47", border: "1px solid rgba(232,255,71,0.5)", padding: "16px", borderRadius: 8, fontSize: 15, fontWeight: 800, textTransform: "uppercase", letterSpacing: 2, cursor: "pointer", transition: "all 0.2s" }}
                  >
                    Book Session
                  </button>
                </div>
              </div>
            ))}
          </div>
        </>
      )}

      {activeTab === 'my_bookings' && (
        <div className="card" style={{ overflow: "hidden" }}>
          <table style={{ width: "100%", borderCollapse: "collapse", textAlign: "left" }}>
            <thead>
              <tr style={{ background: "#151515", borderBottom: "1px solid rgba(255,255,255,0.05)" }}>
                <th style={{ padding: "24px 32px", fontSize: 13, textTransform: "uppercase", letterSpacing: 2, color: "rgba(255,255,255,0.5)", fontWeight: 700 }}>Trainer</th>
                <th style={{ padding: "24px 32px", fontSize: 13, textTransform: "uppercase", letterSpacing: 2, color: "rgba(255,255,255,0.5)", fontWeight: 700 }}>Date & Time</th>
                <th style={{ padding: "24px 32px", fontSize: 13, textTransform: "uppercase", letterSpacing: 2, color: "rgba(255,255,255,0.5)", fontWeight: 700 }}>Type</th>
                <th style={{ padding: "24px 32px", fontSize: 13, textTransform: "uppercase", letterSpacing: 2, color: "rgba(255,255,255,0.5)", fontWeight: 700 }}>Status</th>
              </tr>
            </thead>
            <tbody>
              {MY_BOOKINGS.map((b, i) => (
                <tr key={b.id} style={{ borderBottom: i === MY_BOOKINGS.length - 1 ? "none" : "1px solid rgba(255,255,255,0.05)", background: b.status === "Upcoming" ? "rgba(232,255,71,0.02)" : "transparent" }}>
                  <td style={{ padding: "24px 32px", fontSize: 20, fontWeight: 800 }}>{b.trainer}</td>
                  <td style={{ padding: "24px 32px", fontFamily: "Inter", fontSize: 15, color: "rgba(255,255,255,0.8)" }}>{b.date} &nbsp;•&nbsp; <span style={{color: "#e8ff47"}}>{b.time}</span></td>
                  <td style={{ padding: "24px 32px", fontFamily: "Inter", fontSize: 15, color: "rgba(255,255,255,0.8)" }}>{b.type}</td>
                  <td style={{ padding: "24px 32px" }}>
                    <span style={{ 
                      padding: "8px 16px", borderRadius: 100, fontSize: 11, fontWeight: 900, textTransform: "uppercase", letterSpacing: 2,
                      background: b.status === "Upcoming" ? "rgba(232, 255, 71, 0.1)" : "rgba(255, 255, 255, 0.05)",
                      color: b.status === "Upcoming" ? "#e8ff47" : "rgba(255,255,255,0.4)",
                      border: b.status === "Upcoming" ? "1px solid rgba(232, 255, 71, 0.3)" : "none"
                    }}>
                      {b.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* BOOKING MODAL */}
      {bookingModal && (
        <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.85)", zIndex: 9999, display: "flex", alignItems: "center", justifyContent: "center", backdropFilter: "blur(6px)" }} onClick={() => setBookingModal(null)}>
          <div className="card modal-content" onClick={e => e.stopPropagation()} style={{ width: 500, padding: 48, position: "relative", background: "#111", border: "1px solid rgba(232,255,71,0.2)" }}>
            <button style={{ position: "absolute", top: 24, right: 24, background: "none", border: "none", color: "rgba(255,255,255,0.5)", cursor: "pointer", transition: "color 0.2s" }} onMouseEnter={e => e.currentTarget.style.color = "#fff"} onMouseLeave={e => e.currentTarget.style.color = "rgba(255,255,255,0.5)"} onClick={() => setBookingModal(null)}>
              <X size={28} />
            </button>
            <h2 style={{ fontSize: 36, fontWeight: 900, textTransform: "uppercase", marginBottom: 8, letterSpacing: -0.5 }}>Book Session</h2>
            <div style={{ fontSize: 16, color: "rgba(255,255,255,0.6)", marginBottom: 32, display: "flex", alignItems: "center", gap: 8, paddingBottom: 24, borderBottom: "1px solid rgba(255,255,255,0.05)" }}>
              <span>With <strong style={{color:"#fff"}}>{bookingModal.name}</strong></span>
              <span style={{color: "#e8ff47"}}>•</span>
              <span style={{textTransform: "uppercase", letterSpacing: 1, fontSize: 13, fontWeight: 700, color: "#e8ff47"}}>{bookingModal.specialty}</span>
              <span style={{color: "#e8ff47"}}>•</span>
              <span style={{fontWeight: 700, color: "#fff"}}>₹{bookingModal.price}</span>
            </div>
            
            <form onSubmit={handleBook} style={{ display: "flex", flexDirection: "column", gap: 24 }}>
              <div style={styles.formGroup}>
                <label style={styles.label}><Calendar size={18} color="#e8ff47" /> Date</label>
                <input type="date" required style={styles.input} value={date} onChange={e=>setDate(e.target.value)} />
              </div>
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 24 }}>
                <div style={styles.formGroup}>
                  <label style={styles.label}><Clock size={18} color="#e8ff47" /> Time</label>
                  <select style={styles.input} value={time} onChange={e=>setTime(e.target.value)}>
                    <option>Morning (6AM - 11AM)</option>
                    <option>Afternoon (12PM - 4PM)</option>
                    <option>Evening (5PM - 9PM)</option>
                  </select>
                </div>
                <div style={styles.formGroup}>
                  <label style={styles.label}><User size={18} color="#e8ff47" /> Session Type</label>
                  <select style={styles.input} value={type} onChange={e=>setType(e.target.value)}>
                    <option>1:1 Personal</option>
                    <option>Small Group (Max 3)</option>
                    <option>Online Virtual</option>
                  </select>
                </div>
              </div>
              <div style={styles.formGroup}>
                <label style={styles.label}>Goal / Notes for Coach</label>
                <textarea rows={3} style={{...styles.input, resize: "none"}} placeholder="Any specific focus for this session?..." value={notes} onChange={e=>setNotes(e.target.value)} />
              </div>
              <button type="submit" className="btn-glow" style={{ background: "#e8ff47", color: "#000", border: "none", padding: "20px", borderRadius: 8, fontSize: 16, fontWeight: 900, textTransform: "uppercase", letterSpacing: 2, cursor: "pointer", marginTop: 24 }}>
                Confirm & Pay Later
              </button>
            </form>
          </div>
        </div>
      )}

      {toast && (
        <div style={{ position: "fixed", bottom: 32, right: 120, background: "#e8ff47", color: "#000", padding: "16px 24px", borderRadius: 8, fontWeight: 700, fontSize: 16, display: "flex", alignItems: "center", gap: 12, animation: "slideInLeft 0.3s ease", zIndex: 9999, boxShadow: "0 12px 32px rgba(232,255,71,0.2)", textTransform: "uppercase", letterSpacing: 1 }}>
          <CheckCircle2 size={24} /> Session Booked successfully!
        </div>
      )}

      <style>{`
        .tab-btn { padding: 14px 28px; background: transparent; color: rgba(255,255,255,0.4); border: 1px solid rgba(255,255,255,0.1); border-radius: 8px; font-size: 15px; font-weight: 800; text-transform: uppercase; letter-spacing: 2px; cursor: pointer; transition: all 0.2s; }
        .tab-btn:hover { border-color: rgba(255,255,255,0.4); color: #fff; }
        .tab-btn.active { background: rgba(232,255,71,0.1); border-color: #e8ff47; color: #e8ff47; }
        .trainer-card:hover { transform: translateY(-4px) scale(1.01); border-color: rgba(232,255,71,0.3); }
        .trainer-card button:hover { background: #e8ff47 !important; color: #000 !important; }
        .modal-content { animation: modalScale 0.4s cubic-bezier(0.16, 1, 0.3, 1); }
        @keyframes modalScale { from { opacity: 0; transform: scale(0.95) translateY(20px); } to { opacity: 1; transform: scale(1) translateY(0); } }
        @keyframes slideInLeft { from { opacity: 0; transform: translateX(50px); } to { opacity: 1; transform: translateX(0); } }
        input[type="date"]::-webkit-calendar-picker-indicator { filter: invert(1); cursor: pointer; }
      `}</style>
    </div>
  );
}

const styles = {
  formGroup: { display: "flex", flexDirection: "column", gap: 10 },
  label: { fontSize: 14, textTransform: "uppercase", letterSpacing: 1, color: "rgba(255,255,255,0.6)", fontWeight: 700, display: "flex", alignItems: "center", gap: 10 },
  input: { background: "#080808", border: "1px solid rgba(255,255,255,0.1)", color: "#fff", padding: "16px 20px", borderRadius: 8, fontSize: 15, fontFamily: "Inter", outline: "none", transition: "border-color 0.2s" }
};
