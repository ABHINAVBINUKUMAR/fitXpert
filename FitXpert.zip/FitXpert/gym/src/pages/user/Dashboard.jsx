import { Users, Activity, Target, Flame } from "lucide-react";
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer } from "recharts";

const data = [
  { name: "Mon", visitors: 400 },
  { name: "Tue", visitors: 300 },
  { name: "Wed", visitors: 550 },
  { name: "Thu", visitors: 450 },
  { name: "Fri", visitors: 600 },
  { name: "Sat", visitors: 800 },
  { name: "Sun", visitors: 750 },
];

export default function Dashboard() {
  return (
    <div>
      <h1 style={{ fontSize: 56, textTransform: "uppercase", fontWeight: 900, marginBottom: 40, letterSpacing: -1 }}>
        Dashboard <span className="gradient-text">Overview</span>
      </h1>
      
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(240px, 1fr))", gap: 24, marginBottom: 40 }}>
        <StatCard title="Active Members" value="12,450" icon={<Users color="#e8ff47" size={28} />} trend="+12% this month" />
        <StatCard title="Avg Attendance" value="84%" icon={<Activity color="#e8ff47" size={28} />} trend="+5% this week" />
        <StatCard title="Active Trainers" value="24" icon={<Target color="#e8ff47" size={28} />} trend="Fully staffed" />
        <StatCard title="Calories Burned" value="1.2M" icon={<Flame color="#e8ff47" size={28} />} trend="Global Gym Stat" />
      </div>

      <div className="card" style={{ padding: 32, height: 400 }}>
        <h3 style={{ fontSize: 24, fontWeight: 700, marginBottom: 24, textTransform: "uppercase", letterSpacing: 1 }}>Weekly Footfall</h3>
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart data={data} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
            <defs>
              <linearGradient id="colorVis" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#e8ff47" stopOpacity={0.4}/>
                <stop offset="95%" stopColor="#e8ff47" stopOpacity={0}/>
              </linearGradient>
            </defs>
            <XAxis dataKey="name" stroke="rgba(255,255,255,0.2)" tick={{ fill: "rgba(255,255,255,0.5)", fontFamily: "Inter" }} />
            <YAxis stroke="rgba(255,255,255,0.2)" tick={{ fill: "rgba(255,255,255,0.5)", fontFamily: "Inter" }} />
            <Tooltip 
              contentStyle={{ backgroundColor: "#111", border: "1px solid rgba(232,255,71,0.3)", borderRadius: 8, color: "#fff", fontFamily: "Inter" }}
              itemStyle={{ color: "#e8ff47", fontWeight: "bold" }}
            />
            <Area type="monotone" dataKey="visitors" stroke="#e8ff47" strokeWidth={3} fillOpacity={1} fill="url(#colorVis)" />
          </AreaChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}

function StatCard({ title, value, icon, trend }) {
  return (
    <div className="card" style={{ padding: 24, display: "flex", flexDirection: "column", gap: 16 }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
        <div style={{ fontSize: 13, color: "rgba(255,255,255,0.4)", textTransform: "uppercase", letterSpacing: 2, fontWeight: 700 }}>{title}</div>
        <div style={{ padding: 8, background: "rgba(232,255,71,0.1)", borderRadius: 8 }}>{icon}</div>
      </div>
      <div style={{ fontSize: 52, fontWeight: 900, color: "#fff", lineHeight: 1 }}>{value}</div>
      <div style={{ fontSize: 13, color: "#e8ff47", fontWeight: 600, fontFamily: "Inter" }}>{trend}</div>
    </div>
  );
}
