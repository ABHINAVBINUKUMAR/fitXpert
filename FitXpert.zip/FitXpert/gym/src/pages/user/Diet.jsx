import { useState } from "react";
import { Link } from "react-router-dom";
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip } from "recharts";
import { Droplets, Pill, CheckCircle2, ShoppingCart } from "lucide-react";

const MACROS = [
  { name: "Protein", value: 35, color: "#e8ff47" },
  { name: "Carbs", value: 45, color: "#4caf50" },
  { name: "Fats", value: 20, color: "#ff9800" },
];

const MEAL_PLAN = {
  Breakfast: [
    { name: "Oatmeal with Whey Protein & Berries", calories: 420, p: 35, c: 50, f: 8 },
    { name: "3 Whole Eggs + 2 Toast", calories: 380, p: 24, c: 30, f: 18 }
  ],
  Lunch: [
    { name: "Grilled Chicken Breast & Quinoa", calories: 550, p: 50, c: 60, f: 12 },
    { name: "Lentil Soup with Brown Rice", calories: 480, p: 22, c: 80, f: 8 }
  ],
  Snacks: [
    { name: "Greek Yogurt & Almonds", calories: 250, p: 20, c: 15, f: 12 },
    { name: "Apple with Peanut Butter", calories: 280, p: 8, c: 30, f: 16 }
  ],
  Dinner: [
    { name: "Baked Salmon & Sweet Potato", calories: 600, p: 45, c: 40, f: 26 },
    { name: "Tofu Stir-fry with Veggies", calories: 400, p: 25, c: 35, f: 18 }
  ]
};

export default function Diet() {
  const [form, setForm] = useState({
    goal: "Muscle Gain",
    body: "Mesomorph",
    pref: "Non-Vegetarian",
    allergies: "None",
    weight: "75",
    height: "175"
  });

  const [result, setResult] = useState(null);
  const [toast, setToast] = useState(false);
  const [mealsLogged, setMealsLogged] = useState(false);

  const calculateBMI = (w, h) => {
    const heightM = h / 100;
    const bmi = (w / (heightM * heightM)).toFixed(1);
    let category = "Normal Weight";
    let offset = 50; // percentage on visual scale

    if (bmi < 18.5) { category = "Underweight"; offset = 15; }
    else if (bmi >= 18.5 && bmi < 25) { category = "Normal Weight"; offset = 50; }
    else if (bmi >= 25 && bmi < 30) { category = "Overweight"; offset = 75; }
    else { category = "Obese"; offset = 90; }

    return { bmi, category, offset };
  };

  const calculateDiet = (w, h, goal) => {
    const bmr = 10 * w + 6.25 * h - 120;
    const tdee = bmr * 1.55;
    let targetCals = tdee;
    if (goal === "Muscle Gain") targetCals += 500;
    else if (goal === "Weight Loss") targetCals -= 500;
    return Math.round(targetCals);
  };

  const handleGenerate = (e) => {
    e.preventDefault();
    const w = parseFloat(form.weight);
    const h = parseFloat(form.height);
    if (!w || !h) return;

    const targetCals = calculateDiet(w, h, form.goal);
    let macros = [
      { name: "Protein", value: 35, color: "#e8ff47" },
      { name: "Carbs", value: 45, color: "#4caf50" },
      { name: "Fats", value: 20, color: "#ff9800" },
    ];
    if (form.goal === "Muscle Gain") {
      macros = [
        { name: "Protein", value: 40, color: "#e8ff47" },
        { name: "Carbs", value: 40, color: "#4caf50" },
        { name: "Fats", value: 20, color: "#ff9800" },
      ];
    } else if (form.goal === "Weight Loss") {
      macros = [
        { name: "Protein", value: 50, color: "#e8ff47" },
        { name: "Carbs", value: 20, color: "#4caf50" },
        { name: "Fats", value: 30, color: "#ff9800" },
      ];
    }

    setResult({
      bmiInfo: calculateBMI(w, h),
      water: Math.round(w * 0.04 * 10) / 10, // ~40ml per kg
      supps: form.goal === "Muscle Gain" ? ["Whey Protein Isolate", "Creatine", "Omega-3"] : ["Multivitamin", "Omega-3", "Green Tea Ex."],
      targetCals,
      macros
    });

    setToast("Diet Plan Generated!");
    setTimeout(() => setToast(false), 3000);
  };

  const logMeals = () => {
    if (mealsLogged) return;
    setMealsLogged(true);

    const currentXp = parseInt(localStorage.getItem('fitxpert_xp') || "2400", 10);
    localStorage.setItem('fitxpert_xp', currentXp + 50);

    const badges = JSON.parse(localStorage.getItem('fitxpert_badges') || "[]");
    if (!badges.includes(4)) {
      badges.push(4); // Clean Eater badge
      localStorage.setItem('fitxpert_badges', JSON.stringify(badges));
      setToast('Meals Logged! +50 XP and "Clean Eater" Badge Unlocked!');
    } else {
      setToast('Meals Logged! +50 XP!');
    }

    setTimeout(() => setToast(false), 3000);
  };

  return (
    <div>
      <h1 style={{ fontSize: 56, textTransform: "uppercase", fontWeight: 900, marginBottom: 40, letterSpacing: -1 }}>
        Nutrition & <span className="gradient-text">Diet Plan</span>
      </h1>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 2fr", gap: 40, alignItems: "start" }}>

        {/* PARAMS CARD */}
        <div className="card" style={{ padding: 48, position: "sticky", top: 40 }}>
          <h3 style={{ fontSize: 26, fontWeight: 800, margin: "0 0 32px", textTransform: "uppercase", letterSpacing: 1 }}>Your Profile</h3>
          <form onSubmit={handleGenerate} style={{ display: "flex", flexDirection: "column", gap: 24 }}>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16 }}>
              <div style={styles.formGroup}>
                <label style={styles.label}>Weight (kg)</label>
                <input type="number" style={styles.input} value={form.weight} onChange={e => setForm({ ...form, weight: e.target.value })} required />
              </div>
              <div style={styles.formGroup}>
                <label style={styles.label}>Height (cm)</label>
                <input type="number" style={styles.input} value={form.height} onChange={e => setForm({ ...form, height: e.target.value })} required />
              </div>
            </div>
            <div style={styles.formGroup}>
              <label style={styles.label}>Goal</label>
              <select style={styles.select} value={form.goal} onChange={e => setForm({ ...form, goal: e.target.value })}>
                <option>Weight Loss</option><option>Muscle Gain</option><option>Maintenance</option><option>Endurance</option>
              </select>
            </div>
            <div style={styles.formGroup}>
              <label style={styles.label}>Food Preference</label>
              <select style={styles.select} value={form.pref} onChange={e => setForm({ ...form, pref: e.target.value })}>
                <option>Non-Vegetarian</option><option>Vegetarian</option>
              </select>
            </div>
            <button type="submit" className="btn-glow" style={{ ...styles.submitBtn, marginTop: 16 }}>
              Generate Plan
            </button>
            {result && (
              <Link to="/user/payments?payTo=FitXpert&amount=499&item=Personalized+Diet+Plan" className="btn-glow" style={{ ...styles.submitBtn, marginTop: 0, background: "transparent", color: "#e8ff47", border: "1.5px solid #e8ff47", textDecoration: "none", textAlign: "center", display: "flex", alignItems: "center", justifyContent: "center", gap: 10 }}>
                <ShoppingCart size={20} /> Buy Full Plan (₹499)
              </Link>
            )}
          </form>
        </div>

        {/* RESULTS AREA */}
        {result ? (
          <div style={{ animation: "fadeIn 0.5s ease", display: "flex", flexDirection: "column", gap: 40 }}>

            {/* STATS HEADER */}
            <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(240px, 1fr))", gap: 24 }}>
              {/* BMI CHART */}
              <div className="card" style={{ padding: "32px 32px", display: "flex", flexDirection: "column", justifyContent: "space-between" }}>
                <div style={{ fontSize: 13, textTransform: "uppercase", letterSpacing: 2, fontWeight: 700, color: "rgba(255,255,255,0.5)", marginBottom: 16 }}>BMI Index</div>
                <div style={{ fontSize: 56, fontWeight: 900, color: "#fff", lineHeight: 1 }}>{result.bmiInfo.bmi}</div>
                <div style={{ fontSize: 18, color: "#e8ff47", fontWeight: 700, marginTop: 8, textTransform: "uppercase" }}>{result.bmiInfo.category}</div>

                <div style={{ marginTop: 24, height: 10, background: "linear-gradient(to right, #00bcd4, #4caf50, #ff9800, #ff4747)", borderRadius: 5, position: "relative" }}>
                  <div style={{ position: "absolute", top: -7, left: "calc(" + result.bmiInfo.offset + "% - 12px)", width: 24, height: 24, background: "#fff", border: "4px solid #000", borderRadius: 12, transition: "left 0.8s cubic-bezier(0.4, 0, 0.2, 1)" }} />
                </div>
              </div>

              {/* WATER */}
              <div className="card" style={{ padding: "32px", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", textAlign: "center" }}>
                <Droplets size={48} color="#00bcd4" style={{ marginBottom: 16 }} />
                <div style={{ fontSize: 13, textTransform: "uppercase", letterSpacing: 2, fontWeight: 700, color: "rgba(255,255,255,0.5)", marginBottom: 12 }}>Daily Water Target</div>
                <div style={{ fontSize: 48, fontWeight: 900, color: "#fff" }}>{result.water} <span style={{ fontSize: 24, color: "rgba(255,255,255,0.4)" }}>L</span></div>
              </div>

              {/* SUPPS */}
              <div className="card" style={{ padding: "32px" }}>
                <div style={{ fontSize: 13, textTransform: "uppercase", letterSpacing: 2, fontWeight: 700, color: "rgba(255,255,255,0.5)", marginBottom: 24, display: "flex", alignItems: "center", gap: 10 }}>
                  <Pill size={18} color="#e8ff47" /> Supplements
                </div>
                <ul style={{ listStyle: "none", padding: 0, margin: 0, display: "flex", flexDirection: "column", gap: 16 }}>
                  {result.supps.map((s, i) => (
                    <li key={i} style={{ display: "flex", alignItems: "center", gap: 12, fontWeight: 700, fontSize: 16, color: "#fff" }}>
                      <CheckCircle2 size={18} color="#e8ff47" /> {s}
                    </li>
                  ))}
                </ul>
              </div>
            </div>

            {/* MEAL PLAN + MACROS */}
            <div style={{ display: "grid", gridTemplateColumns: "1.5fr 1fr", gap: 32 }}>

              <div className="card" style={{ padding: 40 }}>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 32 }}>
                  <h3 style={{ fontSize: 26, fontWeight: 800, textTransform: "uppercase", letterSpacing: 1, margin: 0 }}>Your 7-Day Menu</h3>
                  <button onClick={logMeals} disabled={mealsLogged} className="btn-glow" style={{ background: mealsLogged ? "#4caf50" : "#e8ff47", color: mealsLogged ? "#fff" : "#000", border: "none", padding: "10px 20px", borderRadius: 8, fontWeight: 800, cursor: mealsLogged ? "default" : "pointer", display: "flex", alignItems: "center", gap: 8, fontSize: 13, textTransform: "uppercase" }}>
                    {mealsLogged ? <><CheckCircle2 size={16} /> Logged</> : "Log Today's Meals"}
                  </button>
                </div>
                <div style={{ display: "flex", flexDirection: "column", gap: 32 }}>
                  {Object.entries(MEAL_PLAN).map(([mealName, options], i) => (
                    <div key={mealName} style={{ borderBottom: i < 3 ? "1px solid rgba(255,255,255,0.05)" : "none", paddingBottom: i < 3 ? 32 : 0 }}>
                      <div style={{ fontSize: 18, fontWeight: 800, textTransform: "uppercase", color: "#e8ff47", marginBottom: 20, letterSpacing: 1 }}>{mealName}</div>

                      <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
                        {options.map((opt, j) => {
                          if (form.pref === "Vegetarian" && opt.name.includes("Chicken") || form.pref === "Vegetarian" && opt.name.includes("Salmon")) return null;
                          const ratio = result.targetCals / 2400;
                          const adjustedCals = Math.round(opt.calories * ratio);
                          const adjP = Math.round(opt.p * ratio);
                          const adjC = Math.round(opt.c * ratio);
                          const adjF = Math.round(opt.f * ratio);
                          return (
                            <div key={j} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", background: "#181818", padding: "20px 24px", borderRadius: 12 }}>
                              <div>
                                <div style={{ fontSize: 17, fontWeight: 700, color: "#fff", marginBottom: 6 }}>{opt.name}</div>
                                <div style={{ fontSize: 14, color: "rgba(255,255,255,0.5)", fontFamily: "Inter", display: "flex", gap: 20, fontWeight: 500 }}>
                                  <span>P: <strong style={{ color: "#fff" }}>{adjP}g</strong></span>
                                  <span>C: <strong style={{ color: "#fff" }}>{adjC}g</strong></span>
                                  <span>F: <strong style={{ color: "#fff" }}>{adjF}g</strong></span>
                                </div>
                              </div>
                              <div style={{ fontSize: 28, fontWeight: 900, color: "#e8ff47", display: "flex", alignItems: "baseline", gap: 4 }}>
                                {adjustedCals} <span style={{ fontSize: 14, color: "rgba(255,255,255,0.4)", fontWeight: 700 }}>KCAL</span>
                              </div>
                            </div>
                          )
                        })}
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="card" style={{ padding: 40, height: "fit-content" }}>
                <h3 style={{ fontSize: 22, fontWeight: 800, marginBottom: 32, textTransform: "uppercase", textAlign: "center", letterSpacing: 1 }}>Macro Distribution</h3>
                <div style={{ height: 280, position: "relative" }}>
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={result.macros}
                        innerRadius={80}
                        outerRadius={110}
                        paddingAngle={5}
                        dataKey="value"
                        stroke="none"
                      >
                        {result.macros.map((entry, index) => (
                          <Cell key={"cell-" + index} fill={entry.color} />
                        ))}
                      </Pie>
                      <Tooltip
                        contentStyle={{ backgroundColor: "#111", border: "1px solid rgba(232,255,71,0.3)", borderRadius: 8, color: "#fff", fontFamily: "Inter" }}
                        itemStyle={{ color: "#fff", fontWeight: "bold" }}
                      />
                    </PieChart>
                  </ResponsiveContainer>
                  <div style={{ position: "absolute", inset: 0, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", pointerEvents: "none" }}>
                    <div style={{ fontSize: 44, fontWeight: 900, color: "#fff", lineHeight: 1 }}>{result.targetCals}</div>
                    <div style={{ fontSize: 14, fontWeight: 700, color: "rgba(255,255,255,0.4)", textTransform: "uppercase", letterSpacing: 2, marginTop: 4 }}>Kcal Target</div>
                  </div>
                </div>

                <div style={{ display: "flex", flexDirection: "column", gap: 16, marginTop: 40 }}>
                  {result.macros.map(m => (
                    <div key={m.name} style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                      <div style={{ display: "flex", alignItems: "center", gap: 12, fontSize: 16, fontWeight: 800, color: "#fff", textTransform: "uppercase", letterSpacing: 1 }}>
                        <div style={{ width: 14, height: 14, borderRadius: 7, background: m.color }} />
                        {m.name}
                      </div>
                      <div style={{ fontSize: 20, fontWeight: 900 }}>{m.value}%</div>
                    </div>
                  ))}
                </div>
              </div>

            </div>
          </div>
        ) : (
          <div className="card" style={{ display: "flex", alignItems: "center", justifyContent: "center", flexDirection: "column", gap: 24, padding: 60, minHeight: 400, color: "rgba(255,255,255,0.3)" }}>
            <span style={{ fontSize: 72 }}>🥗</span>
            <div style={{ fontSize: 22, fontWeight: 600, letterSpacing: 1, textTransform: "uppercase" }}>
              Fill out your profile to generate your diet protocol
            </div>
          </div>
        )}

      </div>

      {toast && (
        <div style={{
          position: "fixed", bottom: 32, right: 120, background: "#e8ff47", color: "#000",
          padding: "16px 24px", borderRadius: 8, fontWeight: 700, fontSize: 15,
          display: "flex", alignItems: "center", gap: 12,
          animation: "slideInLeft 0.3s ease", zIndex: 9999,
          boxShadow: "0 12px 32px rgba(232,255,71,0.2)",
          textTransform: "uppercase", letterSpacing: 1,
          maxWidth: 400
        }}>
          <CheckCircle2 size={20} /> {toast}
        </div>
      )}

      <style>{`
        @keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }
        @keyframes slideInLeft { from { opacity: 0; transform: translateX(50px); } to { opacity: 1; transform: translateX(0); } }
      `}</style>
    </div>
  );
}

const styles = {
  formGroup: { display: "flex", flexDirection: "column", gap: 10 },
  label: { fontSize: 15, textTransform: "uppercase", letterSpacing: 1, color: "rgba(255,255,255,0.5)", fontWeight: 700 },
  input: {
    background: "#080808", border: "1px solid rgba(255,255,255,0.1)", color: "#fff",
    padding: "16px 20px", borderRadius: 8, fontSize: 16, fontFamily: "Inter",
    outline: "none", transition: "all 0.2s"
  },
  select: {
    background: "#080808", border: "1px solid rgba(255,255,255,0.1)", color: "#fff",
    padding: "16px 20px", borderRadius: 8, fontSize: 16, fontFamily: "Inter",
    outline: "none", cursor: "pointer", appearance: "none"
  },
  submitBtn: {
    background: "#e8ff47", color: "#000", border: "none", padding: "20px", borderRadius: 8,
    fontSize: 18, fontWeight: 900, textTransform: "uppercase", letterSpacing: 2, cursor: "pointer"
  }
};
