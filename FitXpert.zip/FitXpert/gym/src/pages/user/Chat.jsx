import { useState, useRef, useEffect } from "react";
import { Send, Bot } from "lucide-react";

export default function Chat() {
  const [messages, setMessages] = useState([
    { text: "Welcome back! I am FitBot 🤖, your AI assistant. How can I help you crush your goals today?", isBot: true, time: new Date().toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'}) }
  ]);
  const [input, setInput] = useState("");
  const messagesEndRef = useRef(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSend = (e) => {
    e.preventDefault();
    if (!input.trim()) return;

    const userMsg = { text: input, isBot: false, time: new Date().toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'}) };
    setMessages(prev => [...prev, userMsg]);
    setInput("");

    // Simulate typing
    setTimeout(() => {
      setMessages(prev => [...prev, { text: "...", isBot: true, isTyping: true, time: "" }]);
      
      setTimeout(() => {
        let reply = "I'm not sure about that. Try asking me about workouts, diets, or trainers!";
        const lower = userMsg.text.toLowerCase();
        
        if (lower.includes("workout") || lower.includes("plan")) reply = "You can view your personalized workout plan in the 'My Workout' tab. Consistency is key! 💪";
        if (lower.includes("diet") || lower.includes("calories") || lower.includes("protein")) reply = "Nutrition is 80% of the battle! Check your macros in the 'My Diet' tab. Try to hit 1.6g of protein per kg of bodyweight.";
        if (lower.includes("hello") || lower.includes("hi") || lower.includes("hey")) reply = "Hello! Ready to forge some limits today?";
        if (lower.includes("trainer") || lower.includes("book")) reply = "You can book a 1:1 session with our elite coaches in the 'Book Trainer' section. They get booked fast!";
        
        setMessages(prev => {
          const filtered = prev.filter(m => !m.isTyping);
          return [...filtered, { text: reply, isBot: true, time: new Date().toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'}) }];
        });
      }, 1000);
    }, 400);
  };

  return (
    <div style={{ animation: "fadeIn 0.5s ease", height: "calc(100vh - 120px)", display: "flex", flexDirection: "column" }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 20 }}>
        <h1 style={{ fontSize: 48, textTransform: "uppercase", fontWeight: 900, margin: 0, letterSpacing: -1 }}>
          AI <span className="gradient-text">Assistant</span>
        </h1>
        <button onClick={() => setMessages([messages[0]])} style={{ background: "transparent", color: "rgba(255,255,255,0.4)", border: "1px solid rgba(255,255,255,0.1)", padding: "10px 16px", borderRadius: 8, fontSize: 12, fontWeight: 700, textTransform: "uppercase", letterSpacing: 1, cursor: "pointer", transition: "all 0.2s" }} className="hover-white">Clear Chat</button>
      </div>

      <div className="card" style={{ flex: 1, display: "flex", flexDirection: "column", overflow: "hidden", borderRadius: 16 }}>
        <div style={{ padding: "20px 32px", borderBottom: "1px solid rgba(255,255,255,0.05)", display: "flex", alignItems: "center", gap: 16, background: "rgba(232,255,71,0.02)" }}>
           <div style={{ width: 48, height: 48, borderRadius: 24, background: "rgba(232,255,71,0.1)", color: "#e8ff47", display: "flex", alignItems: "center", justifyContent: "center" }}><Bot size={28} /></div>
           <div>
             <div style={{ fontSize: 18, fontWeight: 800, color: "#e8ff47", textTransform: "uppercase", letterSpacing: 1 }}>FitBot 🤖</div>
             <div style={{ fontSize: 12, color: "rgba(255,255,255,0.4)", display: "flex", alignItems: "center", gap: 6 }}><div style={{ width: 6, height: 6, borderRadius: 3, background: "#4caf50" }}/> Online & Ready</div>
           </div>
        </div>

        <div style={{ flex: 1, overflowY: "auto", padding: 32, display: "flex", flexDirection: "column", gap: 24 }}>
          {messages.map((msg, idx) => (
            <div key={idx} style={{ display: "flex", flexDirection: "column", alignItems: msg.isBot ? "flex-start" : "flex-end" }}>
              <div style={{ 
                maxWidth: "70%", 
                background: msg.isBot ? "rgba(255,255,255,0.05)" : "#e8ff47", 
                color: msg.isBot ? "#fff" : "#000",
                padding: "16px 20px", 
                borderRadius: 16,
                borderBottomLeftRadius: msg.isBot ? 0 : 16,
                borderBottomRightRadius: !msg.isBot ? 0 : 16,
                fontSize: 16,
                lineHeight: 1.5,
                fontWeight: msg.isBot ? 500 : 600,
                boxShadow: msg.isBot ? "none" : "0 8px 24px rgba(232,255,71,0.15)"
              }}>
                {msg.isTyping ? (
                  <div style={{ display: "flex", gap: 4, padding: "4px 8px" }}>
                    <div className="typing-dot" style={{ animationDelay: "0s" }} />
                    <div className="typing-dot" style={{ animationDelay: "0.2s" }} />
                    <div className="typing-dot" style={{ animationDelay: "0.4s" }} />
                  </div>
                ) : msg.text}
              </div>
              {!msg.isTyping && <div style={{ fontSize: 11, color: "rgba(255,255,255,0.3)", marginTop: 8, fontWeight: 700, letterSpacing: 1 }}>{msg.time}</div>}
            </div>
          ))}
          <div ref={messagesEndRef} />
        </div>

        <div style={{ padding: 24, borderTop: "1px solid rgba(255,255,255,0.05)", background: "#0a0a0a" }}>
          {messages.length === 1 && (
            <div style={{ display: "flex", gap: 12, marginBottom: 16, overflowX: "auto", paddingBottom: 8 }}>
              {["What's my workout today?", "Create a diet plan", "How to book a trainer?", "I have knee pain"].map(q => (
                <button key={q} onClick={() => setInput(q)} style={{ background: "rgba(232,255,71,0.05)", border: "1px solid rgba(232,255,71,0.2)", color: "#e8ff47", padding: "8px 16px", borderRadius: 100, fontSize: 13, fontWeight: 600, cursor: "pointer", whiteSpace: "nowrap", transition: "all 0.2s" }} className="hover-yellow-fill">{q}</button>
              ))}
            </div>
          )}
          <form onSubmit={handleSend} style={{ display: "flex", gap: 16 }}>
            <input 
              value={input}
              onChange={e => setInput(e.target.value)}
              placeholder="Ask FitBot anything..."
              style={{ flex: 1, background: "#111", border: "1px solid rgba(255,255,255,0.1)", color: "#fff", padding: "20px 24px", borderRadius: 12, fontSize: 16, outline: "none", transition: "border-color 0.2s" }}
              className="focus-yellow-border"
            />
            <button type="submit" disabled={!input.trim()} style={{ background: input.trim() ? "#e8ff47" : "rgba(255,255,255,0.1)", color: input.trim() ? "#000" : "rgba(255,255,255,0.3)", border: "none", padding: "0 32px", borderRadius: 12, cursor: input.trim() ? "pointer" : "not-allowed", transition: "all 0.2s", display: "flex", alignItems: "center", justifyContent: "center" }}>
              <Send size={24} />
            </button>
          </form>
        </div>
      </div>
      <style>{`
        .typing-dot { width: 8px; height: 8px; background: rgba(255,255,255,0.5); border-radius: 4px; animation: bounce 1.4s infinite ease-in-out both; }
        @keyframes bounce { 0%, 80%, 100% { transform: scale(0); } 40% { transform: scale(1); } }
        .hover-white:hover { background: rgba(255,255,255,0.1) !important; color: #fff !important; }
        .hover-yellow-fill:hover { background: #e8ff47 !important; color: #000 !important; }
        .focus-yellow-border:focus { border-color: rgba(232,255,71,0.5) !important; }
      `}</style>
    </div>
  );
}
