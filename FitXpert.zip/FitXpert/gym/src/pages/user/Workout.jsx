import { useState } from "react";
import { Link } from "react-router-dom";
import { Dumbbell, Target, Clock, Zap, CheckCircle2, Download, ShoppingCart } from "lucide-react";

const WORKOUT_MOCK = {
  3: ["Full Body A", "Rest", "Full Body B", "Rest", "Full Body C", "Rest", "Rest"],
  4: ["Upper Body", "Lower Body", "Rest", "Upper Body", "Lower Body", "Rest", "Rest"],
  5: ["Push", "Pull", "Legs", "Push", "Pull", "Rest", "Rest"],
  6: ["Push", "Pull", "Legs", "Push", "Pull", "Legs", "Rest"]
};

const EXERCISES = {
  "Push": [
    { name: "Barbell Bench Press", sets: "4x8-10", rest: "90s", muscle: "Chest", emoji: "🏋️" },
    { name: "Overhead Press", sets: "3x10", rest: "90s", muscle: "Shoulders", emoji: "💪" },
    { name: "Tricep Pushdowns", sets: "3x12", rest: "60s", muscle: "Triceps", emoji: "🔥" }
  ],
  "Pull": [
    { name: "Lat Pulldown", sets: "4x10", rest: "90s", muscle: "Back", emoji: "🔙" },
    { name: "Barbell Row", sets: "3x8", rest: "90s", muscle: "Back", emoji: "🚣" },
    { name: "Bicep Curls", sets: "3x15", rest: "60s", muscle: "Biceps", emoji: "💪" }
  ],
  "Legs": [
    { name: "Barbell Squats", sets: "4x8", rest: "120s", muscle: "Quads/Glutes", emoji: "🦵" },
    { name: "Romanian Deadlifts", sets: "3x10", rest: "90s", muscle: "Hamstrings", emoji: "🔥" },
    { name: "Leg Press", sets: "3x12", rest: "90s", muscle: "Legs", emoji: "🏗️" }
  ],
  "Upper Body": [
    { name: "Bench Press", sets: "4x8", rest: "90s", muscle: "Chest", emoji: "🏋️" },
    { name: "Pull-ups", sets: "3xMax", rest: "90s", muscle: "Back", emoji: "🧗" },
    { name: "Lateral Raises", sets: "3x15", rest: "60s", muscle: "Shoulders", emoji: "🦅" }
  ],
  "Lower Body": [
    { name: "Deadlifts", sets: "4x6", rest: "120s", muscle: "Hamstrings", emoji: "🔥" },
    { name: "Leg Extensions", sets: "3x15", rest: "60s", muscle: "Quads", emoji: "🦵" },
    { name: "Calf Raises", sets: "4x20", rest: "45s", muscle: "Calves", emoji: "💥" }
  ],
  "Full Body A": [
    { name: "Squats", sets: "3x8", rest: "120s", muscle: "Legs", emoji: "🦵" },
    { name: "Bench Press", sets: "3x8", rest: "90s", muscle: "Chest", emoji: "🏋️" },
    { name: "Barbell Row", sets: "3x8", rest: "90s", muscle: "Back", emoji: "🚣" }
  ],
  "Full Body B": [
    { name: "Deadlifts", sets: "3x5", rest: "120s", muscle: "Total Body", emoji: "🔥" },
    { name: "Overhead Press", sets: "3x8", rest: "90s", muscle: "Shoulders", emoji: "💪" },
    { name: "Lat Pulldown", sets: "3x10", rest: "90s", muscle: "Back", emoji: "🔙" }
  ],
  "Full Body C": [
    { name: "Leg Press", sets: "3x10", rest: "90s", muscle: "Legs", emoji: "🏗️" },
    { name: "Incline DB Press", sets: "3x10", rest: "90s", muscle: "Chest", emoji: "🏋️" },
    { name: "Cable Rows", sets: "3x12", rest: "60s", muscle: "Back", emoji: "🚣" }
  ]
};

const getDayColor = (type) => {
  if (type === "Rest") return "#222";
  if (type.includes("Push") || type.includes("Upper")) return "#e8ff47";
  if (type.includes("Pull")) return "#ff9800";
  if (type.includes("Legs") || type.includes("Lower")) return "#4caf50";
  return "#00bcd4";
};

export default function WorkoutGenerator() {
  const [formData, setFormData] = useState({
    goal: "Build Muscle",
    level: "Intermediate",
    days: "4",
    equipment: "Full Gym",
    focus: "Full Body"
  });
  
  const [plan, setPlan] = useState(null);
  const [isGenerating, setIsGenerating] = useState(false);
  const [toast, setToast] = useState('');
  const [completedWorkouts, setCompletedWorkouts] = useState([]);

  const handleGenerate = (e) => {
    e.preventDefault();
    setIsGenerating(true);
    setTimeout(() => {
      const daysStr = parseInt(formData.days);
      const schedule = WORKOUT_MOCK[daysStr] || WORKOUT_MOCK[4];
      
      const detailedPlan = schedule.map((dayType, idx) => {
        const daysOfWeek = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"];
        return {
          id: `day-${idx}`,
          dayName: daysOfWeek[idx],
          type: dayType,
          exercises: dayType === "Rest" ? [] : EXERCISES[dayType] || EXERCISES["Full Body A"]
        };
      });
      
      setPlan(detailedPlan);
      setIsGenerating(false);
    }, 1500);
  };

  const completeWorkout = (dayId) => {
    if (completedWorkouts.includes(dayId)) return;
    
    setCompletedWorkouts(prev => [...prev, dayId]);
    
    // Gamification Logic
    const currentXp = parseInt(localStorage.getItem('fitxpert_xp') || "2400", 10);
    localStorage.setItem('fitxpert_xp', currentXp + 50);
    
    const badges = JSON.parse(localStorage.getItem('fitxpert_badges') || "[]");
    if (!badges.includes(1)) {
      badges.push(1); // First Flame badge
      localStorage.setItem('fitxpert_badges', JSON.stringify(badges));
      setToast('Workout Complete! +50 XP and "First Flame" Badge Unlocked!');
    } else {
      setToast('Workout Complete! +50 XP');
    }
    
    setTimeout(() => setToast(''), 3000);
  };

  const downloadPlan = () => {
    setToast('Protocol Saved to Device!');
    setTimeout(() => setToast(''), 3000);
  };

  return (
    <div>
      <h1 style={{ fontSize: 56, textTransform: "uppercase", fontWeight: 900, marginBottom: 40, letterSpacing: -1 }}>
        <span className="gradient-text">Forge Your</span> Program
      </h1>

      {!plan ? (
        <div className="card" style={{ padding: 48, maxWidth: 800, margin: "0 auto", animation: "fadeIn 0.5s ease" }}>
          <form onSubmit={handleGenerate} style={{ display: "flex", flexDirection: "column", gap: 32 }}>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 24 }}>
              <div style={styles.formGroup}>
                <label style={styles.label}><Target size={16} /> Goal</label>
                <select style={styles.select} value={formData.goal} onChange={e => setFormData({...formData, goal: e.target.value})}>
                  <option>Lose Weight</option>
                  <option>Build Muscle</option>
                  <option>Improve Stamina</option>
                  <option>Stay Active</option>
                </select>
              </div>
              <div style={styles.formGroup}>
                <label style={styles.label}><Zap size={16} /> Fitness Level</label>
                <select style={styles.select} value={formData.level} onChange={e => setFormData({...formData, level: e.target.value})}>
                  <option>Beginner</option>
                  <option>Intermediate</option>
                  <option>Advanced</option>
                </select>
              </div>
              <div style={styles.formGroup}>
                <label style={styles.label}><Clock size={16} /> Days Per Week</label>
                <select style={styles.select} value={formData.days} onChange={e => setFormData({...formData, days: e.target.value})}>
                  <option>3</option>
                  <option>4</option>
                  <option>5</option>
                  <option>6</option>
                </select>
              </div>
              <div style={styles.formGroup}>
                <label style={styles.label}><Dumbbell size={16} /> Equipment</label>
                <select style={styles.select} value={formData.equipment} onChange={e => setFormData({...formData, equipment: e.target.value})}>
                  <option>Full Gym</option>
                  <option>Dumbbells Only</option>
                  <option>No Equipment</option>
                </select>
              </div>
            </div>
            
            <button 
              type="submit" 
              className="btn-glow" 
              style={styles.submitBtn}
              disabled={isGenerating}
            >
              {isGenerating ? "Generating AI Protocol..." : "Generate Custom Plan"}
            </button>
          </form>
        </div>
      ) : (
        <div style={{ animation: "slideUp 0.5s ease" }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 32 }}>
            <div>
              <h2 style={{ fontSize: 32, fontWeight: 800, margin: 0, textTransform: "uppercase" }}>Your 7-Day Protocol</h2>
              <p style={{ color: "rgba(255,255,255,0.5)", margin: "8px 0 0", fontSize: 16 }}>
                Goal: <span style={{color: "#fff"}}>{formData.goal}</span> • Level: <span style={{color: "#fff"}}>{formData.level}</span>
              </p>
            </div>
            <div style={{ display: "flex", gap: 16 }}>
              <button onClick={downloadPlan} className="btn-glow" style={styles.downloadBtn}>
                <Download size={18} /> Download Plan
              </button>
              <Link to="/user/payments?payTo=FitXpert&amount=999&item=Custom+AI+Workout+Plan" className="btn-glow" style={{...styles.downloadBtn, background: "#e8ff47", color: "#000", textDecoration: "none"}}>
                <ShoppingCart size={18} /> Buy Full Access (₹999)
              </Link>
            </div>
          </div>

          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(320px, 1fr))", gap: 24 }}>
            {plan.map((day, idx) => (
              <div key={idx} className="card" style={{ overflow: "hidden", display: "flex", flexDirection: "column" }}>
                <div style={{ 
                  padding: "20px 24px", 
                  background: day.type === "Rest" ? "#151515" : "rgba(232, 255, 71, 0.05)",
                  borderBottom: "2px solid " + getDayColor(day.type)
                }}>
                  <div style={{ fontSize: 13, textTransform: "uppercase", letterSpacing: 2, color: "rgba(255,255,255,0.5)", fontWeight: 700 }}>
                    Day {idx + 1} — {day.dayName}
                  </div>
                  <div style={{ fontSize: 26, fontWeight: 800, color: day.type === "Rest" ? "#666" : "#fff", marginTop: 4, textTransform: "uppercase", letterSpacing: 1 }}>
                    {day.type}
                  </div>
                </div>
                
                <div style={{ padding: 24, flex: 1, background: day.type === "Rest" ? "#0a0a0a" : "#111" }}>
                  {day.type === "Rest" ? (
                    <div style={{ display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", height: "100%", minHeight: 180, color: "rgba(255,255,255,0.3)", gap: 16 }}>
                      <span style={{ fontSize: 48, filter: "grayscale(1)", opacity: 0.5 }}>🧘</span>
                      <span style={{ fontWeight: 700, letterSpacing: 2, fontSize: 16 }}>ACTIVE RECOVERY</span>
                    </div>
                  ) : (
                    <div style={{ display: "flex", flexDirection: "column", gap: 20 }}>
                      {day.exercises.map((ex, i) => (
                        <div key={i} style={{ display: "flex", gap: 16, alignItems: "center" }}>
                          <div style={{ fontSize: 28, background: "rgba(255,255,255,0.05)", width: 48, height: 48, borderRadius: 8, display: "flex", alignItems: "center", justifyContent: "center" }}>
                            {ex.emoji}
                          </div>
                          <div style={{ flex: 1 }}>
                            <div style={{ fontWeight: 700, fontSize: 17, color: "#fff", letterSpacing: 0.5 }}>{ex.name}</div>
                            <div style={{ fontSize: 14, color: "rgba(255,255,255,0.4)", marginTop: 2, textTransform: "uppercase", letterSpacing: 1 }}>{ex.muscle}</div>
                          </div>
                          <div style={{ textAlign: "right" }}>
                            <div style={{ fontWeight: 900, color: "#e8ff47", fontSize: 18 }}>{ex.sets}</div>
                            <div style={{ fontSize: 13, color: "rgba(255,255,255,0.4)" }}>{ex.rest} rest</div>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
                
                {day.type !== "Rest" && (
                  <div style={{ padding: "16px 24px", background: "rgba(0,0,0,0.5)", fontSize: 13, color: "rgba(255,255,255,0.4)", display: "flex", justifyContent: "space-between", alignItems: "center", fontWeight: 600, textTransform: "uppercase", letterSpacing: 1 }}>
                    <span>~350 kcal burn</span>
                    <button 
                      onClick={() => completeWorkout(day.id)}
                      disabled={completedWorkouts.includes(day.id)}
                      style={{
                        background: completedWorkouts.includes(day.id) ? "#4caf50" : "#e8ff47",
                        color: completedWorkouts.includes(day.id) ? "#fff" : "#000",
                        border: "none", padding: "8px 16px", borderRadius: 4, fontWeight: 800, cursor: completedWorkouts.includes(day.id) ? "default" : "pointer",
                        display: "flex", alignItems: "center", gap: 6, textTransform: "uppercase", fontSize: 12
                      }}
                    >
                      {completedWorkouts.includes(day.id) ? <><CheckCircle2 size={14} /> Completed</> : "Complete Workout"}
                    </button>
                  </div>
                )}
              </div>
            ))}
          </div>

          <button onClick={() => setPlan(null)} style={{ marginTop: 40, background: "none", border: "1px solid rgba(255,255,255,0.2)", color: "#fff", padding: "16px 32px", fontSize: 16, borderRadius: 8, cursor: "pointer", textTransform: "uppercase", fontWeight: 700, letterSpacing: 1 }} className="btn-outline">
            ← Change Parameters
          </button>
        </div>
      )}

      {toast && (
        <div style={{
          position: "fixed", bottom: 32, right: 120, background: "#e8ff47", color: "#000",
          padding: "16px 24px", borderRadius: 8, fontWeight: 700, fontSize: 15,
          display: "flex", alignItems: "center", gap: 12,
          animation: "slideInLeft 0.3s ease", zIndex: 9999,
          boxShadow: "0 8px 32px rgba(232,255,71,0.3)",
          textTransform: "uppercase", letterSpacing: 1,
          maxWidth: 400
        }}>
          <CheckCircle2 size={20} /> {toast}
        </div>
      )}

      <style>{`
        @keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }
        @keyframes slideUp { from { opacity: 0; transform: translateY(20px); } to { opacity: 1; transform: translateY(0); } }
        @keyframes slideInLeft { from { opacity: 0; transform: translateX(50px); } to { opacity: 1; transform: translateX(0); } }
        .btn-outline:hover { background: rgba(255,255,255,0.1); border-color: rgba(255,255,255,0.5); }
      `}</style>
    </div>
  );
}

const styles = {
  formGroup: { display: "flex", flexDirection: "column", gap: 12 },
  label: { fontSize: 15, textTransform: "uppercase", letterSpacing: 1, color: "rgba(255,255,255,0.5)", fontWeight: 700, display: "flex", gap: 8, alignItems: "center" },
  select: {
    background: "#080808", border: "1px solid rgba(255,255,255,0.1)", color: "#fff",
    padding: "16px 20px", borderRadius: 8, fontSize: 16, fontFamily: "Inter",
    outline: "none", cursor: "pointer", appearance: "none", transition: "all 0.2s"
  },
  submitBtn: {
    background: "#e8ff47", color: "#000", border: "none", padding: "24px", borderRadius: 8,
    fontSize: 20, fontWeight: 900, textTransform: "uppercase", letterSpacing: 2, cursor: "pointer",
    marginTop: 24
  },
  downloadBtn: {
    background: "transparent", color: "#e8ff47", border: "2px solid #e8ff47", padding: "14px 28px",
    borderRadius: 8, fontWeight: 800, textTransform: "uppercase", letterSpacing: 1,
    display: "flex", alignItems: "center", gap: 10, cursor: "pointer", fontSize: 15
  }
};
