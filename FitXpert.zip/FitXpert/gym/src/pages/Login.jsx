import { useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import { Lock, User, ShieldAlert } from "lucide-react";

export default function Login() {
  const navigate = useNavigate();
  const [role, setRole] = useState("user"); // 'user' or 'admin'
  const [formData, setFormData] = useState({ identifier: "", password: "" });
  const [error, setError] = useState("");

  const handleLogin = (e) => {
    e.preventDefault();
    setError("");
    
    if (!formData.identifier || !formData.password) {
      setError("Please fill in all fields.");
      return;
    }

    if (role === "admin") {
      if (formData.identifier === "admin" && formData.password === "admin") {
        localStorage.setItem("fitxpert_auth", "admin");
        navigate("/dashboard");
      } else {
        setError("Invalid Admin credentials.");
      }
    } else {
      // Mock user login
      if (formData.password.length < 6) {
        setError("Password must be at least 6 characters.");
      } else {
        localStorage.setItem("fitxpert_auth", "user");
        navigate("/dashboard");
      }
    }
  };

  return (
    <div style={{ minHeight: "100vh", background: "#0a0a0a", display: "flex", alignItems: "center", justifyContent: "center", padding: 24, position: "relative", overflow: "hidden" }}>
      {/* Background flare */}
      <div style={{ position: "absolute", width: "40vw", height: "40vw", background: "radial-gradient(circle, rgba(232,255,71,0.08) 0%, transparent 70%)", top: "-10%", right: "-10%", zIndex: 0 }} />
      
      <div className="card" style={{ width: "100%", maxWidth: 440, padding: 48, position: "relative", zIndex: 1, animation: "fadeIn 0.5s ease" }}>
        
        <div style={{ textAlign: "center", marginBottom: 40 }}>
          <div style={{ fontSize: 40, color: "#e8ff47", lineHeight: 1, marginBottom: 16 }}>⬡</div>
          <h1 style={{ fontSize: 36, textTransform: "uppercase", fontWeight: 900, margin: 0, letterSpacing: 1, color: "#fff" }}>
             Welcome Back
          </h1>
          <p style={{ color: "rgba(255,255,255,0.5)", marginTop: 12, fontSize: 16, fontFamily: "Inter" }}>Enter your credentials to access the facility.</p>
        </div>

        <div style={{ display: "flex", gap: 8, marginBottom: 32, background: "rgba(255,255,255,0.05)", padding: 6, borderRadius: 8 }}>
          <button 
            type="button"
            onClick={() => { setRole("user"); setError(""); setFormData({identifier: "", password: ""}); }}
            style={{ flex: 1, background: role === "user" ? "#1a1a1a" : "transparent", color: role === "user" ? "#fff" : "rgba(255,255,255,0.5)", border: "1px solid", borderColor: role === "user" ? "rgba(255,255,255,0.1)" : "transparent", padding: "12px", borderRadius: 6, fontSize: 14, fontWeight: 800, textTransform: "uppercase", letterSpacing: 1, cursor: "pointer", transition: "all 0.2s" }}
          >
            Member
          </button>
          <button 
            type="button"
            onClick={() => { setRole("admin"); setError(""); setFormData({identifier: "", password: ""}); }}
            style={{ flex: 1, background: role === "admin" ? "#1a1a1a" : "transparent", color: role === "admin" ? "#e8ff47" : "rgba(255,255,255,0.5)", border: "1px solid", borderColor: role === "admin" ? "rgba(232,255,71,0.3)" : "transparent", padding: "12px", borderRadius: 6, fontSize: 14, fontWeight: 800, textTransform: "uppercase", letterSpacing: 1, cursor: "pointer", transition: "all 0.2s" }}
          >
            Admin
          </button>
        </div>

        {error && (
          <div style={{ background: "rgba(255,71,71,0.1)", border: "1px solid rgba(255,71,71,0.3)", padding: "12px 16px", borderRadius: 8, color: "#ff4747", fontSize: 14, fontWeight: 700, marginBottom: 24, display: "flex", alignItems: "center", gap: 10 }}>
            <ShieldAlert size={18} /> {error}
          </div>
        )}

        <form onSubmit={handleLogin} style={{ display: "flex", flexDirection: "column", gap: 20 }}>
          <div style={styles.formGroup}>
            <label style={styles.label}>{role === "admin" ? "Admin Username" : "Email Address"}</label>
            <div style={{ position: "relative" }}>
              <User size={20} color={role === "admin" ? "#e8ff47" : "rgba(255,255,255,0.3)"} style={{ position: "absolute", left: 16, top: "50%", transform: "translateY(-50%)" }} />
              <input 
                type={role === "admin" ? "text" : "email"}
                value={formData.identifier}
                onChange={e => setFormData({...formData, identifier: e.target.value})}
                placeholder={role === "admin" ? "Enter admin" : "you@example.com"} 
                style={{...styles.input, paddingLeft: 48, borderColor: role === "admin" ? "rgba(232,255,71,0.2)" : "rgba(255,255,255,0.15)"}} 
              />
            </div>
          </div>
          <div style={styles.formGroup}>
            <label style={styles.label}>Password</label>
            <div style={{ position: "relative" }}>
               <Lock size={20} color={role === "admin" ? "#e8ff47" : "rgba(255,255,255,0.3)"} style={{ position: "absolute", left: 16, top: "50%", transform: "translateY(-50%)" }} />
              <input 
                type="password" 
                value={formData.password}
                onChange={e => setFormData({...formData, password: e.target.value})}
                placeholder={role === "admin" ? "admin" : "••••••••"} 
                style={{...styles.input, paddingLeft: 48, borderColor: role === "admin" ? "rgba(232,255,71,0.2)" : "rgba(255,255,255,0.15)"}} 
              />
            </div>
          </div>
          
          <button type="submit" className="btn-glow" style={{ ...styles.submitBtn, marginTop: 16, background: role === "admin" ? "#e8ff47" : "#fff" }}>
             {role === "admin" ? "Access Control Panel" : "Login to FitXpert"}
          </button>
        </form>

        {role === "user" && (
          <div style={{ textAlign: "center", marginTop: 32, fontSize: 15, color: "rgba(255,255,255,0.5)", fontFamily: "Inter" }}>
            Don't have an account? <Link to="/register" style={{ color: "#e8ff47", fontWeight: 700, textDecoration: "none" }}>Join Now</Link>
          </div>
        )}
      </div>

      <Link to="/" style={{ position: "absolute", top: 40, left: 40, color: "rgba(255,255,255,0.5)", textDecoration: "none", fontWeight: 700, fontSize: 14, textTransform: "uppercase", letterSpacing: 2 }}>
        ← Back to Site
      </Link>

      <style>{`@keyframes fadeIn { from { opacity: 0; transform: translateY(20px); } to { opacity: 1; transform: translateY(0); } }`}</style>
    </div>
  );
}

const styles = {
  formGroup: { display: "flex", flexDirection: "column", gap: 10 },
  label: { fontSize: 13, textTransform: "uppercase", letterSpacing: 1, color: "rgba(255,255,255,0.6)", fontWeight: 800 },
  input: { width: "100%", background: "#050505", border: "1px solid rgba(255,255,255,0.15)", color: "#fff", padding: "16px 20px", borderRadius: 8, fontSize: 16, fontFamily: "Inter", outline: "none", transition: "border-color 0.2s", boxSizing: "border-box" },
  submitBtn: { color: "#000", border: "none", padding: "20px", borderRadius: 8, fontSize: 16, fontWeight: 900, textTransform: "uppercase", letterSpacing: 2, cursor: "pointer", width: "100%" }
};
