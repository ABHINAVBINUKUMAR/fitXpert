import { Link } from "react-router-dom";

const PLANS = [
  { name: "Starter", price: "₹1,499", per: "/mo", features: ["Gym Access", "2 Group Classes", "App Access"], highlight: false, amount: 1499 },
  { name: "Elite", price: "₹2,999", per: "/mo", features: ["Unlimited Access", "All Classes", "Nutrition Guide"], highlight: true, amount: 2999 },
  { name: "Pro", price: "₹4,999", per: "/mo", features: ["Everything in Elite", "Custom Meal Plan", "VIP Lounge"], highlight: false, amount: 4999 },
];

export default function Pricing() {
  return (
    <div style={styles.root}>
      {/* Spacer for navbar */}
      <div style={{ height: 100 }} />
      <div style={{ maxWidth: 1200, margin: "0 auto", padding: "40px 24px" }}>
        <div style={styles.sectionLabel}>— MEMBERSHIP PLANS</div>
        <h2 style={styles.sectionH2}>Invest in <span className="gradient-text">Yourself</span></h2>
        
        <div style={styles.pricingGrid}>
          {PLANS.map((p, i) => (
            <div key={i} style={{ ...styles.planCard, ...(p.highlight ? styles.planCardHL : {}) }} className="plan-card">
              {p.highlight && <div style={styles.planBadge}>BEST VALUE</div>}
              <div style={styles.planName}>{p.name}</div>
              <div style={styles.planPrice}>
                {p.price}<span style={styles.planPer}>{p.per}</span>
              </div>
              <div style={styles.planDivider} />
              <ul style={styles.planFeatures}>
                {p.features.map((f, j) => (
                  <li key={j} style={styles.planFeature}><span style={{ color: "#e8ff47", marginRight: 8 }}>✓</span>{f}</li>
                ))}
              </ul>
              <Link to={`/user/payments?payTo=FitXpert&amount=${p.amount}&item=${p.name}+Membership`} style={{...styles.btn, background: p.highlight ? "#e8ff47" : "transparent", color: p.highlight ? "#000" : "#fff", border: p.highlight ? "none" : "1.5px solid rgba(255,255,255,0.4)" }} className={p.highlight ? "btn-glow" : ""}>
                Buy Membership
              </Link>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

const styles = {
  root: { minHeight: "100vh", background: "#0a0a0a", color: "#f0f0f0" },
  sectionLabel: { fontSize: 12, letterSpacing: 4, color: "#e8ff47", textTransform: "uppercase", fontWeight: 700, marginBottom: 16, textAlign: "center" },
  sectionH2: { fontSize: "clamp(36px, 6vw, 72px)", fontWeight: 900, textTransform: "uppercase", lineHeight: 1, letterSpacing: -1, marginBottom: 60, textAlign: "center" },
  pricingGrid: { display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(300px, 1fr))", gap: 24, alignItems: "center" },
  planCard: { background: "#0d0d0d", border: "1px solid rgba(255,255,255,0.1)", borderRadius: 16, padding: "48px 32px", position: "relative" },
  planCardHL: { background: "linear-gradient(145deg, #1a1c0d, #0d0e05)", border: "1px solid #e8ff47", transform: "scale(1.05)", zIndex: 1, boxShadow: "0 24px 48px rgba(232,255,71,0.05)" },
  planBadge: { position: "absolute", top: -14, left: "50%", transform: "translateX(-50%)", background: "#e8ff47", color: "#000", padding: "4px 16px", borderRadius: 100, fontSize: 10, fontWeight: 900, letterSpacing: 2 },
  planName: { fontSize: 20, fontWeight: 800, textTransform: "uppercase", letterSpacing: 1, color: "rgba(255,255,255,0.7)", marginBottom: 16 },
  planPrice: { fontSize: 48, fontWeight: 900, color: "#fff", marginBottom: 32 },
  planPer: { fontSize: 16, color: "rgba(255,255,255,0.4)", fontWeight: 500 },
  planDivider: { height: 1, background: "rgba(255,255,255,0.1)", marginBottom: 32 },
  planFeatures: { listStyle: "none", padding: 0, margin: "0 0 40px", display: "flex", flexDirection: "column", gap: 16 },
  planFeature: { color: "rgba(255,255,255,0.8)", fontSize: 15, fontWeight: 500 },
  btn: { display: "block", textAlign: "center", textDecoration: "none", padding: "16px", borderRadius: 8, fontSize: 14, fontWeight: 800, textTransform: "uppercase", letterSpacing: 1, cursor: "pointer", transition: "all 0.2s" }
};
