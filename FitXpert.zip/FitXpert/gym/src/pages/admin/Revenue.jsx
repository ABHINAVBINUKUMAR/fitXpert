import { Download, IndianRupee, TrendingUp } from "lucide-react";

const TXNS = [
  { id: "TXN-001", user: "Aria Chen", amount: "₹4,999", plan: "PRO", date: "Today" },
  { id: "TXN-002", user: "John Smith", amount: "₹2,999", plan: "ELITE", date: "Yesterday" },
  { id: "TXN-003", user: "David Kim", amount: "₹4,999", plan: "PRO", date: "Yesterday" },
];

export default function RevenueAdmin() {
  return (
    <div style={{ animation: "fadeIn 0.5s ease" }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 40 }}>
         <div>
          <h1 style={{ fontSize: 48, textTransform: "uppercase", fontWeight: 900, margin: 0, letterSpacing: -1 }}>
            Financial <span style={{ color: "#ff4444" }}>Dashboard</span>
          </h1>
          <p style={{ color: "rgba(255,255,255,0.5)", fontSize: 16, marginTop: 8 }}>Track revenue streams and transactions.</p>
        </div>
        <button style={{ background: "transparent", color: "#ff4444", border: "1px solid #ff4444", padding: "12px 24px", borderRadius: 8, fontSize: 14, fontWeight: 900, textTransform: "uppercase", letterSpacing: 1, display: "flex", alignItems: "center", gap: 8, cursor: "pointer" }}>
           <Download size={18} /> Export CSV
        </button>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 24, marginBottom: 32 }}>
        <div className="card" style={{ padding: 32, display: "flex", alignItems: "center", gap: 24, background: "linear-gradient(135deg, #110000 0%, #050000 100%)", border: "1px solid rgba(255,68,68,0.2)" }}>
           <div style={{ width: 64, height: 64, borderRadius: 32, background: "rgba(255,68,68,0.1)", color: "#ff4444", display: "flex", alignItems: "center", justifyContent: "center" }}><IndianRupee size={32} /></div>
           <div>
             <div style={{ fontSize: 14, textTransform: "uppercase", letterSpacing: 1, color: "rgba(255,255,255,0.5)", fontWeight: 700, marginBottom: 8 }}>Monthly Recurring Revenue</div>
             <div style={{ fontSize: 48, fontWeight: 900, color: "#fff" }}>₹1,24,500</div>
           </div>
        </div>
        <div className="card" style={{ padding: 32, display: "flex", alignItems: "center", gap: 24 }}>
           <div style={{ width: 64, height: 64, borderRadius: 32, background: "rgba(255,255,255,0.05)", color: "#fff", display: "flex", alignItems: "center", justifyContent: "center" }}><TrendingUp size={32} /></div>
           <div>
             <div style={{ fontSize: 14, textTransform: "uppercase", letterSpacing: 1, color: "rgba(255,255,255,0.5)", fontWeight: 700, marginBottom: 8 }}>Projected Growth</div>
             <div style={{ fontSize: 48, fontWeight: 900, color: "#4caf50" }}>+12.4%</div>
           </div>
        </div>
      </div>

      <h2 style={{ fontSize: 20, fontWeight: 800, textTransform: "uppercase", marginBottom: 16 }}>Recent Transactions</h2>
      <div className="card" style={{ overflow: "hidden" }}>
        <table style={{ width: "100%", borderCollapse: "collapse" }}>
          <thead style={{ background: "rgba(255,255,255,0.02)" }}>
            <tr>
              <th style={{ padding: "16px 24px", textAlign: "left", fontSize: 12, textTransform: "uppercase", color: "rgba(255,255,255,0.4)" }}>Transaction ID</th>
              <th style={{ padding: "16px 24px", textAlign: "left", fontSize: 12, textTransform: "uppercase", color: "rgba(255,255,255,0.4)" }}>Member</th>
              <th style={{ padding: "16px 24px", textAlign: "left", fontSize: 12, textTransform: "uppercase", color: "rgba(255,255,255,0.4)" }}>Plan</th>
              <th style={{ padding: "16px 24px", textAlign: "left", fontSize: 12, textTransform: "uppercase", color: "rgba(255,255,255,0.4)" }}>Amount</th>
              <th style={{ padding: "16px 24px", textAlign: "right", fontSize: 12, textTransform: "uppercase", color: "rgba(255,255,255,0.4)" }}>Date</th>
            </tr>
          </thead>
          <tbody>
            {TXNS.map(t => (
              <tr key={t.id} style={{ borderTop: "1px solid rgba(255,255,255,0.05)" }}>
                <td style={{ padding: "20px 24px", fontSize: 14, color: "rgba(255,255,255,0.6)", fontWeight: 700 }}>{t.id}</td>
                <td style={{ padding: "20px 24px", fontWeight: 700 }}>{t.user}</td>
                <td style={{ padding: "20px 24px" }}><span style={{ fontSize: 11, background: "rgba(255,255,255,0.1)", padding: "2px 8px", borderRadius: 4, textTransform: "uppercase", letterSpacing: 1 }}>{t.plan}</span></td>
                <td style={{ padding: "20px 24px", fontWeight: 900, color: "#ff4444" }}>{t.amount}</td>
                <td style={{ padding: "20px 24px", textAlign: "right", fontSize: 14, color: "rgba(255,255,255,0.6)" }}>{t.date}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
