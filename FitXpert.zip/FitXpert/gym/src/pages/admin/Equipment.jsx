import { useState } from "react";
import { Plus, PenTool, AlertTriangle, CheckCircle2, X } from "lucide-react";

// Mocking 16 items
const INITIAL_EQUIPMENT = [
  { id: 1, name: "Matrix Treadmill T7", category: "Cardio", status: "Available", img: "https://images.unsplash.com/photo-1540497077202-7c8a3999166f?w=400&q=80" },
  { id: 2, name: "Rogue Squat Rack", category: "Strength", status: "In Use", img: "https://images.unsplash.com/photo-1534438327276-14e5300c3a48?w=400&q=80" },
  { id: 3, name: "Abductor Machine", category: "Machines", status: "Maintenance", img: "https://images.unsplash.com/photo-1574680096145-d05b474e2155?w=400&q=80" },
  { id: 4, name: "Concept2 Rower", category: "Cardio", status: "Available", img: "https://images.unsplash.com/photo-1596357395217-80de13130e52?w=400&q=80" },
  { id: 5, name: "Hammer Strength Bench", category: "Strength", status: "In Use", img: "https://images.unsplash.com/photo-1581009146145-b5ef050c2e1e?w=400&q=80" },
  { id: 6, name: "Kettlebell Set (All)", category: "Free Weights", status: "Available", img: "https://images.unsplash.com/photo-1517963879433-6ad2b056d712?w=400&q=80" },
  { id: 7, name: "StairMaster 8G", category: "Cardio", status: "Maintenance", img: "https://images.unsplash.com/photo-1540497077202-7c8a3999166f?w=400&q=80" }, 
  { id: 8, name: "Dumbbell Rack", category: "Free Weights", status: "In Use", img: "https://images.unsplash.com/photo-1583454110551-21f2fa2afe61?w=400&q=80" },
  { id: 9, name: "Concept2 SkiErg", category: "Cardio", status: "Available", img: "https://images.unsplash.com/photo-1596357395217-80de13130e52?w=400&q=80" },
  { id: 10, name: "Smith Machine", category: "Machines", status: "In Use", img: "https://images.unsplash.com/photo-1534438327276-14e5300c3a48?w=400&q=80" },
  { id: 11, name: "Cable Crossover", category: "Machines", status: "Available", img: "https://images.unsplash.com/photo-1574680096145-d05b474e2155?w=400&q=80" },
  { id: 12, name: "Preacher Curl Bench", category: "Strength", status: "Available", img: "https://images.unsplash.com/photo-1581009146145-b5ef050c2e1e?w=400&q=80" },
  { id: 13, name: "Adjustable Bench 1", category: "Strength", status: "In Use", img: "https://images.unsplash.com/photo-1581009146145-b5ef050c2e1e?w=400&q=80" },
  { id: 14, name: "Adjustable Bench 2", category: "Strength", status: "Available", img: "https://images.unsplash.com/photo-1581009146145-b5ef050c2e1e?w=400&q=80" },
  { id: 15, name: "Assault Bike", category: "Cardio", status: "In Use", img: "https://images.unsplash.com/photo-1596357395217-80de13130e52?w=400&q=80" },
  { id: 16, name: "Leg Press", category: "Machines", status: "Available", img: "https://images.unsplash.com/photo-1574680096145-d05b474e2155?w=400&q=80" }
];

export default function Equipment() {
  const [equipmentList] = useState(INITIAL_EQUIPMENT);
  const [filter, setFilter] = useState("All");
  
  // Modals state
  const [modalType, setModalType] = useState(null); // 'log', 'report', 'add'
  const [activeItem, setActiveItem] = useState(null);
  const [toast, setToast] = useState(null);

  const stats = {
    total: equipmentList.length,
    available: equipmentList.filter(e => e.status === "Available").length,
    inUse: equipmentList.filter(e => e.status === "In Use").length,
    maintenance: equipmentList.filter(e => e.status === "Maintenance").length
  };

  const filtered = filter === "All" ? equipmentList : equipmentList.filter(e => e.status === filter);

  const showToast = (msg) => {
    setModalType(null);
    setToast(msg);
    setTimeout(() => setToast(null), 3000);
  };

  const handleLogUsage = (e) => { e.preventDefault(); showToast("Usage Logged Successfully"); };
  const handleReport = (e) => { e.preventDefault(); showToast("Issue Reported to Maintenance"); };
  const handleAdd = (e) => { e.preventDefault(); showToast("New Equipment Added to Inventory"); };

  return (
    <div>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 40 }}>
        <h1 style={{ fontSize: 56, textTransform: "uppercase", fontWeight: 900, margin: 0, letterSpacing: -1 }}>
          Facility <span className="gradient-text">Inventory</span>
        </h1>
        <button 
          onClick={() => setModalType('add')}
          className="btn-glow" 
          style={{ background: "#e8ff47", color: "#000", border: "none", padding: "16px 28px", borderRadius: 8, fontSize: 15, fontWeight: 900, textTransform: "uppercase", letterSpacing: 1, display: "flex", alignItems: "center", gap: 10, cursor: "pointer" }}
        >
          <Plus size={20} /> Add Equipment
        </button>
      </div>

      {/* STATS */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))", gap: 24, marginBottom: 40 }}>
        <StatBox label="Total Equipment" value={stats.total} />
        <StatBox label="Available Now" value={stats.available} color="#4caf50" />
        <StatBox label="Currently In Use" value={stats.inUse} color="#ff9800" />
        <StatBox label="Maintenance" value={stats.maintenance} color="#ff4747" />
      </div>

      {/* FILTERS */}
      <div style={{ display: "flex", gap: 12, marginBottom: 32, overflowX: "auto", paddingBottom: 8 }}>
        {["All", "Available", "In Use", "Maintenance"].map(f => (
          <button 
            key={f} onClick={() => setFilter(f)}
            style={{ 
              background: filter === f ? "#e8ff47" : "transparent",
              color: filter === f ? "#000" : "#fff",
              border: filter === f ? "1px solid #e8ff47" : "1px solid rgba(255,255,255,0.2)",
              padding: "10px 24px", borderRadius: 100, fontSize: 13, fontWeight: 800, 
              textTransform: "uppercase", letterSpacing: 1, cursor: "pointer", transition: "all 0.2s"
            }}
          >
            {f}
          </button>
        ))}
      </div>

      {/* GRID */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(280px, 1fr))", gap: 32 }}>
        {filtered.map(eq => (
          <div key={eq.id} className="card eq-card" style={{ display: "flex", flexDirection: "column", overflow: "hidden" }}>
            <div style={{ height: 200, position: "relative", background: "#222" }}>
              <img src={eq.img} alt={eq.name} style={{ width: "100%", height: "100%", objectFit: "cover" }} />
              <div style={{ position: "absolute", inset: 0, background: "linear-gradient(to top, #111 0%, transparent 100%)" }} />
              <StatusBadge status={eq.status} />
            </div>
            <div style={{ padding: 24, flex: 1, display: "flex", flexDirection: "column" }}>
              <div style={{ fontSize: 13, textTransform: "uppercase", letterSpacing: 2, color: "rgba(255,255,255,0.5)", fontWeight: 700, marginBottom: 8 }}>{eq.category}</div>
              <h3 style={{ fontSize: 24, fontWeight: 800, margin: "0 0 24px", letterSpacing: -0.5 }}>{eq.name}</h3>
              
              <div style={{ display: "flex", gap: 12, marginTop: "auto" }}>
                <button 
                  onClick={() => { setActiveItem(eq); setModalType('log'); }}
                  disabled={eq.status === "Maintenance"}
                  className="btn-glow" style={{ flex: 1, background: eq.status === "Maintenance" ? "rgba(255,255,255,0.05)" : "#1a1a1a", color: eq.status === "Maintenance" ? "rgba(255,255,255,0.3)" : "#e8ff47", border: eq.status === "Maintenance" ? "none" : "1px solid rgba(232,255,71,0.5)", padding: "14px", borderRadius: 8, fontSize: 13, fontWeight: 800, textTransform: "uppercase", letterSpacing: 1, cursor: eq.status === "Maintenance" ? "not-allowed" : "pointer", transition: "all 0.2s", display: "flex", justifyContent: "center", alignItems: "center", gap: 8 }}
                >
                  <PenTool size={16} /> Log Use
                </button>
                <button 
                  onClick={() => { setActiveItem(eq); setModalType('report'); }}
                  className="btn-glow" style={{ flex: 1, background: "#1a1a1a", color: "#ff4747", border: "1px solid rgba(255,71,71,0.5)", padding: "14px", borderRadius: 8, fontSize: 13, fontWeight: 800, textTransform: "uppercase", letterSpacing: 1, cursor: "pointer", transition: "all 0.2s", display: "flex", justifyContent: "center", alignItems: "center", gap: 8 }}
                >
                  <AlertTriangle size={16} /> Report
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* MODALS */}
      {modalType && (
        <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.85)", zIndex: 9999, display: "flex", alignItems: "center", justifyContent: "center", backdropFilter: "blur(6px)" }} onClick={() => setModalType(null)}>
          <div className="card modal-content" onClick={e => e.stopPropagation()} style={{ width: 440, padding: 48, position: "relative", background: "#111", border: "1px solid rgba(255,255,255,0.1)" }}>
            <button style={{ position: "absolute", top: 24, right: 24, background: "none", border: "none", color: "rgba(255,255,255,0.5)", cursor: "pointer", transition: "color 0.2s" }} onMouseEnter={e => e.currentTarget.style.color = "#fff"} onMouseLeave={e => e.currentTarget.style.color = "rgba(255,255,255,0.5)"} onClick={() => setModalType(null)}>
              <X size={28} />
            </button>
            
            {modalType === 'log' && (
              <form onSubmit={handleLogUsage} style={{ display: "flex", flexDirection: "column", gap: 24 }}>
                <h2 style={{ fontSize: 32, fontWeight: 800, textTransform: "uppercase", marginBottom: 8, letterSpacing: -0.5 }}>Log Usage</h2>
                <div style={{ fontSize: 16, color: "rgba(255,255,255,0.6)", paddingBottom: 24, borderBottom: "1px solid rgba(255,255,255,0.1)" }}>{activeItem.name}</div>
                <div style={styles.formGroup}><label style={styles.label}>Member Name</label><input required style={styles.input} /></div>
                <div style={styles.formGroup}><label style={styles.label}>Duration (mins)</label><input type="number" required style={styles.input} /></div>
                <div style={styles.formGroup}><label style={styles.label}>Date</label><input type="date" required style={styles.input} /></div>
                <button type="submit" className="btn-glow" style={styles.submitBtn}>Submit Log</button>
              </form>
            )}

            {modalType === 'report' && (
              <form onSubmit={handleReport} style={{ display: "flex", flexDirection: "column", gap: 24 }}>
                <h2 style={{ fontSize: 32, fontWeight: 800, textTransform: "uppercase", marginBottom: 8, letterSpacing: -0.5 }}>Report Issue</h2>
                <div style={{ fontSize: 16, color: "rgba(255,255,255,0.6)", paddingBottom: 24, borderBottom: "1px solid rgba(255,255,255,0.1)" }}>{activeItem.name}</div>
                <div style={styles.formGroup}>
                  <label style={styles.label}>Issue Severity</label>
                  <select style={styles.input}><option>Low (Minor wear)</option><option>Medium (Needs check)</option><option>High (Broken/Unsafe)</option></select>
                </div>
                <div style={styles.formGroup}><label style={styles.label}>Description</label><textarea required rows={4} style={{...styles.input, resize:"none"}} /></div>
                <button type="submit" className="btn-glow" style={{...styles.submitBtn, background: "#ff4747", color: "#fff"}}>Submit Report</button>
              </form>
            )}

            {modalType === 'add' && (
              <form onSubmit={handleAdd} style={{ display: "flex", flexDirection: "column", gap: 24 }}>
                <h2 style={{ fontSize: 32, fontWeight: 800, textTransform: "uppercase", marginBottom: 16, letterSpacing: -0.5 }}>Add Equipment</h2>
                <div style={styles.formGroup}><label style={styles.label}>Equipment Name</label><input required style={styles.input} /></div>
                <div style={styles.formGroup}>
                  <label style={styles.label}>Category</label>
                  <select style={styles.input}><option>Cardio</option><option>Strength</option><option>Machines</option><option>Free Weights</option></select>
                </div>
                <div style={styles.formGroup}><label style={styles.label}>Purchase Date</label><input type="date" required style={styles.input} /></div>
                <div style={styles.formGroup}><label style={styles.label}>Condition</label><select style={styles.input}><option>New</option><option>Used - Good</option></select></div>
                <button type="submit" className="btn-glow" style={styles.submitBtn}>Add to Inventory</button>
              </form>
            )}
          </div>
        </div>
      )}

      {toast && (
        <div style={{ position: "fixed", bottom: 32, right: 120, background: "#e8ff47", color: "#000", padding: "16px 24px", borderRadius: 8, fontWeight: 700, fontSize: 16, display: "flex", alignItems: "center", gap: 12, animation: "slideInLeft 0.3s ease", zIndex: 9999, boxShadow: "0 12px 32px rgba(232,255,71,0.2)", textTransform: "uppercase", letterSpacing: 1 }}>
          <CheckCircle2 size={24} /> {toast}
        </div>
      )}

      <style>{`
        .eq-card:hover { transform: translateY(-4px); border-color: rgba(232,255,71,0.25); }
        .modal-content { animation: fadeInScale 0.3s cubic-bezier(0.16, 1, 0.3, 1); }
        @keyframes fadeInScale { from { opacity: 0; transform: scale(0.95) translateY(20px); } to { opacity: 1; transform: scale(1) translateY(0); } }
        @keyframes slideInLeft { from { opacity: 0; transform: translateX(50px); } to { opacity: 1; transform: translateX(0); } }
        input[type="date"]::-webkit-calendar-picker-indicator { filter: invert(1); cursor: pointer; }
      `}</style>
    </div>
  );
}

function StatBox({ label, value, color = "#fff" }) {
  return (
    <div className="card" style={{ padding: "32px" }}>
      <div style={{ fontSize: 14, textTransform: "uppercase", letterSpacing: 2, color: "rgba(255,255,255,0.5)", fontWeight: 700, marginBottom: 12 }}>{label}</div>
      <div style={{ fontSize: 56, fontWeight: 900, color: color, lineHeight: 1 }}>{value}</div>
    </div>
  );
}

function StatusBadge({ status }) {
  let color = "#4caf50";
  if (status === "In Use") color = "#ff9800";
  if (status === "Maintenance") color = "#ff4747";
  
  return (
    <div style={{ position: "absolute", top: 16, left: 16, background: "rgba(0,0,0,0.85)", backdropFilter: "blur(6px)", padding: "8px 16px", borderRadius: 100, display: "flex", alignItems: "center", gap: 8, fontSize: 12, fontWeight: 800, textTransform: "uppercase", letterSpacing: 1, border: "1px solid rgba(255,255,255,0.1)", color: "#fff", boxShadow: "0 4px 12px rgba(0,0,0,0.5)" }}>
      <div style={{ width: 8, height: 8, borderRadius: 4, background: color, boxShadow: "0 0 12px " + color }} />
      {status}
    </div>
  );
}

const styles = {
  formGroup: { display: "flex", flexDirection: "column", gap: 10 },
  label: { fontSize: 14, textTransform: "uppercase", letterSpacing: 1, color: "rgba(255,255,255,0.6)", fontWeight: 700 },
  input: { background: "#080808", border: "1px solid rgba(255,255,255,0.1)", color: "#fff", padding: "16px 20px", borderRadius: 8, fontSize: 15, fontFamily: "Inter", outline: "none", transition: "border-color 0.2s" },
  submitBtn: { background: "#e8ff47", color: "#000", border: "none", padding: "20px", borderRadius: 8, fontSize: 16, fontWeight: 900, textTransform: "uppercase", letterSpacing: 2, cursor: "pointer", marginTop: 8 }
};
