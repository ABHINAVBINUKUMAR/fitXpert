import { Save } from "lucide-react";

export default function SettingsAdmin() {
  return (
    <div style={{ animation: "fadeIn 0.5s ease", maxWidth: 800 }}>
       <div style={{ marginBottom: 40 }}>
        <h1 style={{ fontSize: 48, textTransform: "uppercase", fontWeight: 900, margin: 0, letterSpacing: -1 }}>
          System <span style={{ color: "#ff4444" }}>Settings</span>
        </h1>
        <p style={{ color: "rgba(255,255,255,0.5)", fontSize: 16, marginTop: 8 }}>Configure platform-wide settings.</p>
      </div>

      <div className="card" style={{ padding: 40 }}>
        <h2 style={{ fontSize: 20, fontWeight: 800, textTransform: "uppercase", marginBottom: 24, letterSpacing: 1 }}>General Configuration</h2>
        
        <div style={{ display: "flex", flexDirection: "column", gap: 24 }}>
          <div>
            <label style={{ display: "block", fontSize: 12, textTransform: "uppercase", letterSpacing: 1, color: "rgba(255,255,255,0.5)", fontWeight: 700, marginBottom: 8 }}>Gym Name</label>
            <input defaultValue="FITXPERT" style={{ width: "100%", background: "#050000", border: "1px solid rgba(255,68,68,0.2)", color: "#fff", padding: "14px", borderRadius: 8, fontSize: 14, outline: "none", boxSizing: "border-box" }} />
          </div>
          <div>
            <label style={{ display: "block", fontSize: 12, textTransform: "uppercase", letterSpacing: 1, color: "rgba(255,255,255,0.5)", fontWeight: 700, marginBottom: 8 }}>Support Email</label>
            <input defaultValue="support@fitxpert.com" style={{ width: "100%", background: "#050000", border: "1px solid rgba(255,68,68,0.2)", color: "#fff", padding: "14px", borderRadius: 8, fontSize: 14, outline: "none", boxSizing: "border-box" }} />
          </div>
          <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "16px 0", borderTop: "1px solid rgba(255,255,255,0.05)" }}>
            <div>
              <div style={{ fontSize: 16, fontWeight: 700, color: "#fff" }}>Enable Member Registration</div>
              <div style={{ fontSize: 13, color: "rgba(255,255,255,0.4)", marginTop: 4 }}>Allow new users to sign up from the landing page.</div>
            </div>
            <div style={{ width: 48, height: 24, background: "#ff4444", borderRadius: 12, position: "relative", cursor: "pointer" }}>
              <div style={{ width: 20, height: 20, background: "#fff", borderRadius: 10, position: "absolute", top: 2, right: 2 }} />
            </div>
          </div>
        </div>

        <button style={{ marginTop: 32, background: "#ff4444", color: "#fff", border: "none", padding: "16px 32px", borderRadius: 8, fontSize: 14, fontWeight: 900, textTransform: "uppercase", letterSpacing: 1, display: "flex", alignItems: "center", gap: 8, cursor: "pointer", boxShadow: "0 4px 16px rgba(255,68,68,0.2)" }}>
           <Save size={18} /> Save Preferences
        </button>
      </div>
    </div>
  );
}
