import { Search } from "lucide-react";

const LOGS = [
  { id: "L-9041", member: "Aria Chen", time: "Today, 10:42 AM", type: "Check-in", station: "Front Desk A" },
  { id: "L-9040", member: "David Kim", time: "Today, 09:15 AM", type: "Check-in", station: "Mobile App" },
  { id: "L-9039", member: "John Smith", time: "Today, 08:30 AM", type: "Check-out", station: "Front Desk B" },
  { id: "L-9038", member: "Emma Wilson", time: "Today, 07:10 AM", type: "Check-in", station: "Front Desk A" },
];

export default function AttendanceLogsAdmin() {
  return (
    <div style={{ animation: "fadeIn 0.5s ease" }}>
       <div>
        <h1 style={{ fontSize: 48, textTransform: "uppercase", fontWeight: 900, margin: 0, letterSpacing: -1 }}>
          Facility <span style={{ color: "#ff4444" }}>Access Logs</span>
        </h1>
        <p style={{ color: "rgba(255,255,255,0.5)", fontSize: 16, marginTop: 8, marginBottom: 40 }}>Live tracking of member entry and exit.</p>
      </div>

      <div className="card" style={{ padding: 24 }}>
        <div style={{ position: "relative", marginBottom: 24 }}>
          <Search size={20} color="rgba(255,255,255,0.4)" style={{ position: "absolute", left: 16, top: "50%", transform: "translateY(-50%)" }} />
          <input placeholder="Search logs by member name or ID..." style={{ width: "100%", background: "#050000", border: "1px solid rgba(255,68,68,0.2)", color: "#fff", padding: "14px 16px 14px 48px", borderRadius: 8, fontSize: 14, outline: "none", boxSizing: "border-box" }} />
        </div>

        <table style={{ width: "100%", borderCollapse: "collapse" }}>
          <thead>
            <tr style={{ borderBottom: "1px solid rgba(255,255,255,0.1)" }}>
              <th style={{ padding: "16px", textAlign: "left", fontSize: 12, textTransform: "uppercase", color: "rgba(255,255,255,0.4)" }}>Log ID</th>
              <th style={{ padding: "16px", textAlign: "left", fontSize: 12, textTransform: "uppercase", color: "rgba(255,255,255,0.4)" }}>Member</th>
              <th style={{ padding: "16px", textAlign: "left", fontSize: 12, textTransform: "uppercase", color: "rgba(255,255,255,0.4)" }}>Timestamp</th>
              <th style={{ padding: "16px", textAlign: "left", fontSize: 12, textTransform: "uppercase", color: "rgba(255,255,255,0.4)" }}>Event Type</th>
              <th style={{ padding: "16px", textAlign: "left", fontSize: 12, textTransform: "uppercase", color: "rgba(255,255,255,0.4)" }}>Station</th>
            </tr>
          </thead>
          <tbody>
            {LOGS.map(l => (
              <tr key={l.id} style={{ borderBottom: "1px solid rgba(255,255,255,0.05)" }}>
                <td style={{ padding: "16px", fontSize: 14, color: "rgba(255,255,255,0.6)" }}>{l.id}</td>
                <td style={{ padding: "16px", fontWeight: 700 }}>{l.member}</td>
                <td style={{ padding: "16px", fontSize: 14, color: "rgba(255,255,255,0.8)" }}>{l.time}</td>
                <td style={{ padding: "16px" }}>
                  <span style={{ color: l.type === "Check-in" ? "#4caf50" : "#ff9800", background: l.type === "Check-in" ? "rgba(76,175,80,0.1)" : "rgba(255,152,0,0.1)", padding: "4px 8px", borderRadius: 4, fontSize: 11, fontWeight: 800, textTransform: "uppercase" }}>{l.type}</span>
                </td>
                <td style={{ padding: "16px", fontSize: 14, color: "rgba(255,255,255,0.6)" }}>{l.station}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
