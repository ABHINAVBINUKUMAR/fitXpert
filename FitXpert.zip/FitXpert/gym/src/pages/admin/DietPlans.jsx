import { Plus, Edit3, Trash2 } from "lucide-react";

const DIETS = [
  { name: "Fat Loss Aggressive", type: "Low Carb", cals: 1800, desc: "High protein, minimal carbs for rapid cutting." },
  { name: "Lean Bulking", type: "High Carb", cals: 3200, desc: "Slight caloric surplus with balanced macros." },
  { name: "Maintenance Protocol", type: "Balanced", cals: 2500, desc: "Standard recomposition diet." }
];

export default function DietPlansAdmin() {
  return (
    <div style={{ animation: "fadeIn 0.5s ease" }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 40 }}>
        <div>
          <h1 style={{ fontSize: 48, textTransform: "uppercase", fontWeight: 900, margin: 0, letterSpacing: -1 }}>
            Diet <span style={{ color: "#ff4444" }}>Protocols</span>
          </h1>
          <p style={{ color: "rgba(255,255,255,0.5)", fontSize: 16, marginTop: 8 }}>Global nutrition blueprints.</p>
        </div>
        <button style={{ background: "#ff4444", color: "#fff", border: "none", padding: "12px 24px", borderRadius: 8, fontSize: 14, fontWeight: 900, textTransform: "uppercase", letterSpacing: 1, display: "flex", alignItems: "center", gap: 8, cursor: "pointer", boxShadow: "0 4px 16px rgba(255,68,68,0.2)" }}>
           <Plus size={18} /> New Protocol
        </button>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1fr", gap: 16 }}>
        {DIETS.map((d, i) => (
          <div key={i} className="card" style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: 24 }}>
            <div>
              <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 8 }}>
                <h3 style={{ fontSize: 20, fontWeight: 900, textTransform: "uppercase", margin: 0 }}>{d.name}</h3>
                <span style={{ fontSize: 11, background: "rgba(255,255,255,0.1)", padding: "2px 8px", borderRadius: 4, textTransform: "uppercase", letterSpacing: 1 }}>{d.type}</span>
                <span style={{ fontSize: 11, background: "rgba(255,68,68,0.1)", color: "#ff4444", padding: "2px 8px", borderRadius: 4, textTransform: "uppercase", letterSpacing: 1 }}>{d.cals} KCAL</span>
              </div>
              <p style={{ color: "rgba(255,255,255,0.5)", margin: 0, fontSize: 14 }}>{d.desc}</p>
            </div>
            <div style={{ display: "flex", gap: 8 }}>
              <button style={{ background: "transparent", color: "#fff", border: "1px solid rgba(255,255,255,0.2)", padding: 12, borderRadius: 8, cursor: "pointer" }}><Edit3 size={18} /></button>
              <button style={{ background: "rgba(255,68,68,0.1)", color: "#ff4444", border: "1px solid rgba(255,68,68,0.2)", padding: 12, borderRadius: 8, cursor: "pointer" }}><Trash2 size={18} /></button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
