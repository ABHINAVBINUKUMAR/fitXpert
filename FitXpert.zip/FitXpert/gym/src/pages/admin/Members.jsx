import { useEffect, useState } from "react";
import { Search, Plus, Filter, MoreVertical, Edit2, ShieldBan, CalendarCheck } from "lucide-react";
import { apiFetch } from "../../lib/api";

export default function MembersList() {
  const [members, setMembers] = useState([]);
  const [showModal, setShowModal] = useState(false);
  const [toast, setToast] = useState('');

  useEffect(() => {
    const loadMembers = async () => {
      try {
        const response = await apiFetch('/members');
        setMembers(response.members || []);
      } catch (error) {
        setToast('Unable to load member list');
      }
    };

    loadMembers();
  }, []);

  const handleUpdateMember = async (memberId, updates) => {
    try {
      const response = await apiFetch(`/members/${memberId}`, {
        method: 'PATCH',
        body: updates,
      });

      setMembers(prev => prev.map(member => member.id === memberId ? { ...member, ...response.member } : member));
      setToast('Member updated');
      setTimeout(() => setToast(''), 2000);
    } catch (error) {
      setToast(error.message || 'Unable to update member');
      setTimeout(() => setToast(''), 2000);
    }
  };

  const handleAddAttendance = async (memberId, name) => {
    try {
      await apiFetch(`/members/${memberId}/attendance`, { method: 'POST' });
      setToast(`Attendance marked for ${name}`);
      setTimeout(() => setToast(''), 3000);
    } catch (error) {
      setToast(error.message || 'Unable to mark attendance');
      setTimeout(() => setToast(''), 3000);
    }
  };

  return (
    <div style={{ animation: "fadeIn 0.5s ease" }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-end", marginBottom: 40 }}>
        <div>
          <h1 style={{ fontSize: 48, textTransform: "uppercase", fontWeight: 900, margin: 0, letterSpacing: -1 }}>
            Member <span style={{ color: "#ff4444" }}>Directory</span>
          </h1>
          <p style={{ color: "rgba(255,255,255,0.5)", fontSize: 16, marginTop: 8 }}>Manage your 248 active members.</p>
        </div>
        <button onClick={() => setShowModal(true)} style={{ background: "#ff4444", color: "#fff", border: "none", padding: "12px 24px", borderRadius: 8, fontSize: 14, fontWeight: 900, textTransform: "uppercase", letterSpacing: 1, display: "flex", alignItems: "center", gap: 8, cursor: "pointer", boxShadow: "0 4px 16px rgba(255,68,68,0.2)" }}>
           <Plus size={18} /> Add Member
        </button>
      </div>

      <div className="card" style={{ padding: 24 }}>
        <div style={{ display: "flex", gap: 16, marginBottom: 24 }}>
          <div style={{ flex: 1, position: "relative" }}>
            <Search size={20} color="rgba(255,255,255,0.4)" style={{ position: "absolute", left: 16, top: "50%", transform: "translateY(-50%)" }} />
            <input placeholder="Search members by name, email, or ID..." style={{ width: "100%", background: "#050000", border: "1px solid rgba(255,68,68,0.2)", color: "#fff", padding: "14px 16px 14px 48px", borderRadius: 8, fontSize: 14, outline: "none" }} />
          </div>
          <button style={{ background: "rgba(255,68,68,0.1)", color: "#ff4444", border: "1px solid rgba(255,68,68,0.2)", padding: "0 24px", borderRadius: 8, display: "flex", alignItems: "center", gap: 8, fontSize: 14, fontWeight: 700, cursor: "pointer" }}><Filter size={18} /> Filters</button>
        </div>

        <table style={{ width: "100%", borderCollapse: "collapse" }}>
          <thead>
            <tr style={{ borderBottom: "1px solid rgba(255,255,255,0.1)" }}>
              <th style={{ padding: "16px", textAlign: "left", fontSize: 12, textTransform: "uppercase", letterSpacing: 1, color: "rgba(255,255,255,0.4)" }}>Name & ID</th>
              <th style={{ padding: "16px", textAlign: "left", fontSize: 12, textTransform: "uppercase", letterSpacing: 1, color: "rgba(255,255,255,0.4)" }}>Plan & Fee</th>
              <th style={{ padding: "16px", textAlign: "left", fontSize: 12, textTransform: "uppercase", letterSpacing: 1, color: "rgba(255,255,255,0.4)" }}>Billing & Expiry</th>
              <th style={{ padding: "16px", textAlign: "left", fontSize: 12, textTransform: "uppercase", letterSpacing: 1, color: "rgba(255,255,255,0.4)" }}>Status</th>
              <th style={{ padding: "16px", textAlign: "right", fontSize: 12, textTransform: "uppercase", letterSpacing: 1, color: "rgba(255,255,255,0.4)" }}>Actions</th>
            </tr>
          </thead>
          <tbody>
            {members.map((m) => (
              <tr key={m.id} style={{ borderBottom: "1px solid rgba(255,255,255,0.05)" }}>
                <td style={{ padding: "20px 16px" }}>
                  <div style={{ fontWeight: 800, fontSize: 15, marginBottom: 4 }}>{m.name}</div>
                  <div style={{ fontSize: 13, color: "rgba(255,255,255,0.4)" }}>ID: {m.id}</div>
                </td>
                <td style={{ padding: "20px 16px" }}>
                  <span style={{ background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.1)", padding: "4px 8px", borderRadius: 4, fontSize: 11, fontWeight: 800, letterSpacing: 1, marginRight: 8 }}>{m.plan}</span>
                  <div style={{ fontSize: 14, color: "#e8ff47", fontWeight: 700, display: "inline-block" }}>{m.fee}</div>
                </td>
                <td style={{ padding: "20px 16px" }}>
                  <div style={{ fontSize: 14, color: "#fff", marginBottom: 4 }}>Exp: <span style={{ fontWeight: 700 }}>{m.expiry}</span></div>
                  <div style={{ fontSize: 12, color: "rgba(255,255,255,0.5)" }}>Paid: {m.lastPayment}</div>
                </td>
                <td style={{ padding: "20px 16px" }}>
                  <span style={{ display: "inline-flex", alignItems: "center", gap: 6, color: m.status === "Active" ? "#4caf50" : "#ff4444", fontSize: 13, fontWeight: 700 }}><div style={{ width: 6, height: 6, borderRadius: 3, background: m.status === "Active" ? "#4caf50" : "#ff4444" }}/>{m.status}</span>
                </td>
                <td style={{ padding: "20px 16px", textAlign: "right" }}>
                  <button onClick={() => handleAddAttendance(m.id, m.name)} style={{ background: "rgba(76,175,80,0.1)", color: "#4caf50", border: "1px solid rgba(76,175,80,0.2)", cursor: "pointer", marginRight: 12, padding: "8px 12px", borderRadius: 6, fontWeight: 700, fontSize: 12, textTransform: "uppercase", display: "inline-flex", alignItems: "center", gap: 6 }} title="Add Attendance"><CalendarCheck size={14}/> Mark Present</button>
                  <button onClick={() => handleUpdateMember(m.id, { status: m.status === 'active' ? 'inactive' : 'active' })} style={{ background: "transparent", color: "rgba(255,255,255,0.6)", border: "none", cursor: "pointer", marginRight: 12 }} title="Edit"><Edit2 size={18} /></button>
                  <button style={{ background: "transparent", color: "#ff4444", border: "none", cursor: "pointer" }} title="Revoke"><ShieldBan size={18} /></button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {toast && (
        <div style={{
          position: "fixed", bottom: 32, right: 32, background: "#4caf50", color: "#fff",
          padding: "16px 24px", borderRadius: 8, fontWeight: 700, fontSize: 15,
          display: "flex", alignItems: "center", gap: 12,
          animation: "slideInLeft 0.3s ease", zIndex: 9999,
          boxShadow: "0 12px 32px rgba(76,175,80,0.2)",
          textTransform: "uppercase", letterSpacing: 1
        }}>
          <CalendarCheck size={20} /> {toast}
        </div>
      )}

      {showModal && (
        <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.8)", backdropFilter: "blur(4px)", zIndex: 1000, display: "flex", alignItems: "center", justifyContent: "center" }}>
          <div className="card" style={{ width: "100%", maxWidth: 500, padding: 32, animation: "scaleIn 0.3s cubic-bezier(0.16, 1, 0.3, 1)" }}>
            <h2 style={{ fontSize: 24, fontWeight: 900, textTransform: "uppercase", marginBottom: 24, color: "#ff4444" }}>Add New Member</h2>
            <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
              <div><label style={styles.label}>Full Name</label><input style={styles.input} /></div>
              <div><label style={styles.label}>Email</label><input type="email" style={styles.input} /></div>
              <div><label style={styles.label}>Subscription Plan</label><select style={styles.input}><option>STARTER</option><option>PRO</option><option>ELITE</option></select></div>
              <div style={{ display: "flex", gap: 16, marginTop: 16 }}>
                <button onClick={() => setShowModal(false)} style={{ flex: 1, background: "transparent", border: "1px solid rgba(255,255,255,0.2)", color: "#fff", padding: 14, borderRadius: 8, fontWeight: 700, cursor: "pointer" }}>Cancel</button>
                <button onClick={() => setShowModal(false)} style={{ flex: 1, background: "#ff4444", border: "none", color: "#fff", padding: 14, borderRadius: 8, fontWeight: 800, textTransform: "uppercase", cursor: "pointer" }}>Provision Account</button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

const styles = {
  label: { display: "block", fontSize: 12, textTransform: "uppercase", letterSpacing: 1, color: "rgba(255,255,255,0.5)", fontWeight: 700, marginBottom: 8 },
  input: { width: "100%", background: "#050000", border: "1px solid rgba(255,68,68,0.2)", color: "#fff", padding: "14px", borderRadius: 8, fontSize: 14, outline: "none", boxSizing: "border-box" }
};
