import { Trophy, Target, Award } from "lucide-react";

export default function GamificationAdmin() {
  return (
    <div style={{ animation: "fadeIn 0.5s ease" }}>
       <div style={{ marginBottom: 40 }}>
        <h1 style={{ fontSize: 48, textTransform: "uppercase", fontWeight: 900, margin: 0, letterSpacing: -1 }}>
          Engagement & <span style={{ color: "#ff4444" }}>Gamification</span>
        </h1>
        <p style={{ color: "rgba(255,255,255,0.5)", fontSize: 16, marginTop: 8 }}>Manage leaderboards and achievement criteria.</p>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 24 }}>
        <div className="card" style={{ padding: 32 }}>
          <h2 style={{ fontSize: 20, fontWeight: 800, textTransform: "uppercase", marginBottom: 24, display: "flex", alignItems: "center", gap: 12 }}><Trophy color="#ff4444" /> Monthly Leaderboard Reward</h2>
          <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
            <div>
              <label style={{ display: "block", fontSize: 12, textTransform: "uppercase", color: "rgba(255,255,255,0.5)", fontWeight: 700, marginBottom: 8 }}>Current Prize</label>
              <input value="1 Month Free Elite Membership" readOnly style={{ width: "100%", background: "#050000", border: "1px solid rgba(255,68,68,0.2)", color: "#fff", padding: "14px", borderRadius: 8, fontSize: 14, boxSizing: "border-box" }} />
            </div>
            <button style={{ background: "rgba(255,68,68,0.1)", color: "#ff4444", border: "1px solid rgba(255,68,68,0.2)", padding: "12px", borderRadius: 8, fontSize: 14, fontWeight: 800, cursor: "pointer", textTransform: "uppercase" }}>Update Prize Pool</button>
          </div>
        </div>
        
        <div className="card" style={{ padding: 32 }}>
           <h2 style={{ fontSize: 20, fontWeight: 800, textTransform: "uppercase", marginBottom: 24, display: "flex", alignItems: "center", gap: 12 }}><Target color="#ff4444" /> Platform Achievements</h2>
           <p style={{ color: "rgba(255,255,255,0.6)", fontSize: 14, lineHeight: 1.6, marginBottom: 24 }}>12 active badges available for members to unlock based on consistency and effort.</p>
           <button style={{ background: "#ff4444", color: "#fff", border: "none", padding: "12px", borderRadius: 8, fontSize: 14, fontWeight: 800, cursor: "pointer", textTransform: "uppercase", width: "100%" }}>Create New Badge</button>
        </div>
      </div>
    </div>
  );
}
