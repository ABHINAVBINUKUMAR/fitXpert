import { Plus, Star, Users } from "lucide-react";

const TRAINERS = [
  { name: "Marcus Steele", role: "Strength & Conditioning", clients: 24, rating: 4.9, img: "https://images.unsplash.com/photo-1567013127542-490d757e51fc?w=400&q=80" },
  { name: "Aria Chen", role: "HIIT & Cardio", clients: 38, rating: 4.8, img: "https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?w=400&q=80" },
  { name: "Dev Ramos", role: "Combat & MMA", clients: 16, rating: 5.0, img: "https://images.unsplash.com/photo-1583454110551-21f2fa2afe61?w=400&q=80" },
  { name: "Elena Rostova", role: "Yoga & Mobility", clients: 42, rating: 4.9, img: "https://images.unsplash.com/photo-1544367567-0f2fcb009e0b?w=400&q=80" },
];

export default function TrainersAdmin() {
  return (
    <div style={{ animation: "fadeIn 0.5s ease" }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 40 }}>
        <div>
          <h1 style={{ fontSize: 48, textTransform: "uppercase", fontWeight: 900, margin: 0, letterSpacing: -1 }}>
            Trainer <span style={{ color: "#ff4444" }}>Roster</span>
          </h1>
          <p style={{ color: "rgba(255,255,255,0.5)", fontSize: 16, marginTop: 8 }}>Manage your elite coaching staff.</p>
        </div>
        <button style={{ background: "#ff4444", color: "#fff", border: "none", padding: "12px 24px", borderRadius: 8, fontSize: 14, fontWeight: 900, textTransform: "uppercase", letterSpacing: 1, display: "flex", alignItems: "center", gap: 8, cursor: "pointer", boxShadow: "0 4px 16px rgba(255,68,68,0.2)" }}>
           <Plus size={18} /> Onboard Coach
        </button>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(300px, 1fr))", gap: 24 }}>
        {TRAINERS.map((t, i) => (
          <div key={i} className="card" style={{ overflow: "hidden" }}>
            <div style={{ padding: 24, display: "flex", gap: 20 }}>
              <img src={t.img} alt={t.name} style={{ width: 80, height: 80, borderRadius: 12, objectFit: "cover" }} />
              <div>
                <h3 style={{ fontSize: 20, fontWeight: 900, textTransform: "uppercase", margin: "0 0 4px" }}>{t.name}</h3>
                <div style={{ color: "#ff4444", fontSize: 12, fontWeight: 700, textTransform: "uppercase", letterSpacing: 1, marginBottom: 12 }}>{t.role}</div>
                <div style={{ display: "flex", gap: 16 }}>
                  <div style={{ display: "flex", alignItems: "center", gap: 6, fontSize: 13, color: "rgba(255,255,255,0.6)" }}><Users size={14} /> {t.clients}</div>
                  <div style={{ display: "flex", alignItems: "center", gap: 6, fontSize: 13, color: "rgba(255,255,255,0.6)" }}><Star size={14} color="#f59e0b" fill="#f59e0b" /> {t.rating}</div>
                </div>
              </div>
            </div>
            <div style={{ display: "flex", borderTop: "1px solid rgba(255,255,255,0.05)" }}>
              <button style={{ flex: 1, padding: 16, background: "transparent", color: "#fff", border: "none", borderRight: "1px solid rgba(255,255,255,0.05)", fontWeight: 700, cursor: "pointer" }}>Edit Profile</button>
              <button style={{ flex: 1, padding: 16, background: "rgba(255,68,68,0.05)", color: "#ff4444", border: "none", fontWeight: 700, cursor: "pointer" }}>View Schedule</button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
