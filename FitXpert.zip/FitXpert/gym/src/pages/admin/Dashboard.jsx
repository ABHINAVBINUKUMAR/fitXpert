import { BarChart, Bar, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from "recharts";
import { Users, Activity, IndianRupee, Wrench, Bell, Clock } from "lucide-react";

const REVENUE_DATA = [
  { name: 'Jan', val: 95000 }, { name: 'Feb', val: 102000 }, { name: 'Mar', val: 124500 }, 
  { name: 'Apr', val: 110000 }, { name: 'May', val: 118000 }, { name: 'Jun', val: 132000 },
  { name: 'Jul', val: 145000 }, { name: 'Aug', val: 142000 }, { name: 'Sep', val: 155000 },
  { name: 'Oct', val: 158000 }, { name: 'Nov', val: 162000 }, { name: 'Dec', val: 175000 }
];

const CHECKIN_DATA = [
  { name: 'Mon', val: 142 }, { name: 'Tue', val: 185 }, { name: 'Wed', val: 165 },
  { name: 'Thu', val: 190 }, { name: 'Fri', val: 160 }, { name: 'Sat', val: 95 }, { name: 'Sun', val: 120 }
];

const EQ_DATA = [
  { name: 'Available', val: 42, color: '#4caf50' },
  { name: 'In Use', val: 5, color: '#ff9800' },
  { name: 'Maintenance', val: 3, color: '#ff4444' }
];

const ACTIVITY = [
  { time: "10:42 AM", msg: "Marcus Steele completed 1:1 session with John" },
  { time: "10:30 AM", msg: "New Elite membership purchased" },
  { time: "09:15 AM", msg: "Treadmill #4 marked for maintenance" },
  { time: "08:45 AM", msg: "Aria Chen started HIIT class" },
  { time: "08:10 AM", msg: "Concept2 Rower usage logged" },
  { time: "07:30 AM", msg: "Peak hours started (85 members active)" },
  { time: "06:45 AM", msg: "Daily system backup completed" },
  { time: "06:00 AM", msg: "Facility opened" },
];

export default function AdminDashboard() {
  return (
    <div style={{ animation: "fadeIn 0.5s ease" }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 40 }}>
        <div>
          <h1 style={{ fontSize: 48, textTransform: "uppercase", fontWeight: 900, margin: 0, letterSpacing: -1 }}>
            Admin <span style={{ color: "#ff4444" }}>Control Panel</span>
          </h1>
          <p style={{ color: "rgba(255,255,255,0.5)", fontSize: 16, marginTop: 8 }}>Overview of facility operations and metrics.</p>
        </div>
        <button style={{ background: "#ff4444", color: "#fff", border: "none", padding: "12px 24px", borderRadius: 8, fontSize: 14, fontWeight: 900, textTransform: "uppercase", letterSpacing: 1, display: "flex", alignItems: "center", gap: 8, cursor: "pointer", boxShadow: "0 4px 16px rgba(255,68,68,0.2)" }}>
           Generate Report
        </button>
      </div>

      {/* KPI ROW */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(240px, 1fr))", gap: 24, marginBottom: 40 }}>
        <KpiBox title="Total Members" value="248" trend="+12 this week" icon={<Users />} color="#ff4444" />
        <KpiBox title="Active Today" value="64" trend="15% vs yesterday" icon={<Activity />} color="#4caf50" />
        <KpiBox title="Monthly Revenue" value="₹1,24,500" trend="+8% vs last month" icon={<IndianRupee />} color="#e8ff47" />
        <KpiBox title="Equipment Status" value="42/50" trend="3 in maintenance" icon={<Wrench />} color="#ff9800" />
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "2fr 1fr", gap: 24, marginBottom: 24 }}>
        
        {/* CHARTS */}
        <div style={{ display: "flex", flexDirection: "column", gap: 24 }}>
          {/* Revenue Area */}
          <div className="card" style={{ padding: 32, background: "#110000", border: "1px solid rgba(255,68,68,0.15)" }}>
            <h2 style={{ fontSize: 18, fontWeight: 800, textTransform: "uppercase", marginBottom: 24, letterSpacing: 1, color: "#ff4444" }}>Revenue Pipeline (YTD)</h2>
            <div style={{ height: 300, width: "100%" }}>
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={REVENUE_DATA}>
                  <defs>
                    <linearGradient id="colorRev" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#ff4444" stopOpacity={0.3}/>
                      <stop offset="95%" stopColor="#ff4444" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" vertical={false} />
                  <XAxis dataKey="name" stroke="rgba(255,255,255,0.4)" axisLine={false} tickLine={false} dy={10} fontSize={12} />
                  <YAxis stroke="rgba(255,255,255,0.4)" axisLine={false} tickLine={false} dx={-10} fontSize={12} tickFormatter={(v) => `₹${v/1000}K`} />
                  <Tooltip contentStyle={{ background: "#0a0a0a", border: "1px solid rgba(255,68,68,0.3)", borderRadius: 8, color: "#fff" }} itemStyle={{ color: "#ff4444", fontWeight: 800 }} />
                  <Line type="monotone" dataKey="val" stroke="#ff4444" strokeWidth={3} dot={{ fill: "#0a0a0a", stroke: "#ff4444", strokeWidth: 2, r: 4 }} activeDot={{ r: 6, fill: "#ff4444" }} />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>

          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 24 }}>
            
            {/* Check-ins Bar */}
            <div className="card" style={{ padding: 32 }}>
              <h2 style={{ fontSize: 18, fontWeight: 800, textTransform: "uppercase", marginBottom: 24, letterSpacing: 1, color: "rgba(255,255,255,0.6)" }}>Weekly Footfall</h2>
              <div style={{ height: 200, width: "100%" }}>
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={CHECKIN_DATA}>
                    <Tooltip cursor={{ fill: "rgba(255,255,255,0.05)" }} contentStyle={{ background: "#111", border: "none", borderRadius: 8 }} />
                    <Bar dataKey="val" fill="rgba(255,68,68,0.8)" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* EQ Donut */}
            <div className="card" style={{ padding: 32, display: "flex", flexDirection: "column" }}>
              <h2 style={{ fontSize: 18, fontWeight: 800, textTransform: "uppercase", marginBottom: 24, letterSpacing: 1, color: "rgba(255,255,255,0.6)" }}>Hardware Matrix</h2>
              <div style={{ height: 200, width: "100%", position: "relative" }}>
                 <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie data={EQ_DATA} cx="50%" cy="50%" innerRadius={60} outerRadius={80} paddingAngle={5} dataKey="val" stroke="none">
                        {EQ_DATA.map((entry, index) => <Cell key={`cell-${index}`} fill={entry.color} />)}
                      </Pie>
                      <Tooltip contentStyle={{ background: "#111", border: "none", borderRadius: 8 }} />
                    </PieChart>
                 </ResponsiveContainer>
                 <div style={{ position: "absolute", inset: 0, display: "flex", alignItems: "center", justifyContent: "center", flexDirection: "column" }}>
                   <div style={{ fontSize: 32, fontWeight: 900 }}>50</div>
                   <div style={{ fontSize: 12, color: "rgba(255,255,255,0.4)", textTransform: "uppercase", letterSpacing: 1 }}>Total</div>
                 </div>
              </div>
            </div>

          </div>
        </div>

        {/* SIDEBAR WIDGETS */}
        <div style={{ display: "flex", flexDirection: "column", gap: 24 }}>
          
          {/* Alerts */}
          <div className="card" style={{ padding: 24, background: "rgba(255,68,68,0.05)", border: "1px solid rgba(255,68,68,0.2)" }}>
            <h3 style={{ fontSize: 14, fontWeight: 800, textTransform: "uppercase", letterSpacing: 1, color: "#ff4444", marginBottom: 16, display: "flex", alignItems: "center", gap: 8 }}>
              <Bell size={16} /> Critical Alerts
            </h3>
            <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
              <div style={{ fontSize: 14, padding: "12px", background: "rgba(255,68,68,0.1)", borderRadius: 6, borderLeft: "3px solid #ff4444", color: "#fff" }}>
                <strong>2</strong> Equipment overdue maintenance
              </div>
              <div style={{ fontSize: 14, padding: "12px", background: "rgba(255,152,0,0.1)", borderRadius: 6, borderLeft: "3px solid #ff9800", color: "#fff" }}>
                <strong>5</strong> Members inactive for 30+ days
              </div>
            </div>
          </div>

          {/* Activity Feed */}
          <div className="card" style={{ padding: 32, flex: 1, display: "flex", flexDirection: "column" }}>
            <h2 style={{ fontSize: 18, fontWeight: 800, textTransform: "uppercase", marginBottom: 24, letterSpacing: 1, color: "rgba(255,255,255,0.6)" }}>Live Activity</h2>
            <div style={{ display: "flex", flexDirection: "column", gap: 16, overflowY: "auto", paddingRight: 8 }}>
              {ACTIVITY.map((a, i) => (
                <div key={i} style={{ display: "flex", gap: 16, position: "relative" }}>
                  <div style={{ width: 1, background: "rgba(255,255,255,0.1)", position: "absolute", left: 19, top: 24, bottom: -16 }} />
                  <div style={{ color: "rgba(255,255,255,0.4)", fontSize: 12, fontWeight: 700, width: 60, flexShrink: 0, paddingTop: 2 }}>{a.time}</div>
                  <div style={{ width: 8, height: 8, borderRadius: 4, background: "#ff4444", marginTop: 6, position: "relative", zIndex: 1, boxShadow: "0 0 8px rgba(255,68,68,0.6)" }} />
                  <div style={{ fontSize: 14, color: "rgba(255,255,255,0.8)", paddingBottom: 16 }}>{a.msg}</div>
                </div>
              ))}
            </div>
          </div>

        </div>
      </div>
    </div>
  );
}

function KpiBox({ title, value, trend, icon, color }) {
  return (
    <div className="card" style={{ padding: 24, display: "flex", flexDirection: "column", gap: 16 }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <div style={{ fontSize: 13, textTransform: "uppercase", letterSpacing: 1, color: "rgba(255,255,255,0.5)", fontWeight: 700 }}>{title}</div>
        <div style={{ width: 40, height: 40, borderRadius: 8, background: `rgba(255,255,255,0.05)`, color: color, display: "flex", alignItems: "center", justifyContent: "center" }}>
          {icon}
        </div>
      </div>
      <div>
        <div style={{ fontSize: 40, fontWeight: 900, marginBottom: 8 }}>{value}</div>
        <div style={{ fontSize: 13, color: "rgba(255,255,255,0.4)", fontWeight: 600 }}>{trend}</div>
      </div>
    </div>
  )
}
