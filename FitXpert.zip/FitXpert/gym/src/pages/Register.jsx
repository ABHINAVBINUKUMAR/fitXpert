import { useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import { Mail, Lock, User, ShieldAlert, CheckCircle2 } from "lucide-react";
import { useAuth } from "../context/AuthContext";

export default function Register() {
  const navigate = useNavigate();
  const { register } = useAuth();
  const [formData, setFormData] = useState({ name: "", email: "", password: "", confirm: "" });
  const [error, setError] = useState("");
  const [success, setSuccess] = useState(false);

  const handleRegister = async (e) => {
    e.preventDefault();
    setError("");
    
    if (!formData.name || !formData.email || !formData.password || !formData.confirm) {
      setError("Please fill in all fields.");
      return;
    }

    if (!formData.email.includes("@")) {
      setError("Please enter a valid email address.");
      return;
    }

    if (formData.password.length < 6) {
      setError("Password must be at least 6 characters.");
      return;
    }

    if (formData.password !== formData.confirm) {
      setError("Passwords do not match.");
      return;
    }

    try {
      await register({
        name: formData.name,
        email: formData.email,
        password: formData.password,
        password_confirmation: formData.confirm,
      });

      setSuccess(true);
      setTimeout(() => navigate("/login/member"), 1500);
    } catch (error) {
      setError(error.message || "Unable to create account.");
    }
  };

  return (
    <div style={{ minHeight: "100vh", background: "#0a0a0a", display: "flex", alignItems: "center", justifyContent: "center", padding: 24, position: "relative", overflow: "hidden" }}>
      {/* Background flare */}
      <div style={{ position: "absolute", width: "50vw", height: "50vw", background: "radial-gradient(circle, rgba(232,255,71,0.04) 0%, transparent 70%)", top: "50%", left: "-20%", transform: "translateY(-50%)", zIndex: 0 }} />
      
      <div className="card" style={{ width: "100%", maxWidth: 500, padding: 48, position: "relative", zIndex: 1, animation: "fadeIn 0.5s ease" }}>
        
        {success ? (
          <div style={{ textAlign: "center", animation: "fadeIn 0.5s ease" }}>
             <div style={{ display: "inline-flex", background: "rgba(232,255,71,0.1)", borderRadius: 100, padding: 24, marginBottom: 24, border: "1px solid rgba(232,255,71,0.3)" }}>
              <CheckCircle2 size={64} color="#e8ff47" />
            </div>
            <h2 style={{ fontSize: 32, fontWeight: 900, color: "#fff", textTransform: "uppercase" }}>Registration Successful</h2>
            <p style={{ color: "rgba(255,255,255,0.6)", fontSize: 16, fontFamily: "Inter", marginTop: 8 }}>Redirecting to login...</p>
          </div>
        ) : (
          <>
            <div style={{ textAlign: "center", marginBottom: 32 }}>
              <div style={{ fontSize: 40, color: "#e8ff47", lineHeight: 1, marginBottom: 16 }}>⬡</div>
              <h1 style={{ fontSize: 36, textTransform: "uppercase", fontWeight: 900, margin: 0, letterSpacing: 1, color: "#fff" }}>
                 Join FitXpert
              </h1>
              <p style={{ color: "rgba(255,255,255,0.5)", marginTop: 12, fontSize: 16, fontFamily: "Inter" }}>Create your account and start your journey.</p>
            </div>

            {error && (
              <div style={{ background: "rgba(255,71,71,0.1)", border: "1px solid rgba(255,71,71,0.3)", padding: "12px 16px", borderRadius: 8, color: "#ff4747", fontSize: 14, fontWeight: 700, marginBottom: 24, display: "flex", alignItems: "center", gap: 10 }}>
                <ShieldAlert size={18} /> {error}
              </div>
            )}

            <form onSubmit={handleRegister} style={{ display: "flex", flexDirection: "column", gap: 20 }}>
              <div style={styles.formGroup}>
                <label style={styles.label}>Full Name</label>
                <div style={{ position: "relative" }}>
                  <User size={20} color="rgba(255,255,255,0.3)" style={{ position: "absolute", left: 16, top: "50%", transform: "translateY(-50%)" }} />
                  <input 
                    type="text"
                    value={formData.name}
                    onChange={e => setFormData({...formData, name: e.target.value})}
                    placeholder="John Doe" 
                    style={{...styles.input, paddingLeft: 48}} 
                  />
                </div>
              </div>

              <div style={styles.formGroup}>
                <label style={styles.label}>Email Address</label>
                <div style={{ position: "relative" }}>
                  <Mail size={20} color="rgba(255,255,255,0.3)" style={{ position: "absolute", left: 16, top: "50%", transform: "translateY(-50%)" }} />
                  <input 
                    type="email"
                    value={formData.email}
                    onChange={e => setFormData({...formData, email: e.target.value})}
                    placeholder="you@example.com" 
                    style={{...styles.input, paddingLeft: 48}} 
                  />
                </div>
              </div>
              
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16 }}>
                <div style={styles.formGroup}>
                  <label style={styles.label}>Password</label>
                  <div style={{ position: "relative" }}>
                    <Lock size={20} color="rgba(255,255,255,0.3)" style={{ position: "absolute", left: 16, top: "50%", transform: "translateY(-50%)" }} />
                    <input 
                      type="password" 
                      value={formData.password}
                      onChange={e => setFormData({...formData, password: e.target.value})}
                      placeholder="••••••••" 
                      style={{...styles.input, paddingLeft: 48}} 
                    />
                  </div>
                </div>
                
                <div style={styles.formGroup}>
                  <label style={styles.label}>Confirm</label>
                  <div style={{ position: "relative" }}>
                    <Lock size={20} color="rgba(255,255,255,0.3)" style={{ position: "absolute", left: 16, top: "50%", transform: "translateY(-50%)" }} />
                    <input 
                      type="password" 
                      value={formData.confirm}
                      onChange={e => setFormData({...formData, confirm: e.target.value})}
                      placeholder="••••••••" 
                      style={{...styles.input, paddingLeft: 48}} 
                    />
                  </div>
                </div>
              </div>
              
              <button type="submit" className="btn-glow" style={{ ...styles.submitBtn, marginTop: 16 }}>
                 Create Account
              </button>
            </form>

            <div style={{ textAlign: "center", marginTop: 32, fontSize: 15, color: "rgba(255,255,255,0.5)", fontFamily: "Inter" }}>
              Already a member? <Link to="/login" style={{ color: "#e8ff47", fontWeight: 700, textDecoration: "none" }}>Log In</Link>
            </div>
          </>
        )}
      </div>

      <Link to="/" style={{ position: "absolute", top: 40, left: 40, color: "rgba(255,255,255,0.5)", textDecoration: "none", fontWeight: 700, fontSize: 14, textTransform: "uppercase", letterSpacing: 2 }}>
        ← Back to Site
      </Link>

      <style>{`@keyframes fadeIn { from { opacity: 0; transform: translateY(20px); } to { opacity: 1; transform: translateY(0); } }`}</style>
    </div>
  );
}

const styles = {
  formGroup: { display: "flex", flexDirection: "column", gap: 10 },
  label: { fontSize: 13, textTransform: "uppercase", letterSpacing: 1, color: "rgba(255,255,255,0.6)", fontWeight: 800 },
  input: { width: "100%", background: "#050505", border: "1px solid rgba(255,255,255,0.15)", color: "#fff", padding: "16px 20px", borderRadius: 8, fontSize: 16, fontFamily: "Inter", outline: "none", transition: "border-color 0.2s", boxSizing: "border-box" },
  submitBtn: { background: "#e8ff47", color: "#000", border: "none", padding: "20px", borderRadius: 8, fontSize: 16, fontWeight: 900, textTransform: "uppercase", letterSpacing: 2, cursor: "pointer", width: "100%" }
};
