import { Link } from "react-router-dom";

const TRAINERS = [
  { name: "Marcus Steele", role: "Strength Coach", img: "https://images.unsplash.com/photo-1567013127542-490d757e51fc?w=400&q=80", cert: "NSCA-CSCS" },
  { name: "Aria Chen", role: "HIIT Specialist", img: "https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?w=400&q=80", cert: "ACE Certified" },
  { name: "Dev Ramos", role: "MMA & Combat", img: "https://images.unsplash.com/photo-1583454110551-21f2fa2afe61?w=400&q=80", cert: "Pro Fighter" },
];

export default function TrainersDirectory() {
  return (
    <div style={styles.root}>
      {/* Spacer for navbar */}
      <div style={{ height: 100 }} />
      <div style={{ maxWidth: 1200, margin: "0 auto", padding: "40px 24px" }}>
        <div style={styles.sectionLabel}>— WORLD-CLASS COACHING</div>
        <h2 style={styles.sectionH2}>Meet Your <span className="gradient-text">Coaches</span></h2>
        
        <div style={styles.trainerGrid}>
          {TRAINERS.map((t, i) => (
            <div key={i} style={styles.trainerCard} className="trainer-card">
              <div style={styles.trainerImgWrap}>
                <img src={t.img} alt={t.name} style={styles.trainerImg} />
                <div style={styles.trainerOverlay} />
              </div>
              <div style={styles.trainerInfo}>
                <div style={styles.trainerCert}>{t.cert}</div>
                <div style={styles.trainerName}>{t.name}</div>
                <div style={styles.trainerRole}>{t.role}</div>
                <Link to={`/user/payments?payTo=${encodeURIComponent(t.name)}&amount=1999&item=1-on-1+Session`} style={{...styles.trainerBtn, marginTop: 16, display: "inline-block"}} className="btn-glow">
                  Book Session (₹1,999)
                </Link>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

const styles = {
  root: { minHeight: "100vh", background: "#0a0a0a", color: "#f0f0f0" },
  sectionLabel: { fontSize: 12, letterSpacing: 4, color: "#e8ff47", textTransform: "uppercase", fontWeight: 700, marginBottom: 16, textAlign: "center" },
  sectionH2: { fontSize: "clamp(36px, 6vw, 72px)", fontWeight: 900, textTransform: "uppercase", lineHeight: 1, letterSpacing: -1, marginBottom: 60, textAlign: "center" },
  trainerGrid: { display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(300px, 1fr))", gap: 32 },
  trainerCard: { position: "relative", overflow: "hidden", borderRadius: 12 },
  trainerImgWrap: { height: 400, position: "relative" },
  trainerImg: { width: "100%", height: "100%", objectFit: "cover" },
  trainerOverlay: { position: "absolute", inset: 0, background: "linear-gradient(to top, #0a0a0a, transparent)" },
  trainerInfo: { position: "absolute", bottom: 0, left: 0, right: 0, padding: 32 },
  trainerCert: { color: "#e8ff47", fontSize: 11, fontWeight: 900, letterSpacing: 2, marginBottom: 8, textTransform: "uppercase" },
  trainerName: { fontSize: 24, fontWeight: 900, color: "#fff", textTransform: "uppercase", margin: "0 0 4px" },
  trainerRole: { color: "rgba(255,255,255,0.6)", fontSize: 14, fontFamily: "Georgia, serif", fontStyle: "italic" },
  trainerBtn: { background: "#e8ff47", color: "#000", padding: "12px 24px", textDecoration: "none", fontSize: 12, fontWeight: 800, textTransform: "uppercase", borderRadius: 4, letterSpacing: 1 }
};
