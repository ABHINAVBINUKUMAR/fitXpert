import { useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import { Lock, User, ShieldAlert } from "lucide-react";
import { useAuth } from "../context/AuthContext";

export default function AdminLogin() {
  const navigate = useNavigate();
  const { login } = useAuth();
  const [formData, setFormData] = useState({ email: "", password: "" });
  const [error, setError] = useState("");
  const [shake, setShake] = useState(false);

  const handleLogin = async (e) => {
    e.preventDefault();
    setError("");

    if (!formData.email || !formData.password) {
      triggerShake();
      return setError("Please fill all required fields.");
    }

    try {
      const response = await fetch(`${import.meta.env.VITE_API_URL || 'http://localhost:8000/api'}/login`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email: formData.email, password: formData.password }),
      });

      const data = await response.json();
      if (!response.ok) {
        throw new Error(data?.message || "Invalid admin credentials.");
      }

      if (data.user.role !== "admin") {
        throw new Error("This account is not an admin account.");
      }

      localStorage.setItem("fitxpert_token", data.token);
      await login({ email: formData.email, password: formData.password });
      navigate("/admin/dashboard");
    } catch (error) {
      triggerShake();
      setError(error.message || "Invalid admin credentials.");
    }
  };

  const triggerShake = () => {
    setShake(true);
    setTimeout(() => setShake(false), 500);
  };

  return (
    <div style={{ minHeight: "100vh", background: "#050000", display: "flex", alignItems: "center", justifyContent: "center", padding: 24, position: "relative", overflow: "hidden" }}>
      <div style={{ position: "absolute", inset: 0, backgroundImage: `linear-gradient(rgba(255,68,68,0.03) 1px, transparent 1px), linear-gradient(90deg, rgba(255,68,68,0.03) 1px, transparent 1px)`, backgroundSize: "40px 40px", zIndex: 0 }} />

      <div className={shake ? "shake" : ""} style={{ width: "100%", maxWidth: 440, padding: 48, position: "relative", zIndex: 1, background: "#0a0000", border: "1px solid rgba(255,68,68,0.2)", borderRadius: 16, boxShadow: "0 24px 64px rgba(255,68,68,0.1)" }}>

        <div style={{ textAlign: "center", marginBottom: 40 }}>
          <div style={{ fontSize: 40, color: "#ff4444", marginBottom: 16 }}>⬡</div>
          <h1 style={{ fontSize: 32, textTransform: "uppercase", fontWeight: 900, color: "#fff", margin: 0, letterSpacing: 2 }}>
            System Access
          </h1>
          <div style={{ display: "inline-block", background: "rgba(255,68,68,0.1)", color: "#ff4444", padding: "4px 12px", borderRadius: 100, fontSize: 12, fontWeight: 800, textTransform: "uppercase", letterSpacing: 1, marginTop: 12 }}>
            🔴 Admin Panel
          </div>
        </div>

        {error && (
          <div style={{ background: "rgba(255,68,68,0.1)", border: "1px solid rgba(255,68,68,0.3)", padding: "12px 16px", borderRadius: 8, color: "#ff4444", fontSize: 14, fontWeight: 700, marginBottom: 24, display: "flex", alignItems: "center", gap: 10 }}>
            <ShieldAlert size={18} /> {error}
          </div>
        )}

        <form onSubmit={handleLogin} style={{ display: "flex", flexDirection: "column", gap: 20 }}>
          <div style={styles.formGroup}>
            <label style={styles.label}>Admin Email</label>
            <div style={{ position: "relative" }}>
              <User size={20} color="rgba(255,68,68,0.4)" style={{ position: "absolute", left: 16, top: "50%", transform: "translateY(-50%)" }} />
              <input type="text" value={formData.email} onChange={e => setFormData({ ...formData, email: e.target.value })} placeholder="admin@gym.com" style={{ ...styles.input, paddingLeft: 48 }} />
            </div>
          </div>

          <div style={styles.formGroup}>
            <label style={styles.label}>Password</label>
            <div style={{ position: "relative" }}>
              <Lock size={20} color="rgba(255,68,68,0.4)" style={{ position: "absolute", left: 16, top: "50%", transform: "translateY(-50%)" }} />
              <input type="password" value={formData.password} onChange={e => setFormData({ ...formData, password: e.target.value })} placeholder="admin123" style={{ ...styles.input, paddingLeft: 48 }} />
            </div>
          </div>

          <button type="submit" style={styles.submitBtn}>
            Authenticate
          </button>
        </form>
      </div>

      <Link to="/" style={{ position: "absolute", top: 40, left: 40, color: "rgba(255,255,255,0.4)", textDecoration: "none", fontWeight: 700, fontSize: 13, textTransform: "uppercase", letterSpacing: 2 }}>
        ← Back to Home
      </Link>

      <style>{`
        .shake { animation: shake 0.5s cubic-bezier(.36,.07,.19,.97) both; }
        @keyframes shake { 10%, 90% { transform: translate3d(-1px, 0, 0); } 20%, 80% { transform: translate3d(2px, 0, 0); } 30%, 50%, 70% { transform: translate3d(-4px, 0, 0); } 40%, 60% { transform: translate3d(4px, 0, 0); } }
      `}</style>
    </div>
  );
}

const styles = {
  formGroup: { display: "flex", flexDirection: "column", gap: 10 },
  label: { fontSize: 13, textTransform: "uppercase", letterSpacing: 1, color: "rgba(255,255,255,0.6)", fontWeight: 800 },
  input: { width: "100%", background: "rgba(0,0,0,0.5)", border: "1px solid rgba(255,255,255,0.1)", color: "#fff", padding: "16px 20px", borderRadius: 8, fontSize: 16, fontFamily: "Inter", outline: "none", transition: "border-color 0.2s", boxSizing: "border-box" },
  submitBtn: { background: "#ff4444", color: "#fff", border: "none", padding: "20px", borderRadius: 8, fontSize: 16, fontWeight: 900, textTransform: "uppercase", letterSpacing: 2, cursor: "pointer", width: "100%", marginTop: 16, boxShadow: "0 0 24px rgba(255,68,68,0.4)" }
};
