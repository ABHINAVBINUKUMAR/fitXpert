Project Rules (Frontend Phase)

1. UI components → src/pages/menus/<module>/<ModuleName>Form.jsx
2. Redux slices → src/redux/slice/<module>/<moduleName>Slice.js
3. All slices must be registered in redux/store.js
4. Use shared styles only → src/styles/
5. Use Redux Toolkit for state management (createSlice)
6. Keep components reusable and modular
7. Use dummy/static data instead of API calls for now
8. Maintain clean folder structure and naming conventions