<?php

namespace Tests\Feature;

use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class MembershipPlanTest extends TestCase
{
    use RefreshDatabase;

    public function test_member_can_register_with_plan_and_view_available_plans(): void
    {
        $this->seed();

        $response = $this->postJson('/api/register', [
            'name' => 'Plan User',
            'email' => 'planuser@example.com',
            'password' => 'password123',
            'password_confirmation' => 'password123',
            'plan_id' => 1,
        ]);

        $response->assertStatus(201)
            ->assertJsonPath('user.email', 'planuser@example.com');

        $plans = $this->getJson('/api/plans');

        $plans->assertStatus(200)
            ->assertJsonStructure([
                'plans' => [
                    '*' => ['id', 'name', 'price', 'duration_days'],
                ],
            ]);
    }
}
