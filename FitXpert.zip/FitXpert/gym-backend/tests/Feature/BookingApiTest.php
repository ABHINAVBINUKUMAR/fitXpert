<?php

namespace Tests\Feature;

use App\Models\Booking;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class BookingApiTest extends TestCase
{
    use RefreshDatabase;

    public function test_user_can_create_booking_and_admin_can_update_it(): void
    {
        $user = User::factory()->create([
            'role' => 'user',
        ]);

        $admin = User::factory()->create([
            'role' => 'admin',
        ]);

        $response = $this->actingAs($user, 'sanctum')->postJson('/api/bookings', [
            'trainer_name' => 'Marcus Steele',
            'session_type' => '1:1 Personal',
            'booking_date' => '2026-03-24',
            'booking_time' => '07:00 AM',
            'amount' => 1999,
            'notes' => 'Need strength focus',
        ]);

        $response->assertStatus(201)
            ->assertJsonPath('booking.trainer_name', 'Marcus Steele');

        $booking = Booking::first();

        $this->actingAs($admin, 'sanctum')
            ->patchJson('/api/admin/bookings/'.$booking->id, [
                'status' => 'confirmed',
                'payment_status' => 'paid',
            ])
            ->assertStatus(200)
            ->assertJsonPath('booking.status', 'confirmed');
    }
}
