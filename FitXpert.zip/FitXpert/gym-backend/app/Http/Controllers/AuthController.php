<?php

namespace App\Http\Controllers;

use App\Models\Plan;
use App\Models\User;
use App\Models\UserMembership;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\ValidationException;

class AuthController extends Controller
{
    public function register(Request $request)
    {
        $validated = $request->validate([
            'name' => ['required', 'string', 'max:255'],
            'email' => ['required', 'string', 'email', 'max:255', 'unique:users'],
            'password' => ['required', 'string', 'min:6', 'confirmed'],
            'plan_id' => ['nullable', 'integer', 'exists:plans,id'],
        ]);

        $user = User::create([
            'name' => $validated['name'],
            'email' => $validated['email'],
            'password' => Hash::make($validated['password']),
            'role' => 'user',
            'status' => 'active',
            'plan' => 'starter',
            'fee' => '₹999',
            'joined_at' => now()->toDateString(),
            'expiry_at' => now()->addMonth()->toDateString(),
            'last_payment_at' => now()->toDateString(),
        ]);

        if (! empty($validated['plan_id'])) {
            $plan = Plan::findOrFail($validated['plan_id']);

            UserMembership::create([
                'user_id' => $user->id,
                'plan_id' => $plan->id,
                'start_date' => now()->toDateString(),
                'expiry_date' => now()->addDays($plan->duration_days)->toDateString(),
                'status' => 'active',
                'payment_status' => 'pending',
                'amount_paid' => $plan->price,
            ]);

            $user->update([
                'plan' => $plan->name,
                'fee' => '₹'.number_format((float) $plan->price, 0),
                'expiry_at' => now()->addDays($plan->duration_days)->toDateString(),
            ]);
        }

        $token = $user->createToken('fitxpert')->plainTextToken;

        return response()->json([
            'token' => $token,
            'user' => $this->serializeUser($user),
        ], 201);
    }

    public function login(Request $request)
    {
        $validated = $request->validate([
            'email' => ['required', 'string', 'email'],
            'password' => ['required', 'string'],
        ]);

        $user = User::where('email', $validated['email'])->first();

        if (! $user || ! Hash::check($validated['password'], $user->password)) {
            throw ValidationException::withMessages([
                'email' => ['The provided credentials are incorrect.'],
            ]);
        }

        $token = $user->createToken('fitxpert')->plainTextToken;

        return response()->json([
            'token' => $token,
            'user' => $this->serializeUser($user),
        ]);
    }

    public function logout(Request $request)
    {
        $request->user()->tokens()->delete();

        return response()->json(['message' => 'Logged out successfully']);
    }

    public function user(Request $request)
    {
        return response()->json([
            'user' => $this->serializeUser($request->user()),
        ]);
    }

    protected function serializeUser(User $user): array
    {
        return [
            'id' => $user->id,
            'name' => $user->name,
            'email' => $user->email,
            'role' => $user->role,
            'status' => $user->status,
            'plan' => $user->plan,
            'fee' => $user->fee,
            'joined_at' => $user->joined_at,
            'expiry_at' => $user->expiry_at,
            'last_payment_at' => $user->last_payment_at,
        ];
    }
}
