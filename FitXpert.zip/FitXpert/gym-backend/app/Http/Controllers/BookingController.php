<?php

namespace App\Http\Controllers;

use App\Models\Booking;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class BookingController extends Controller
{
    public function index(Request $request)
    {
        $bookings = Booking::where('user_id', $request->user()->id)
            ->orderByDesc('created_at')
            ->get();

        return response()->json([
            'bookings' => $bookings->map(function ($booking) {
                return [
                    'id' => $booking->id,
                    'trainer_name' => $booking->trainer_name,
                    'session_type' => $booking->session_type,
                    'booking_date' => $booking->booking_date,
                    'booking_time' => $booking->booking_time,
                    'amount' => (int) $booking->amount,
                    'notes' => $booking->notes,
                    'status' => $booking->status,
                    'payment_status' => $booking->payment_status,
                ];
            }),
        ]);
    }

    public function adminIndex(Request $request)
    {
        $this->authorizeAdmin($request);

        return response()->json([
            'bookings' => Booking::with('user')->orderByDesc('created_at')->get()->map(function ($booking) {
                return [
                    'id' => $booking->id,
                    'member' => $booking->user?->name ?? 'Unknown',
                    'trainer_name' => $booking->trainer_name,
                    'session_type' => $booking->session_type,
                    'booking_date' => $booking->booking_date,
                    'booking_time' => $booking->booking_time,
                    'amount' => (int) $booking->amount,
                    'status' => $booking->status,
                    'payment_status' => $booking->payment_status,
                ];
            }),
        ]);
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'trainer_name' => ['required', 'string', 'max:255'],
            'session_type' => ['required', 'string', 'max:255'],
            'booking_date' => ['required', 'date'],
            'booking_time' => ['required', 'string', 'max:255'],
            'amount' => ['nullable', 'numeric'],
            'notes' => ['nullable', 'string'],
        ]);

        $booking = Booking::create([
            'user_id' => $request->user()->id,
            'trainer_name' => $validated['trainer_name'],
            'session_type' => $validated['session_type'],
            'booking_date' => $validated['booking_date'],
            'booking_time' => $validated['booking_time'],
            'amount' => $validated['amount'] ?? 0,
            'notes' => $validated['notes'] ?? null,
            'status' => 'pending',
            'payment_status' => 'pending',
        ]);

        return response()->json([
            'message' => 'Booking created successfully',
            'booking' => [
                'id' => $booking->id,
                'trainer_name' => $booking->trainer_name,
                'session_type' => $booking->session_type,
                'booking_date' => $booking->booking_date,
                'booking_time' => $booking->booking_time,
                'amount' => (int) $booking->amount,
                'status' => $booking->status,
                'payment_status' => $booking->payment_status,
            ],
        ], 201);
    }

    public function markPaid(Request $request, Booking $booking)
    {
        if ($request->user()->id !== $booking->user_id && $request->user()->role !== 'admin') {
            abort(403, 'Access denied');
        }

        $booking->update([
            'payment_status' => 'paid',
            'status' => 'confirmed',
        ]);

        return response()->json([
            'message' => 'Payment confirmed',
            'booking' => $booking->fresh(),
        ]);
    }

    public function update(Request $request, Booking $booking)
    {
        $this->authorizeAdmin($request);

        $validated = $request->validate([
            'status' => ['sometimes', 'string'],
            'payment_status' => ['sometimes', 'string'],
        ]);

        $booking->fill($validated);
        $booking->save();

        return response()->json([
            'message' => 'Booking updated successfully',
            'booking' => $booking->fresh(),
        ]);
    }

    protected function authorizeAdmin(Request $request): void
    {
        if ($request->user()?->role !== 'admin') {
            abort(403, 'Access denied');
        }
    }
}
