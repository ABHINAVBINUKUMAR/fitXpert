<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class MemberController extends Controller
{
    public function index(Request $request)
    {
        $this->authorizeAdmin($request);

        return response()->json([
            'members' => User::where('role', 'user')->get()->map(fn (User $user) => [
                'id' => 'M-'.$user->id,
                'name' => $user->name,
                'email' => $user->email,
                'plan' => strtoupper($user->plan ?? 'starter'),
                'fee' => $user->fee ?? '₹999',
                'joined' => $user->joined_at?->format('d M Y') ?? 'N/A',
                'expiry' => $user->expiry_at?->format('d M Y') ?? 'N/A',
                'lastPayment' => $user->last_payment_at?->format('d M Y') ?? 'N/A',
                'status' => ucfirst($user->status ?? 'active'),
            ])->all(),
        ]);
    }

    public function store(Request $request)
    {
        $this->authorizeAdmin($request);

        $validated = $request->validate([
            'name' => ['required', 'string'],
            'email' => ['required', 'email', 'unique:users'],
            'plan' => ['required', 'string'],
            'fee' => ['required', 'string'],
            'password' => ['required', 'string', 'min:6'],
        ]);

        $member = User::create([
            'name' => $validated['name'],
            'email' => $validated['email'],
            'password' => Hash::make($validated['password']),
            'role' => 'user',
            'plan' => strtolower($validated['plan']),
            'fee' => $validated['fee'],
            'status' => 'active',
            'joined_at' => now()->toDateString(),
            'expiry_at' => now()->addMonth()->toDateString(),
            'last_payment_at' => now()->toDateString(),
        ]);

        return response()->json([
            'message' => 'Member created successfully',
            'member' => [
                'id' => 'M-'.$member->id,
                'name' => $member->name,
                'email' => $member->email,
                'plan' => strtoupper($member->plan),
                'fee' => $member->fee,
                'status' => ucfirst($member->status),
            ],
        ], 201);
    }

    public function markAttendance(Request $request, User $user)
    {
        $this->authorizeAdmin($request);

        $user->update([
            'status' => 'active',
        ]);

        return response()->json([
            'message' => 'Attendance marked for '.$user->name,
            'user' => $user->name,
        ]);
    }

    public function update(Request $request, User $user)
    {
        $this->authorizeAdmin($request);

        $validated = $request->validate([
            'name' => ['sometimes', 'string', 'max:255'],
            'email' => ['sometimes', 'email', 'max:255', 'unique:users,email,'.$user->id],
            'plan' => ['sometimes', 'string', 'max:255'],
            'fee' => ['sometimes', 'string', 'max:255'],
            'status' => ['sometimes', 'in:active,inactive,pending,blocked'],
        ]);

        $user->fill($validated);

        if (isset($validated['plan'])) {
            $user->plan = strtolower($validated['plan']);
        }

        if (isset($validated['fee'])) {
            $user->fee = $validated['fee'];
        }

        $user->save();

        return response()->json([
            'message' => 'Member updated successfully',
            'member' => [
                'id' => $user->id,
                'name' => $user->name,
                'email' => $user->email,
                'plan' => strtoupper($user->plan ?? 'starter'),
                'fee' => $user->fee ?? '₹999',
                'status' => ucfirst($user->status ?? 'active'),
            ],
        ]);
    }

    protected function authorizeAdmin(Request $request): void
    {
        if ($request->user()?->role !== 'admin') {
            abort(403, 'Access denied');
        }
    }
}
