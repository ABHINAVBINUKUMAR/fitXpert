<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;

class DashboardController extends Controller
{
    public function userDashboard(Request $request)
    {
        $user = $request->user();

        return response()->json([
            'overview' => [
                ['title' => 'Active Members', 'value' => '12,450', 'trend' => '+12% this month'],
                ['title' => 'Avg Attendance', 'value' => '84%', 'trend' => '+5% this week'],
                ['title' => 'Active Trainers', 'value' => '24', 'trend' => 'Fully staffed'],
                ['title' => 'Calories Burned', 'value' => '1.2M', 'trend' => 'Global Gym Stat'],
            ],
            'weeklyFootfall' => [
                ['name' => 'Mon', 'visitors' => 400],
                ['name' => 'Tue', 'visitors' => 300],
                ['name' => 'Wed', 'visitors' => 550],
                ['name' => 'Thu', 'visitors' => 450],
                ['name' => 'Fri', 'visitors' => 600],
                ['name' => 'Sat', 'visitors' => 800],
                ['name' => 'Sun', 'visitors' => 750],
            ],
            'user' => [
                'id' => $user->id,
                'name' => $user->name,
                'email' => $user->email,
                'plan' => $user->plan,
                'status' => $user->status,
            ],
        ]);
    }

    public function adminDashboard(Request $request)
    {
        $this->authorizeAdmin($request);

        return response()->json([
            'kpis' => [
                ['title' => 'Total Members', 'value' => '248', 'trend' => '+12 this week'],
                ['title' => 'Active Today', 'value' => '64', 'trend' => '15% vs yesterday'],
                ['title' => 'Monthly Revenue', 'value' => '₹1,24,500', 'trend' => '+8% vs last month'],
                ['title' => 'Equipment Status', 'value' => '42/50', 'trend' => '3 in maintenance'],
            ],
            'revenue' => [
                ['name' => 'Jan', 'val' => 95000], ['name' => 'Feb', 'val' => 102000], ['name' => 'Mar', 'val' => 124500],
                ['name' => 'Apr', 'val' => 110000], ['name' => 'May', 'val' => 118000], ['name' => 'Jun', 'val' => 132000],
                ['name' => 'Jul', 'val' => 145000], ['name' => 'Aug', 'val' => 142000], ['name' => 'Sep', 'val' => 155000],
                ['name' => 'Oct', 'val' => 158000], ['name' => 'Nov', 'val' => 162000], ['name' => 'Dec', 'val' => 175000],
            ],
            'checkins' => [
                ['name' => 'Mon', 'val' => 142], ['name' => 'Tue', 'val' => 185], ['name' => 'Wed', 'val' => 165],
                ['name' => 'Thu', 'val' => 190], ['name' => 'Fri', 'val' => 160], ['name' => 'Sat', 'val' => 95], ['name' => 'Sun', 'val' => 120],
            ],
            'equipment' => [
                ['name' => 'Available', 'val' => 42, 'color' => '#4caf50'],
                ['name' => 'In Use', 'val' => 5, 'color' => '#ff9800'],
                ['name' => 'Maintenance', 'val' => 3, 'color' => '#ff4444'],
            ],
            'activity' => [
                ['time' => '10:42 AM', 'msg' => 'Marcus Steele completed 1:1 session with John'],
                ['time' => '10:30 AM', 'msg' => 'New Elite membership purchased'],
                ['time' => '09:15 AM', 'msg' => 'Treadmill #4 marked for maintenance'],
            ],
        ]);
    }

    protected function authorizeAdmin(Request $request): void
    {
        if ($request->user()?->role !== 'admin') {
            abort(403, 'Access denied');
        }
    }
}
