<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Seeder;

class AdminUserSeeder extends Seeder
{
    public function run(): void
    {
        User::firstOrCreate(
            ['email' => 'admin@gym.com'],
            [
                'name' => 'Gym Admin',
                'password' => bcrypt('admin123'),
                'role' => 'admin',
                'status' => 'active',
                'plan' => 'premium',
                'fee' => '₹2999',
                'joined_at' => now()->toDateString(),
                'expiry_at' => now()->addMonth()->toDateString(),
                'last_payment_at' => now()->toDateString(),
            ]
        );
    }
}
