<?php

namespace Database\Seeders;

use App\Models\Plan;
use Illuminate\Database\Seeder;

class PlanSeeder extends Seeder
{
    public function run(): void
    {
        $plans = [
            ['name' => 'Basic', 'price' => 999, 'duration_days' => 30, 'description' => 'Basic gym access', 'is_active' => true],
            ['name' => 'Standard', 'price' => 1799, 'duration_days' => 30, 'description' => 'Gym + cardio access', 'is_active' => true],
            ['name' => 'Premium', 'price' => 2999, 'duration_days' => 30, 'description' => 'Gym + trainer + premium access', 'is_active' => true],
        ];

        foreach ($plans as $plan) {
            Plan::create($plan);
        }
    }
}
